# BASS_CR foundation rebuild scout

Read REPORT_KO.md first; theory and architecture are in docs/. Internal units are a0, Eh, t_a. This is a CPU foundation-probe package, NOT an admitted proton-hydrogen capture solver. It does not modify cr_repro, install GPU dependencies, invoke a local LLM, or launch a full collision.

## Tests
```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
PYTHONPATH=src python -m pytest tests -q
```
The recorded environment is in ENVIRONMENT.json. requirements-tested.txt records exact tested versions; do not upgrade a production environment silently just to match this scout.

## Fresh output only
```sh
mkdir -p runs
PYTHONPATH=src python run_probes.py atom --solver lobpcg --n 64 --length 16 --phase 0 --out runs/atom.json
PYTHONPATH=src python run_probes.py split --solver lobpcg --n 64 --length 16 --out runs/split.json
PYTHONPATH=src python run_probes.py radial --out runs/radial.json
PYTHONPATH=src python run_rebuild_probes.py --embedded --modes 15 31 47 63 --outdir runs/galerkin
```
Atom scout capped at128 nodes/axis; Galerkin CLI at81 modes/axis; dense diagnostic matrix at9^3. Radial dense prototype capped at1500 DOFs. A solver failure raises rather than returning an unconverged endpoint. Existing results are never overwritten. If a run interrupted after a case, preserve its *_PARTIAL.json and use a new output name for another attempt.

Cell-average roundoff is checked against a high-precision scalar implementation on tested geometries, not certified for arbitrary huge r/h. Factory Fourier kernel arrays are read-only; mutable dictionary containers are a prototype interface, not a production identity/security boundary. Only isolated static and translating-potential tests have been run. Existing original 3% capture discrepancy remains OPEN.
