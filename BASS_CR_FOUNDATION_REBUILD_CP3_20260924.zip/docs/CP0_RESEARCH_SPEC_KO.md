# CP0: 기초 가정의 재개방과 판별 실험

## 현재 권한과 기준
이번 사용자 요청은 원래 외부 감사의 read-only 연구 범위를 확장하여 수학/물리 탐사와 독립 코딩 실험을 요청한다. 기존 bass_cr checkout 및 과거 결과는 수정하지 않는다. 현재 원격 R3M29 HEAD=8e1d49e5ef6af70bb47d9238e64cda68ea0f5c4f. 이후 관측이 없는 한 production HOLD, all-bound OPEN, b-grid NO_GO를 유지한다.

## 사전 판별 질문
1. 셀 평균은 potential 적분의 정밀성만 개선하는가, 실제 수소 스펙트럼 오차도 개선하는가? 동일 FFT kinetic에서 point와 exact cuboid-average를 true eigensolver로 비교한다. 정적 단일 원자와 여러 subcell 위치, h, box를 사용한다. capture 수렴으로 승격하지 않는다.
2. Coulomb cusp에서 Strang의 매끄러운 potential 오차정리가 h에 균일한가? commutator와 수소 1s 기대값을 직접 유도한다. finite matrix의 시간 수렴과 continuum limit을 분리한다.
3. 유한 imaginary dt의 split fixed point가 true H_h eigenstate인가? 실제 소규모 3D 원자에서 split operator의 고유벡터와 H_h ground state를 비교하여 반복 오차를 제거한 뒤 남는 편향을 측정한다.
4. Collocation과 비alias Fourier-Galerkin을 혼동했는가? analytic cutoff-Coulomb Fourier coefficients로 finite Toeplitz Hamiltonian을 만들고 exact subcell translation covariance를 검증한다. cutoff/periodic boundary는 명시적 진단용 모형이다.
5. radial high-order FEM이 cusp와 bound spectrum을 낮은 자유도로 해결하는가? 정적 radial hydrogen u(r) weak form의 질량/강성 행렬을 조립하고 해석적 n,l spectrum, virial, residual, quadrature/mesh/domain 수렴을 검증한다. 전체 이중중심 충돌 솔버로 부르지 않는다.
6. AOCC의 norm 보존은 기저 미분항과 angular completeness를 보장하는가? 실제 코드의 s,p 한계 및 algebraically skewed generator를 확인하고 independent moving-basis negative control을 시험한다.

## 기준과 정지
방법 간 작은 차이를 정답으로 쓰지 않는다. 수소 exact spectrum, 정확한 대칭, 독립 조립 및 algebra가 기준이다. 실패 후보의 thresholds를 완화하거나 같은 원리의 full collision을 반복하지 않는다. 각 소규모 실험의 결과를 그대로 보존하고 하나의 다음 implementation decision을 선택한다.

## 실험 범위
원자 단위(a0,Eh,t_a)를 명시적으로 사용한다. CPU bounded experiments만, 기존 B3 array 없이 가능하다. full production h=.20 63M-grid collision, new physical cross sections, cloud/heavy jobs, repo push/merge는 이 pass에서 하지 않는다.

## 복구 및 외부 도구
R3M9 Dropbox 추출 본문을 읽어 기존 물리계약과 ETF/Gram/continuum 요구를 확인했다. 기존 Google Drive ZIP 네 개는 현 런타임의 byte-backed 입력으로 보존한다. Dropbox direct-download를 Python에서 시도했으나 DNS 실패; 이를 scientific failure로 세지 않는다. SkillQuiver 검색 결과는 빈 배열이므로 해당 스킬 실행을 주장하지 않는다. SciSpace 논문 검색 및 Wolfram symbolic evaluator는 사용했다.
