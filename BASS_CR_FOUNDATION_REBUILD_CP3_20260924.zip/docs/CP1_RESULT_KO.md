# CP1: Coulomb/FFT 원자 및 준비 고정점 판별

원자 단위 사용. 이 결과는 B3 전체 box/trajectory의 재실행이 아니다.

## 확정된 결과
- L=16, h=.25에서 true-H 고유해 E는 point=-0.4873543259575225 Eh, cell=-0.4905554527341125 Eh다. L=24에서는 각각 -0.4873474817859029, -0.4905489878271475 Eh다. box 차이 약 6.8e-6/6.5e-6 Eh보다 continuum -1/2와의 차이가 훨씬 크다.
- L=16,h=.20에서 point=-0.4914980072234173, cell=-0.4937913004021899 Eh. L=24에서는 -0.49149165108259574,-0.4937851978086809 Eh다. 셀 평균은 개선하지만 원자 에너지 오차 1.24%가 남는다. 이는 capture 확률 오차의 추정치가 아니다.
- h=.20에서 핵 z 위치를 0→h/2 이동할 때 point E 차이는 0.0021597829929372 Eh, cell은 0.0003789895846805 Eh다. L=16 boundary 변화가 함께 있으므로 완전한 translation-only 효과라는 주장은 하지 않는다.
- 같은 H_h의 true eigenstate와 S_tau의 정확한 고정점을 직접 비교했다. h=.25,.20, tau=.00625의 true-H residual은 각각 .001375456058107419,.0031950105956815495 Eh. 이는 원래 A3/B3 초기 residual .0013755497501259978,.003195199693883384 Eh와 각각 약 0.00681%,0.00592% 차이다. 다른 box이므로 byte parity는 아니지만 finite-tau split 고정점 편향이 잔차의 바닥값을 설명한다는 강한 증거다.
- 이때 state L2 차이는 각각 3.79347858e-5,5.64803536e-5. 큰 H residual과 state/capture error를 동일시할 수 없다. 그로부터 B3 전체 capture 원인/예산 승인을 주장하지 않는다.
- 보존 원본과 달리 true-H 준비 후보는 FFT kinetic inverse preconditioning + LOBPCG를 쓴다. 작은 원자의 ARPACK 독립 고유해 및 h=.25의 ARPACK 결과와 일치했고, h=.20의 true-H residual은 약 1.6e-11 Eh다. 이는 준비 solver 구조의 해결이지 continuum discretization의 해결은 아니다.
- Fourier-Galerkin 진단 Hamiltonian에서 translation covariance norm 상대잔차 ~1e-16, energy 변화 <=9e-16 Eh. 구면 cutoff/periodic boundary는 원래 free-space Hamiltonian과 별도다.
- Radial FEM에서 R=64의 n=5,l=2 energy는 .00010098 Eh 편향을 보이면서 eigenresidual <1e-11이다. R=128로 늘리면 차이가 ~1e-11 Eh로 줄었다. 작은 residual만으로 domain/고준위 completeness를 판단할 수 없다.

## 실패 보존과 수정
1. 최초 TDD RED와 20 PASS/2 FAIL 로그 보존. 두 FAIL은 R=64로 n<=5 무한공간 spectrum을 요구한 시험 범위가 부적절했다. radial kernel/정확도 threshold는 바꾸지 않고 R=128로 domain을 늘린 독립 결과를 확인했다. R=64의 실패는 명시적 negative control 시험으로 남겼다.
2. 비전처리 ARPACK N80 probe는 45초 묶음 실행 제한, 이어 90초 독립 실행 제한으로 두 번 중단되었다. 최종 결과가 없으며 scientific NO_GO로 세지 않는다. 동등한 H를 residual-stopped LOBPCG로 푼 별도 candidate를 구현해 완료했다. 이전 run 시간을 speedup factor로 해석하지 않는다.
3. 현재 새 패키지 unit/invariant suite: 33 passed. 기존 repository 전체 suite 재실행은 아니다.

## 다음 단계
Cell average만 production에 넣는 선택은 하지 않는다. 진짜 Fourier-Galerkin Coulomb action으로 static binding/cusp 수렴을 비교하고, 이동 좌표계의 정확한 시간의존 benchmark와 moving-basis connection을 검증한다. 독립 radical radial/two-center 경로는 동시에 설계한다. 기존 원본 상태와 production HOLD를 보존한다.
