# CP2: 연산자 재구축과 radical 경로 판별

## Fourier-Galerkin의 실제 결과
구면 cutoff Coulomb(-1/r for r<Rc, 밖에서0)을 주기 box에 올린 별도 진단 모형이다. Coulomb 원점은 softening하지 않는다. n=15,31,47,63,79 모드/축, L=16,Rc=7의 ground 에너지 오차 |E+.5|는 .02351274,.003716780,.001162189,.0005036337,.0002637263 Eh다. 같은 주기 cutoff 모형에서 부분공간을 늘릴 때 변분 에너지가 단조 감소했다. 63/79 모드의 상대 에너지 차이는 .1007267%,.0527453%다. point/cell collocation의 N64/80와 최대 파수가 가깝지만 완전히 같지는 않으며 boundary 모델도 다르다.

L=20,Rc=9,n=79 (kmax=12.2522)는 E=-.4995078946005073 Eh. L=16,Rc=7,n=63(kmax=12.1737)의 E=-.4994963663327842와 비슷하다. 둘을 같은 cutoff/basis의 exact boundary subtraction으로 해석하지 않는다. L=16,n=79에서 Rc=6→7 변화는 -5.74094e-5 Eh다. 따라서 cutoff 효과를 버리거나 continuum error가 모두 spectral truncation이라고 단정하지 않는다.

무한공간 단일 원자에 대해서만, Vcut>=VCoulomb 및 정확한 1s trial state의 변분원리를 사용하면 0<=Ecut+1/2<=(2Rc+1)exp(-2Rc)이다. Rc=7에서1.2472931e-5 Eh, Rc=9에서2.8936962e-7 Eh. 이 bound는 주기경계나 이중중심 충돌에는 적용하지 않았다.

## 실제 코딩 루프
- full linear convolution으로 조립한 nonalias Toeplitz action을 독립 dense matrix와 비교했다.
- 이를 (2n-1)^3 이상 circulant embedding으로 바꾼 action을 추가했다. 작은 n=3/5/7에서 dense와 원래 convolution 양쪽에 일치한다. n=63 ground energy는 두 구현 사이6.1e-16 Eh 차이였다. scalar code의 국소 corner 보정과 전혀 다른 알고리즘이다.
- n63 case 한 번의 측정 wall은 full convolution7.03초, embedding1.72초였지만 반복·동시성·peak memory 통제된 성능 연구가 아니므로 production speedup이라고 부르지 않는다.
- B3 350x300x600에서 fast embedding700x600x1200의 complex128 배열 하나8,064,000,000 bytes. 세 배열22.53GiB에 상태/kinetic/CAP/FFT workspace는 미포함이다. naive full-box 이식은 자원 계획 없이 승인하지 않는다. 최소 배열 수로 줄일 가능성을 배제하거나 메모리 불가능 정리를 주장하지 않는다.

## 이동 potential과 connection
H(t)=D(vt)H0D(vt)^dagger는 정확히 c(t)=D(vt)exp[-i(H0-vKz)t]c(0)로 풀린다. n=7,L=10,Rc=4,v=2.0079810665,T=1.3의 유한 기저 시험에서 exponential midpoint의8/16/32/64/128 steps state error는 .00188847,.000469838,.000117324,2.93227e-5,7.33015e-6로2차 수렴했다. 잘못해서 -vKz를 빠뜨리면 norm error1.3e-15인데 state error1.0285, translated-ground projection이 .22624 대신 거의1이 된다. 초기조건은 정지 H0 ground이며 이는 isolated transport benchmark이지 p-H capture 실험이 아니다. finite-band translation covariance와 continuum boost invariance도 구분한다.

R3M17 scripts/r3m17_aocc_metric.py는 이미 독립 dot(S)=D+D† 검사와 Cholesky 미분 검사를 제공한다. 이 사실을 확인했으므로 '기존에 metric 감사가 없었다'고 말하지 않는다. 그러나 D의 anti-Hermitian 부분은 dot(S)와 norm 조건에 나타나지 않는다. 회전 기저 negative control에서 틀린 D=0은 metric identity와 skew-generator 검사를 통과하지만 직접 B†dot(B) 잔차 .9899495가 나온다. 새로운 보완은 직접 basis derivative와 exact transport의 검증이다. 실제 AOCC D의 결함을 발견했다는 주장은 아니다.

## radical 경로
Radial hp-FEM 원자 준비/스펙트럼 코드와 위 이동 기저 benchmark를 two-center cusp-adapted Galerkin 엔진의 첫 독립 구성품으로 채택한다. 기존 Gaussian AOCC는 s+p-only임이 실제 source에 명시되어 있다. radial exponents만 늘리는 것으로 outgoing d/f channels를 완성하지 못한다. 새로운 엔진은 두 중심의 l,m 및 positive-energy pseudostates, cross overlap/kinetic/Coulomb/direct-D, 질량행렬, full-H 시간 적분, common observable를 함께 다룬다. 이중중심 행렬과 충돌 전파는 아직 구현/검증되지 않았다.

## 결정
1. 기존 모형·결과는 freeze; point FFT baseline을 회귀 비교로 유지한다.
2. surgical preparation은 true-H residual-stopped eigensolve로 변경하는 후보가 구현되었다.
3. cell-average-only production patch는 선택하지 않는다. cell 평균 oracle는 검산용으로 보존한다.
4. operator-consistent Fourier-Galerkin은 독립 기준 및 제한된 domain 후보로 승격하지만 full B3 box에는 즉시 이식하지 않는다.
5. radical two-center cusp-adapted basis를 독립 prototype branch의 우선 연구 경로로 선택한다. geometry/cross-integral 비용과 실제 common-capture convergence가 최종 생산 경로 선택을 결정한다.

새 패키지 최종41 tests PASS, 기존 repo full suite 미실행. Production HOLD/all-bound OPEN/b-grid NO_GO는 유지한다.
