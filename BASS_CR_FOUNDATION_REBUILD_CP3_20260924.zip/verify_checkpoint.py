#!/usr/bin/env python3
"""Read-only integrity check for one immutable stage ZIP.

A byte-integrity result is not a scientific or restoration validation.
Historical manifests describe their own ZIP, never the current source tree.
"""
import argparse,json,hashlib,zipfile
from pathlib import PurePosixPath

def verify(archive,stage):
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist();names=[i.filename for i in infos]
        if len(names)!=len(set(names)):raise ValueError('duplicate ZIP member')
        if sum(i.file_size for i in infos)>250_000_000:raise ValueError('unexpectedly large checkpoint')
        for name in names:
            p=PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts:raise ValueError('unsafe archive member')
        mp=f'checkpoints/{stage}_MANIFEST.json'
        manifest=json.loads(z.read(mp));files=manifest.get('files',manifest)
        if set(names)!=set(files)|{mp}:raise ValueError('manifest/archive membership mismatch')
        for name,spec in files.items():
            blob=z.read(name)
            if len(blob)!=spec['bytes'] or hashlib.sha256(blob).hexdigest()!=spec['sha256']:
                raise ValueError('byte mismatch: '+name)
        if z.testzip() is not None:raise ValueError('CRC failure')
        return {'archive':str(archive),'stage':stage,'members_verified':len(files),
                'byte_integrity':'VERIFIED','scientific_validation':'NOT_IMPLIED',
                'full_original_state_restore':'NOT_TESTED'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive');p.add_argument('--stage',required=True,choices=['CP0','CP1','CP2','CP3']);a=p.parse_args()
    print(json.dumps(verify(a.archive,a.stage),indent=2))
