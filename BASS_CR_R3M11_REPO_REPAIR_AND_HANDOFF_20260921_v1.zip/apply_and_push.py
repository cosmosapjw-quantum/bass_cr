#!/usr/bin/env python3
"""Apply this addition-only packet in a new Git worktree; optionally publish that branch.

Uses an existing clone and existing Git credentials. Never changes main, forces a
push, rewrites old results, or invents author identity. Run from the delivered packet.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE='77237751bdd2aed5934bf7fc3bc626d631a09058'


def run(args,cwd=None):
    p=subprocess.run(args,cwd=cwd,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(f'{args[0]} failed ({p.returncode}): {p.stderr[-2000:]}')
    return p.stdout.strip()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',required=True);p.add_argument('--worktree',required=True)
    p.add_argument('--branch',default='cr/r3m11-fixed-cap-gram-20260921')
    p.add_argument('--push',action='store_true');p.add_argument('--receipt',required=True)
    a=p.parse_args();packet=Path(__file__).resolve().parent;repo=Path(a.repo).resolve();wt=Path(a.worktree).resolve();receipt=Path(a.receipt)
    if receipt.exists():raise FileExistsError('receipt already exists')
    if wt.exists():raise FileExistsError('worktree path must be new')
    if not a.branch.startswith('cr/'):raise ValueError('use a dedicated cr/ branch')
    run(['git','check-ref-format','--branch',a.branch])
    origin=run(['git','remote','get-url','origin'],repo)
    if origin.rstrip('/').removesuffix('.git') not in ['https://github.com/cosmosapjw-quantum/bass_cr','git@github.com:cosmosapjw-quantum/bass_cr']:
        raise ValueError('origin is not the approved bass_cr repository')
    # Read-only fetch, then bind to the exact imported main. A newer main calls
    # for an explicit semantic rebase, not an automatic patch onto changed code.
    run(['git','fetch','origin'],repo)
    current=run(['git','rev-parse','origin/main'],repo)
    if current!=BASE:raise RuntimeError(f'origin/main moved to {current}; review/rebase explicitly, preserving imported base {BASE}')
    existing=run(['git','ls-remote','--heads','origin',a.branch],repo)
    if existing:raise RuntimeError('remote branch already exists; choose a new branch, never force push')
    index=json.loads((packet/'OVERLAY_FILES.json').read_text())
    for entry in index:
        if sha(packet/'overlay'/entry['path'])!=entry['sha256']:raise ValueError('overlay hash mismatch')
    patch=packet/'R3M11.patch'
    patch_expected=(packet/'R3M11.patch.sha256').read_text().split()[0]
    if sha(patch)!=patch_expected:raise ValueError('patch hash mismatch')
    run(['git','worktree','add','-b',a.branch,str(wt),BASE],repo)
    result=dict(schema='R3M11_LOCAL_GIT_PUBLICATION_V1',base_commit=BASE,branch=a.branch,
        status='WORKTREE_CREATED_NOT_COMMITTED',push_requested=a.push,remote_push_verified=False)
    receipt.parent.mkdir(parents=True,exist_ok=True)
    def save():receipt.write_text(json.dumps(result,indent=2)+'\n')
    save()
    try:
        run(['git','apply','--check',str(patch)],wt);run(['git','apply','--index',str(patch)],wt)
        names=run(['git','diff','--cached','--name-only'],wt).splitlines()
        if sorted(names)!=sorted(e['path'] for e in index):raise RuntimeError('staged paths differ from approved additions')
        for e in index:
            if sha(wt/e['path'])!=e['sha256']:raise RuntimeError(f'applied byte mismatch {e["path"]}')
        cmd=[sys.executable,'-m','pytest','-q','tests/test_core.py','tests/test_r3m11.py','tests/test_r3m11_jobs.py','tests/test_production_configs.py','tests/test_smoke.py::test_tdl_smoke','-p','no:cacheprovider']
        output=run(cmd,wt);(receipt.parent/(receipt.stem+'_tests.txt')).write_text(output+'\n')
        run(['git','commit','-m','CR R3M11: import NO_GO and add fixed-CAP / finite-span controls'],wt)
        result.update(status='LOCAL_COMMIT_CREATED',commit=run(['git','rev-parse','HEAD'],wt),tests_command=cmd,tests_output=output);save()
        if a.push:
            run(['git','push','origin',f'HEAD:refs/heads/{a.branch}'],wt)
            remote=run(['git','ls-remote','--heads','origin',a.branch],wt).split()[0]
            if remote!=result['commit']:raise RuntimeError('remote ref does not match local commit')
            result.update(status='REMOTE_BRANCH_PUSH_VERIFIED',remote_push_verified=True,remote_commit=remote);save()
    except Exception as e:
        result.update(status='STOPPED_WITH_EVIDENCE_PRESERVED',error=str(e));save();raise
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
