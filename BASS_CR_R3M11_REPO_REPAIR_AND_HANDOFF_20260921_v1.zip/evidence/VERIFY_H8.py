from pathlib import Path
import hashlib,json
root=Path('/mnt/data/cr_r3m11_work/imports/host_h8/HOST4_H8_FINAL_WORK')
rows=[]
for l in (root/'MANIFEST.sha256').read_text().splitlines():
 h,p=l.split('  ',1);a=hashlib.sha256((root/p).read_bytes()).hexdigest()
 rows.append({'path':p,'match':a==h});assert a==h,p
Path('/mnt/data/cr_r3m11_work/evidence/H8_IMPORT_VERIFICATION.json').write_text(json.dumps({'source_sha256':'8d9b3565f278f07f8d1aaa103910725bca6df4ce252247208e7492aff601ebd8','payloads':len(rows),'all_match':all(r['match'] for r in rows),'CRC':'PASS','rows':rows,'scientific_rerun':False},indent=2))
print(len(rows),'verified')
