#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/runtime_snapshot"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH=.
python -m pytest -q tests/test_core.py tests/test_r3m11.py tests/test_r3m11_jobs.py tests/test_production_configs.py tests/test_smoke.py::test_tdl_smoke tests/test_gpu_runtime.py -p no:cacheprovider
