# R4AH 전달 재개 계약

현재R4AH의온라인게시/백업은미실행이다. 사용자승인은유효하지만현재GitHub create_tree와두cloud의upload_file action은노출되지않았고직접git도DNS실패였다. 과거R4AG백업ID나과거성공을R4AH의새성공으로복사하지않는다.

1. R4AH package/validation/detached receipt의실제SHA/크기를확인한다. 새package의바이트검증은계산재실행이아니다.
2. GitHub cosmosapjw-quantum/bass_cr의research/r4q-gap-closure-20261001 HEAD/tree를다시읽는다. 이번마지막read는0d7bdbe76dc35d38668d750e6312919cecb09144/16c687b2205dc0ac680fe01bda563c4b2547d371이다. 다르면실제diff를읽고다른source변경을덮지않는다.
3. publication/FILES.json의새경로만create-only로게시한다. source/test/docs의28이전R4AF,27이전R4AG,18이전R4AD등과이번mapping은별도다. 원27-file R4AG mapping은r4ag/publication/에그대로보존했다. 이번패키지전체는실행가능하지만개별코드몇개만Git에넣었다고필수입력/부모근거동기화완료라부르지않는다. force/newbranch/mainmerge금지.
4. Drive parent=1pkohlay5eIfFJsBwPZ_yn2jIZONZjesI. Dropbox directory=ns:183516487//bianchi/BASS_CR_R3M10_LOCAL_REPRODUCTION_PACKAGE_20260921_v1/provenance/NCP_F1_DUAL_BACKUPS/. 동일명충돌을확인하고새파일로업로드한다. 두provider실제완료응답/ID/name/size가있어야R1을닫는다. 체크섬이반환되지않으면미확인으로기록한다.
5. 새commit/tree/coverage/remoteIDs/실패분류를detachedreceipt에기록한다. 업로드후불필요한재다운로드를하지않는다. restore검증없이는RESTORE_VERIFIED=false다.
6. 전달경로복구를위해원자적분/완료suite를반복하지않는다. R4AH의과학상태는NCP실제m64결과반환전까지BLOCKED/NOT_EXECUTED다.
