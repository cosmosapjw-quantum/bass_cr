# R4AH 첫 shifted runtime: 실제 자원 차단과 좁은 실행 인계

2026-10-03. 상태: **R4AH_RUNTIME_PREPARATION_BLOCKED**. R4AH의원자pilot은완료되지않았다. 새수학/미분/적분certificate는없다. 이번닫힌산출물은실제준비시도기록,원기능을변경하지않는m64전용launcher,신규launcher시험,외부실행/반환계약이다.

## 회수와 실제 실행

R4AG archive 2,322,003bytes의SHA256은05160e18660bf0866320d3e128e79b0efdd39b0db79904b3f333e9f27dd48ff8과일치했다. CRC와90개payload SHA가일치하며source/input49pin을보존했다. 원격read는0d7bdbe76dc35d38668d750e6312919cecb09144/tree16c687b2205dc0ac680fe01bda563c4b2547d371로전달receipt와일치했다. 새remotecommit은아니다.

최소1worker의원R4AG `prepare`를실제한번시도했고exit1 `ContractError: available memory admission`으로종료했다. outputdirectory/native/BATCH/AUTHORIZATION은생성되지않았다. nativebuild/원자적분/실제승인/재시도는0이다. 이는과학methodFAIL이나새S정확도FAIL이아닌runtime자원blocker다.

실행직전독립관측snapshot: CPUquota4,affinity5CPU,메모리한도4,294,967,296bytes,사용량2,172,702,720bytes,가용headroom2,122,264,576bytes. 원1worker요구량2,415,919,104bytes에293,654,528bytes모자랐다. 이정확한숫자는prepare직전snapshot이며내부guard가다시관측한순간의값은오류메시지에없다. 둘을같은시각관측으로꾸미지않는다. 실제내부guard실패는stderr로확인된다.

Linux cgroup문서에서memory.current는cgroup및descendants의현재메모리사용량이며memory.max는hardlimit이다. 본프로젝트guard는min(hostMemAvailable,limit-current)를사용한다. 단순히전체RAM4GiB와2.25GiB요구량만비교해통과시키지않았다. 정책완화/테스트자원주입/다른프로세스종료/cache강제회수는수행하지않았다. 공식근거는PRIMARY_SOURCES.json에있다.

## 새 구현

source/m64_launch.py는R4AG과학코드와resourcepolicy를수정하지않는바깥launcher다. prepare와execute를분리하고실패가parentoutput생성전발생해도바깥session에REQUEST/PREPARATION_FAILED/stdout/stderr가남는다. exactBATCHSHA의별도승인이있을때만m64와max-new-nodes1을전달한다. all10승인을만들지않는다. wrapper의hash,sourceinputlock,root/outputbinding을고정하고기존승인/기존point폴더/소비된요청을거절한다.

반환에서는m64한점/pointtarget/fixture거절/D및M9미실행/globalceiling/두windowtotalnull을검사한다. parentcollect가실제원자payload의seal/cell/native/구간상계를검토한다. bundle은실패와부분출력까지create-onlyZIP+payloadSHA로보존하며실행은하지않는다.

원R4AG의r4ag/90개payload와49개sourceinputpin은바이트동일하다. 원center/M9/oldR8및R4Z~R4AGsuite를재실행하지않았다.

## 검증의 정확한 의미

새launcher시험33건통과. m64한점승인/cap,prepare만실행,자원실패기록,승인필수,hash변조/기존attempt/기존all10승인거절,잘못된/너무넓은/fixture반환거절,실패후collect금지,sourcepin,ZIPpath/symlink/create-only를검사했다. 핵심명령구성시험은실제RED→GREEN을관측했고다른시험은구현후추가검증이다. 전부를TDD라고부르지않는다.

성공경로시험은subprocess경계를mock한TEST_ONLY fixture다. 실제GMP/compiler/native/원자적분성공의증거가아니다. 원환경값을mock해실제과학실행을허용한적은없다. read-only audit는부모바이트와실패근거/상태분리/결과부재를확인하며독립원자실험이아니다.

## DB 및 과학 상태

DBv20은v19를복제한뒤별도runtime_attempt/source 테이블에이번준비차단근거만append한다. 기존current_research_gap_status와v19view전체13행은모두동일하게유지한다. G02를새롭게해결했다고표시하지않고과학적record_json도바꾸지않는다.

A1기존scopeCLOSED,A2PARTIAL,C0actualbindingPENDING. G02=UNRESOLVED,production=HOLD,capture=false,all_bound=OPEN,b_grid=NO_GO. actualshifted0,windowtotal=[null,null],M9/center/oldR8/D/V/oldsuite모두0이다. 다음scientificnode는여전히R4AH m64실제실행이다.

## 전달

이번현재도구discovery에서GitHub create_tree/create/write,GoogleDrive upload_file,Dropbox upload_file은노출되지않았다. installed/enabled여부와실제action노출을구분한다. 직접git ls-remote도github.com DNS해석실패였다. 새NCP실행연결은확인되지않았다. 따라서새원격게시/이중백업성공receipt를만들지않는다. 이전R4AG온라인백업은과거상태그대로다.

전체새package와새create-onlypatch/mapping,원R4AG27-filemapping을제공한다. 실제온라인상태는detachedDELIVERY_RECEIPT에서기록한다. 원격action이나NCP환경이열리지않은상태에서똑같은준비/감사를반복하지않고,NCP의한점결과반환을다음작업으로고정한다.
