# R4AG: stored-epoch shifted S와 정확 구간 stencil 조립

## 범위와 전제

새 원자적분을 하지 않는 R4AG의 산출물은 10개 기존 shifted 입력의 결합, one-shot 실행 adapter, read-only 반환 검증, 고정 두 R8의 정확 유리수 합산이다. R4AF의 한 점 정확도와 R4AE의 M9/Peano 근거를 재실행하지 않는다. 원자 단위 좌표는 a0, 시간은 ta=ħ/Eh, 속도는 a0/ta이며 C와 S는 무차원이다. SI phase는 m_e v_phys x_z/ħ−m_e v_phys² t/(2ħ)이다. Galilean prescribed-trajectory 모델의 이 단위 변환은 c나ħ를 임의로1로 놓는 새 가정이 아니다.

same-center Gram은 기존 범위에서 상수다. X=[[0,C],[C†,0]]는18x18 full-cross 행렬이고 C는9x9이다. 원시 저장 TP/PT를 투영하지 않는다. 새 계산의 수학적 X를 이 블록형식으로 정의하는 것은 과거 원시값을 대칭화하는 것과 다르다.

## 실제 시각에서 이상적 시각으로의 변환

표본 j에서 저장FP64 값은 float의 정확한 이진 유리수로 해석한다. z_j와 t_j는 각 원본 GEOMETRY.json의 actual_z_hex/time_hex와 함께 결합한다. t_j를 z_j/v로 새로 생성하지 않는다.

δ_j=(v z_j−v²t_j)/2이면 C_actual,j=exp(iδ_j) C_ideal,j다. 따라서 C_ideal,j=exp(−iδ_j) C_actual,j이다. 이 부호를 독립 고정밀 복소 exponential fixture로 검사했다.

표본의 complex rectangle enclosure에서 정확 rational midpoint M_j와 Frobenius full-cross 반경 ε_j를 만든다. 복소위상 exp(−iδ_j)의 rational center q_j와 modulus error η_j를 만들면

||X_ideal,j−X(q_j M_j)||F ≤ ε_j+η_j ||X(M_j)||F.

증명은 exp(−iδ_j)의 절댓값이 정확히1이라는 사실과 삼각부등식이다. 반올림된 q_j의 norm을1이라고 가정하지 않는다. 원점에서 cos는24차, sin은23차 다항식으로 정확 rational 계산하고, |δ|≤1에서 각각 |δ|25/25!, |δ|24/24!의 Lagrange 나머지를 사용한다. 실제 δ는 이 범위 안이지만 범위를 벗어난 입력은 거절한다. sqrt 상계는 integer isqrt와 제곱부등식으로 위쪽 반올림한다. phase truncation/해당 sqrt 반올림은 η에 이미 포함된다.

## 고정 가중합

H=1/64 또는1/128이고 h_i=H/2^i, a_i=(-1,84,-1344,4096)/2835다. w_(i,+)=a_i v/(2h_i), w_(i,−)=−w_(i,+)를 원본 STENCIL 파일과 exact 비교한다. 계수·간격·최종1e−12 ta^-1 조건은 변하지 않는다.

새 rational midpoint T_H=Σ_j w_j X(q_j M_j)와

ε_H = Σ_j |w_j| ε_j + Σ_j |w_j| η_j ||X(M_j)||F + vH^8 M9/(4096·9!)

를 반환한다. 상수/곱/합을 끝까지 Fraction의 integer numerator/denominator로 계산하므로 이 rational 가중합의 별도 rounding remainder는0이다. 이는 초월함수나 입력적분 오차가0이라는 뜻이 아니다. 입력평가 오차는 ε_j, phase 표현의 오차는 η_j, 도함수나머지는 상속된 Peano 항에 남는다. 이 단계는 옛FP64/fsum 미분값의 roundoff를 인증하지 않고, 다른 새 rational-center 인증을 만든다.

두 window는 각각8표본이고6표본이 공통이어서 합집합은10개다. 필요한8개 중 하나라도 없으면 midpoint/total_upper/within_final_target은 null이다. 사용 가능한 다른 window의 계산은 독립적으로 허용한다. 잘못된 unit/norm/candidate/geometry/epoch/bound_type, 중복/중심점, test fixture의 physical import는 거절한다. 표본 정확도 목표1e−16과 최종1e−12는 별도 검사다.

기존M9의 hash는95df9f4ba47056e7d79a72dd95fb4ad09996cac7f8338122981e45bb80c01daf이다. 사용 전에 같은 candidate,b,v,ordered channel,ideal epoch,domain을 확인하며 숫자표시3.884e6에서 상계를 다시 만들지 않고 원래의 rational Peano 상계를 읽는다.

## 실행과 근거의 범위

point_engine.py는 불변R4AF v2의 Gaussian core를 새 shifted adapter로 복사한 것이다. low-level provider/complex/quadrature/native C++ 및 dyadic/geometry는 원 manifest와 byte-identical이다. 기존 run_pilot.py를 monkeypatch하거나 소비된 계약의 z를 고치지 않는다. 새 geometry마다 cover와 complex pole 조건을 실제 engine 안에서 다시 검사한다. R4AG는 이 적분을 실행하지 않았으므로 shifted 결과를 예측하여 기록하지 않는다.

외부 one-shot은 prepare에서 관측한 affinity/quota/가용RAM/compiler/interpreter/dependency/library/native/output과 exact source/input에 묶인다. worker1~3와 별도coordinator CPU, serial node를 사용한다. timeout은 process group을 종료한다. FAILED/PARTIAL node는 자동 재시도하지 않는다. COMPLETED node만 hash/정확합산 검토 후 재사용한다. test-only resource fixture는 실제engine이 명시적으로 거절한다.

## 근거 상태와 출처

새 phase ball 및 rational 합성식은 이번 작업의 직접 유도이다. Python 공식fractions 문서는 Fraction(float)가 저장된float와 정확히 같은 값을 갖고 Decimal 문자열과 일반적으로 다름을 명시한다. https://docs.python.org/3.13/library/fractions.html . 이 성질만 이용하며 limit_denominator를 쓰지 않는다.

Open MPI 공식문서의CPU mapping/binding/oversubscription 구분은 후속NCP 최적화 참고일 뿐이다. https://docs.open-mpi.org/en/v5.0.4/man-openmpi/man1/mpirun.1.html . 이번 코드는 MPI를 실행하지 않으며64CPU 가속을 주장하지 않는다.

적분식/정칙성/M9/Gaussian 근거는 R4AD–R4AF의 pin된 문서와 결과를 사용한다. 새로운 shifted 실제 적분 및 최종 미분 정확도 인증은 NOT_RUN이다. G02 UNRESOLVED, production HOLD, capture false, all_bound OPEN, b_grid NO_GO를 보존한다.
