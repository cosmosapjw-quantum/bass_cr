# R4AG → NCP/local Codex 실행 지시

역할: 전달된 코드를 처음부터 재구현하지 말고, 현 환경 준비·좁은 검토·승인된 실행·반환을 수행한다. 다음 actual node는 R4AH_SHIFTED_S_RUNTIME_PILOT이며 첫 입력은 m64(z=-2049/64 a0)다. R4AF 중심점/M9/oldR8/완료된 과학 suite를 반복하지 않는다.

## 1. 읽기 및 준비

`python verify_delivery.py .`로 이 release의 bytes를 확인한다. `REPORT_KO.md`, `DERIVATION_KO.md`, `SOURCE_INPUT_LOCK.json`, `inputs/NODE_REGISTRY.json`, `contracts/EXECUTION_POLICY.json`을 읽는다. Linux cgroup-v2, Python≥3.11 + numpy/scipy/mpmath, C++17, GMP/GMPXX 개발 헤더가 필요하다. pytest는 변경영역 검사에만 필요하다.

원본을 보존하고 새 작업위치에 추출한다. compiler/backend를 바꾸면 새 native가 생기며 그 identity를 별도결합한다. 다음 prepare는 source 검증·실제환경 관측·native 빌드만 하며 원자적분을 실행하지 않는다.

```sh
cd /absolute/path/to/extracted/R4AG
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
python source/batch.py prepare --output /absolute/new/r4ah_batch --workers 3
```

실제가용CPU≥workers+1, available RAM≥workers×512MiB+1792MiB가 필요하다. 조건을 만족하지 못하면 작업을 멈추고 실제환경을 보고한다. 임의로수치를고쳐admission하지않는다.64CPU/128GB는관측값으로대체한다. 기본은serial10nodes, point당1~3workers이며MPI/NUMA/SIMD최적화는이정확성기준을유지한별도작업이다.

prepare가 출력하는 BATCH.json의 exact SHA, ENVIRONMENT, BUILD/LDD/dependency 정보를 반환하면 네이티브실행전좁은검토가가능하다. 자동승인표시를추가하지않는다.

## 2. 명시적으로 승인한 범위만 실행

다음 authorize는 사용자/실행 owner가 정확한 batch SHA와 native scope를 승인한 경우에만 실행한다. `all10`은10개노드의각각1회승인이지자동10점실행이아니다. `--nodes m64`만 승인할 수도 있으나 이후확장은별도새batch/승인계약이필요하다. 이 패키지에는 소비된 실제승인파일을 넣지 않았다.

```sh
B=/absolute/new/r4ah_batch/BATCH.json
H=$(sha256sum "$B" | cut -d ' ' -f1)
python source/batch.py authorize --batch "$B" --confirm-sha256 "$H" --nodes all10 --authorize-native
python source/batch.py run --batch "$B" --max-new-nodes 1
python source/batch.py collect --batch "$B" --output /absolute/new/r4ah_batch/PILOT_RETURN.json
```

첫m64완료후확인: source/native/geometry/epoch/cover/pole/cell완결,point반경≤1e−16,실행오류0.결과를D에맞춰보정하지않는다.한점이실패하거나정확도미달이면추가계산을멈추고FAILURE/부분기록을반환한다.

전체10점실행이승인돼있고첫pilot이수락된뒤에만:

```sh
python source/batch.py run --batch "$B" --max-new-nodes 9
python source/batch.py collect --batch "$B" --output /absolute/new/r4ah_batch/FINAL_STENCIL_RETURN.json
```

완료m64는read-only검토후재사용되며재실행하지않는다.실패/중단폴더는자동복구하지않는다.새수동recovery계약은마지막완료cell/미완료범위와새source/output을구체적으로결합해야한다.본코드는그부분실행복구를자동구현하지않았으므로기존attempt를리셋하지않는다.

## 3. 반환

BATCH/AUTHORIZATION/ENVIRONMENT,모든nodecontract,buildcompiler/library/nativeidentity,각node RESERVATION/CELL_CERTIFICATES/GAUSS_RULES/NATIVE_INPUT/NATIVE_DISPATCH/worker intervals+stderr/S_ENCLOSURE/S_ONLY_SEAL/RESULT/RETURN_MANIFEST/COMPLETED 또는FAILURE,collect출력과실제wall/RSS를모아create-only ZIP과SHA manifest로반환한다. 단순요약만보내지않는다. 반환검토는read-only이며원자적분을다시하지않는다.

결론은샘플·epoch·구간가중합·Peano항을합한두window의오차인증까지만이다. D/fullH/전궤도/capture/source/basis/b/energy/rate승인은별도다. Git현HEAD를읽고새경로만samebranch non-force게시한다.허용되지않는이전R4AD안전성차단mutation을우회하지않는다.두provider ACK가있을때만이중backup완료로기록한다.
