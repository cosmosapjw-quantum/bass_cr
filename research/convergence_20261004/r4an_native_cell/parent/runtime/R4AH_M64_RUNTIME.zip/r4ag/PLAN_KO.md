# R4AG 실행 계획

목표: 두 고정 R8 window의 10개 저장 geometry/epoch를 결합하는 batch adapter, 정확 유리수 구간/ball stencil 조립기, 외부 one-shot 실행 및 반환 계약을 구현한다.

1. 원본 AF의 107 payload hash와 AD에서 선택한 10개 S-only 입력을 회수한다. 원본 결과/코드/계약은 수정하거나 실행하지 않는다.
2. 계약·scope·단위·epoch·누락·identity 거절과 합산의 해석적 fixture를 먼저 만들고, 실제 실패를 기록한 뒤 구현한다.
3. 이전 Gaussian provider와 native 소스는 byte-identical vendor로 재사용한다. 새 point runner만 등록된 shifted geometry와 새 출력·source·native·자원 계약을 받는다. 모든 native science cap은 이 세션에서는 0이다.
4. 정확 rational phase transport와 가중합으로 새 midpoint/certified norm radius를 반환한다. M9/Peano는 원 hash와 적용영역을 검증해 재사용하며 새로 계산하지 않는다. 미완료 window total은 null이다.
5. 새 시험, 반환자료 read-only checker, DBv19 append-only 근거, 보고서/DAG/실행·반환 handoff, create-only package를 생성한다. NCP10점 결과는 NOT_RUN이다.

외부 실행은 prepare에서 실제 환경을 관측/빌드하고, 별도 authorize 명령에 batch hash와 노드목록을 명시한 뒤에만 가능하다. serial-node, node당 worker 1~3, 추가 최적화 없음. 실패/timeout/중단 node는 자동 재시도하지 않으며 완료 node는 해시 확인 후 재사용한다.
