# BASS_CR R4AG 실행 보고서

2026-10-03 KST. R4AG_SHIFTED_S_CERTIFIED_STENCIL_ASSEMBLY_CONTRACT를 구현·fixture검증·외부실행계약까지 닫았다. 실제10점 원자적분은 실행하지 않았다. 따라서 numerical stencil certificate와 두window total_upper는 여전히null이다.

## 실제 산출

원R4AF archive dde12ae9bd21a7f9129eb59829238fa72d5d8a32e0a290d1cb500e4ceb3c22a7의107payload hash를 확인했다. 원R4AD archive에서 shifted10개의GEOMETRY/S 원본20개와 고정stencil2개를 추출했고, z/time의FP64 hex와 정확유리수,기존raw/full/task/S/geometry identity를 보존했다. 원적분·D·이전R8을재계산하지않았다.두window는각각8표본이고6개를공유한다.

source/common.py, runtime_contract.py, point_engine.py, batch.py, collect.py, stencil.py, independent_review.py의7새모듈을구현했다. Gaussian provider/complex_box/quadrature/native C++와dyadic/geometry6개는원manifest와byte-identical이다. point_engine은새shiftedguard/output/source/native/resource binding을사용하며소비된R4AF계약을고치지않는다.

prepare는실제Linux자원과compiler/interpreter/dependency/library/native/output을관측·결합한다. authorize는정확batchSHA와노드목록의명시적승인을요구한다. run은node별one-shot과동시coordinator거절,process-group timeout,FAILED/PARTIAL자동재시도거절,완료node의검토후재사용을구현한다. collect는manifest/seal/nativepartition/DONE·정확endpoint합·Gaussian나머지부등식·상계·epoch·단위를검토한뒤stencil을조립한다.

## 이론과 산술

δ_j=(vz_j−v²t_FP,j)/2이며idealC=exp(−iδ_j)actualC다. actual의정확midpointM_j와full-cross반경ε_j,phasecenterq_j와오차η_j에서ideal반경≤ε_j+η_j||X(M_j)||F다. cos24차/sin23차의정확rational Taylor와Lagrange bound로phase를감싼다.

새stencilmidpoint=Σw_j X(q_j M_j),반경=Σ|w_j|ε_j+Σ|w_j|η_j||X(M_j)||F+상속Peano다. 합산은정확rational이라별도가중합roundoff항0이다. 입력·phase·제곱근·절단오차가0인것은아니다. 원래h/weights/1e−12ta^-1기준은변하지않는다. actual8개중누락이있으면midpoint와total/within_target은null이다. 이번현재출력에는10point모두NOT_RUN이다.

## 검증

새시험49건통과. 원본입력identity/hex/channel/단위,누락·중복·중심점거절,0~8차행렬다항식fixture,독립복소phase부호검사,구간방향성,widebound실패,fixture격리,source/output/권한/소비context,가용메모리/CPUreserve,실제compiler빌드와read-only빈반환을검사했다.일부공개seam은실제RED→GREEN기록이며모든시험이TDD였다고말하지않는다.

독립read-only검토133조건통과.다른Lagrange다항식구성으로가중치와다항식응답을확인하고10개exact입력,원vendorhash,두window공유범위,누락total의null을검사했다. 별도인간/에이전트검토나실제10점수치검증은아니다.

최초통합시험의5setup오류는동일자원원인이다.당시가용메모리1982025728bytes가worker1+reserve의2415919104bytes보다작아원자계산및native빌드전에차단됐다. production admission을완화하지않았다.남은계약시험에서는관측자원경계만8GiB test-fixture로대체했으며실제compiler와filesystem을사용했다.이test-only환경계약은point_engine에서명시적으로실행불가다.따라서실제NCP자원승인을얻었다고보고하지않는다.

## 상태

R4AG=CLOSED_PORTABLE_IMPLEMENTATION_AND_EXECUTION_RETURN_CONTRACT. 실제newshifted/nativepoint0,M9/center/oldR8/D/Vother/old과학suite0이다. DBv19에append하고v18전체view와다른12행은그대로다. G02UNRESOLVED,productionHOLD,capturefalse,all_boundOPEN,b_gridNO_GO. C0 actualreceiverbinding은별도pending이다.

새유리수합산기와반환검토코드는준비됐지만실제shiftedresult와native배치의end-to-end성공은NOT_RUN이다. 환경특화MPI/NUMA/SIMD최적화나64CPU가속도수행하지않았다. 전체H/D/전궤도/capture/physicalsource/rate gate는열지않는다.

## 다음 한 단계

R4AH_SHIFTED_S_RUNTIME_PILOT. NCP_START_HANDOFF_KO.md대로실제NCP환경을준비하고exactBATCHSHA와첫m64(z=-2049/64a0)의native실행을승인한뒤한점만반환한다. source/geometry/pole/cover와1e−16point목표가수락되기전에는나머지9점을돌리지않는다. 기존M9와R4AF중심점은재실행하지않는다.

## 전달

전체코드/불변vendor/필수입력/고정Peano근거/시험/외부계약/DBv19/보고서는새ZIP에있다. Git의실제게시범위와두cloud의성공ACK는detached DELIVERY_RECEIPT를정본으로한다. 원R4AA379/R4AD/R4AE/R4AF의미게시개별mapping을이번작업으로소급완료하지않는다.원격ACK와RESTORE검증을구별한다.
