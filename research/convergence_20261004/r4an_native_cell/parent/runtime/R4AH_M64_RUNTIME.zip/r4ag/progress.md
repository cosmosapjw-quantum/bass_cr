Plan: PLAN_KO.md
Task1: complete,107AFpayloads+10shiftedinputs
Task2: complete,49newtests
Task3: complete,133read-onlychecks
Task4: complete,DB19+run/returncontracts
Actual10pointintegrals: NOT_RUN
