from pathlib import Path
from fractions import Fraction as F
import copy,pytest
from common import ROOT,read,ContractError
from runtime_contract import validate_registry,choose_resources

def test_recovered_shifted_inputs_are_verified_not_regenerated():
    rows=validate_registry(read(ROOT/'inputs/NODE_REGISTRY.json'),ROOT)
    assert len(rows)==10
    assert rows[0]['node_id']=='m64'
    assert all(F(r['z_a0'])!=F(-32) for r in rows)

def test_quota_includes_coordinator_reserve():
    env={'affinity':[0,1,2,3],'quota':'2','memory_limit':4*1024**3,'memory_available':3*1024**3}
    with pytest.raises(ContractError,match='quota'):choose_resources(env,2)
from runtime_contract import observe_environment,prepare_batch,validate_batch,authorize_batch,validate_point_contract
from common import sha,write_new,canonical

def test_actual_hex_change_is_detected():
    r=read(ROOT/'inputs/NODE_REGISTRY.json');r['nodes'][0]['time_hex']='-0x1.0000000000000p+3'
    with pytest.raises(ContractError):validate_registry(r,ROOT)

def test_saved_source_hash_change_is_detected():
    r=read(ROOT/'inputs/NODE_REGISTRY.json');r['nodes'][2]['S_sha256']='0'*64
    with pytest.raises(ContractError,match='pin'):validate_registry(r,ROOT)

def test_node_order_and_duplicates_rejected():
    r=read(ROOT/'inputs/NODE_REGISTRY.json');r['nodes'][3]=r['nodes'][2]
    with pytest.raises(ContractError):validate_registry(r,ROOT)

def test_memory_checks_available_not_only_installed():
    e={'affinity':[0,1,2,3],'quota':'4','memory_limit':128*1024**3,'memory_available':1024**3}
    with pytest.raises(ContractError,match='memory'):choose_resources(e,3)

def test_resources_reserve_coordinator_and_no_oversubscription():
    e={'affinity':[4,5,6,7],'quota':'4','memory_limit':8*1024**3,'memory_available':8*1024**3}
    p=choose_resources(e,3);assert p['worker_cpu_ids']==[4,5,6] and p['coordinator_cpu_id']==7 and p['parallel_nodes']==1

@pytest.mark.parametrize('n',[0,4,True])
def test_unqualified_workers_rejected(n):
    with pytest.raises(ContractError):choose_resources({'affinity':list(range(64)),'quota':'64','memory_limit':128*1024**3,'memory_available':128*1024**3},n)

def test_prepare_requires_absolute_new_path(tmp_path):
    with pytest.raises(ContractError,match='absolute'):prepare_batch('relative',1)
    with pytest.raises(ContractError,match='new output'):prepare_batch(str(tmp_path),1)

@pytest.fixture(scope='module')
def prepared(tmp_path_factory):
    # Resource observation is the external boundary. No native integral is
    # launched by these tests; compiler and filesystem operations remain real.
    import runtime_contract
    environment=observe_environment()
    environment.update(memory_limit=8*1024**3,memory_available=8*1024**3,
                       test_only_resource_fixture=True)
    p=tmp_path_factory.mktemp('r4ag_new_binding')/'batch'
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(runtime_contract,'observe_environment',lambda: environment.copy())
        yield prepare_batch(p,1)

def test_preparer_does_not_run_any_geometry(prepared):
    b=validate_batch(prepared)
    assert len(b['nodes'])==10 and not list((prepared.parent/'runs').iterdir())
    assert not (prepared.parent/'AUTHORIZATION.json').exists()
    assert b['status']=='PREPARED_NOT_AUTHORIZED_NOT_EXECUTED'

def test_authorization_requires_exact_batch_hash(prepared):
    with pytest.raises(ContractError,match='SHA'):authorize_batch(prepared,'0'*64,['m64'])

def test_explicit_one_point_authorization_does_not_authorize_others(prepared):
    auth=authorize_batch(prepared,sha(prepared),['m64']);b=read(prepared)
    c,a=validate_point_contract(b['nodes'][0]['contract'],auth)
    assert c['z']=='-2049/64'
    with pytest.raises(ContractError,match='not authorized'):validate_point_contract(b['nodes'][1]['contract'],auth)
    with pytest.raises(FileExistsError):authorize_batch(prepared,sha(prepared),['all10'])

def test_readonly_empty_collection_keeps_both_totals_null(prepared,tmp_path):
    from collect import collect
    out=tmp_path/'empty.json';r=collect(prepared,out)
    assert r['available_nodes']==0 and all(w['total_upper'] is None for w in r['windows'])

def test_partial_reservation_is_not_replayed(prepared):
    from batch import run_batch
    b=read(prepared);out=Path(b['nodes'][0]['output']);out.mkdir();write_new(out/'RESERVATION.json',{'state':'STARTED'})
    with pytest.raises(FileExistsError):validate_point_contract(b['nodes'][0]['contract'],prepared.parent/'AUTHORIZATION.json')
    with pytest.raises(ContractError,match='partial'):run_batch(prepared)
    assert not (out/'COMPLETED.json').exists()

def test_dynamic_loader_override_is_refused(monkeypatch):
    monkeypatch.setenv('LD_PRELOAD','/tmp/not-a-verified-library.so')
    with pytest.raises(ContractError,match='loader'):observe_environment()


def test_simulated_resource_contract_cannot_launch_engine(prepared):
    from point_engine import run
    b=read(prepared)
    with pytest.raises(ValueError,match='SYNTHETIC_RESOURCE_FIXTURE_NOT_EXECUTABLE'):
        run(b['nodes'][0]['contract'],prepared.parent/'AUTHORIZATION.json')
    assert not list((prepared.parent/'runs').glob('*/S_ENCLOSURE.json'))
