from fractions import Fraction as F
import pytest
from stencil import windows, transport_center

def test_frozen_windows_have_exactly_eight_nodes_each():
    w=windows()
    assert len(w)==2, 'both inherited R8 windows must be present'
    assert all(len(x['nodes'])==8 for x in w)

def test_identity_epoch_transport_is_exact():
    entries=[{'re':['1','1'],'im':['2','2']}]*81
    assert transport_center(entries,F(0))==([('1','2')]*81,F(0),F(0))

import copy
from common import ROOT, read, ContractError, CANDIDATE
from stencil import assemble_packets,sqrt_upper,interval,phase_midpoint,inherited_truncations

def reg():return read(ROOT/'inputs/NODE_REGISTRY.json')

def fixture_packet(row,value=F(0),radius=F(0),imag=F(0)):
    v=F(row['v_a0_per_ta']);z=F(row['z_a0']);t=F(row['time_ta'])
    return {'node_id':row['node_id'],'candidate':CANDIDATE,'geometry_sha256':row['geometry_sha256'],'unit':'1','norm':'FROBENIUS_FULL_CROSS','matrix_shape':[9,9],'epoch':'ACTUAL_STORED','bound_type':'DIRECTED_INTERVAL_ENCLOSURE','fixture':True,'epoch_offset':str((v*z-v*v*t)/2),'entries':[{'re':[str(value-radius),str(value+radius)],'im':[str(imag-radius),str(imag+radius)]}]*81}

def test_missing_samples_remain_unknown():
    r=assemble_packets(reg(),[],fixture=True)
    assert all(w['total_upper'] is None and w['within_final_target'] is None and len(w['missing_nodes'])==8 for w in r['windows'])

@pytest.mark.parametrize('degree',range(9))
def test_complete_exact_polynomial_reaches_true_derivative(degree):
    rr=reg();packets=[]
    for row in rr['nodes']:
        row['time_ta']=str(F(row['z_a0'])/F(row['v_a0_per_ta'])) # analytic fixture, not a real event
        x=F(row['offset_a0']);packets.append(fixture_packet(row,x**degree))
    r=assemble_packets(rr,packets,fixture=True)
    truth=F(rr['nodes'][0]['v_a0_per_ta']) if degree==1 else F(0)
    for w in r['windows']:
        assert all(F(a)==truth and F(b)==0 for a,b in w['midpoint'])
        assert w['arithmetic_upper']=='0'
        assert w['status']=='SYNTHETIC_ONLY'
        assert w['within_final_target']
    assert r['physical_source_admission'] is False

def test_eight_samples_close_only_their_window():
    rr=reg();p=[fixture_packet(row) for row in rr['nodes'] if abs(F(row['offset_a0']))!=F(1,1024)]
    r=assemble_packets(rr,p,fixture=True)
    assert r['windows'][0]['within_final_target'] is True
    assert r['windows'][1]['total_upper'] is None
    assert len(r['windows'][1]['missing_nodes'])==2

def test_wide_valid_intervals_are_not_accuracy_pass():
    rr=reg();r=assemble_packets(rr,[fixture_packet(row,radius=F(1,10**8)) for row in rr['nodes']],fixture=True)
    assert all(not w['within_final_target'] for w in r['windows'])

@pytest.mark.parametrize('field,value',[('unit','Eh'),('norm','SPECTRAL'),('epoch','IDEAL'),('bound_type','EMPIRICAL_DIFFERENCE'),('candidate','x'),('geometry_sha256','0'*64),('matrix_shape',[18,18]),('epoch_offset','1/2')])
def test_wrong_packet_semantics_rejected(field,value):
    rr=reg();p=fixture_packet(rr['nodes'][0]);p[field]=value
    with pytest.raises(ContractError):assemble_packets(rr,[p],fixture=True)

def test_duplicate_node_rejected():
    rr=reg();p=fixture_packet(rr['nodes'][0])
    with pytest.raises(ContractError,match='duplicate'):assemble_packets(rr,[p,p],fixture=True)

def test_central_result_not_a_shifted_sample():
    rr=reg();p=fixture_packet(rr['nodes'][0]);p['node_id']='center'
    with pytest.raises(ContractError,match='unknown'):assemble_packets(rr,[p],fixture=True)

def test_fixture_cannot_be_imported_as_real():
    rr=reg();p=fixture_packet(rr['nodes'][0])
    with pytest.raises(ContractError,match='fixture'):assemble_packets(rr,[p],fixture=False)

@pytest.mark.parametrize('value',[[1.0,2.0],['2','1'],{'denominator_power2':128,'lower_numerator':'0','upper_numerator':'1'}])
def test_bad_endpoint_encoding(value):
    with pytest.raises(ContractError):interval(value)

def test_phase_inverse_sign_against_independent_high_precision():
    import mpmath as mp
    with mp.workdps(150):
        delta=F(1,100);a,b,err=phase_midpoint(delta)
        av=mp.mpf(a.numerator)/a.denominator;bv=mp.mpf(b.numerator)/b.denominator;er=mp.mpf(err.numerator)/err.denominator
        assert abs(mp.e**(-mp.j/100)-(av+mp.j*bv))<=er
        assert b<0

def test_sqrt_upper_exact_and_directional():
    assert sqrt_upper(F(4))==2
    for q in (F(2),F(1,3),F(1,10**90)):
        s=sqrt_upper(q);assert s*s>=q and (s-F(1,2**256))**2<q

def test_known_truncation_remains_below_budget():
    assert all(x<F(1,10**13) for x in inherited_truncations().values())
