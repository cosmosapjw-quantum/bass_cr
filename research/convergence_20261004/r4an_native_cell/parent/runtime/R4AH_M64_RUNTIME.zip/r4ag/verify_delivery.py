"""Read/hash release bytes only. No model import or scientific evaluation."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
m=json.loads((root/'MANIFEST.json').read_text());seen=set()
for x in m['files']:
    p=(root/x['path']).resolve()
    if not p.is_relative_to(root) or x['path'] in seen:raise SystemExit('invalid/duplicate manifest path')
    seen.add(x['path'])
    if p.stat().st_size!=x['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=x['sha256']:raise SystemExit('identity mismatch: '+x['path'])
print(json.dumps({'status':'ALL_PAYLOAD_HASHES_MATCH','files':len(seen),'scientific_evaluations':0}))
