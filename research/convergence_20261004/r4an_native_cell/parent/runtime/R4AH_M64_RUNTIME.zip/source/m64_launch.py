#!/usr/bin/env python3
"""R4AH single-point launcher. Inherited R4AG science/policy bytes stay unchanged.

prepare observes/builds via the parent, execute requires an exact BATCH hash
and authorizes only m64, and bundle exports all receipts/partial evidence.
A failed preparation/launch is durable and is never automatically retried.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'r4ag'
LOCK_SHA='9795d7c0bf930978d4383a7e35113f0b1b8da1d5b05ff43be96b9fa9a748530c'
CEILING={'G02':'UNRESOLVED','production':'HOLD','capture':False,'all_bound':'OPEN','b_grid':'NO_GO'}

class PilotError(ValueError):
    """Scope, identity or lifecycle violation. No automatic retry is allowed."""

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def _pairs(items):
    out={}
    for k,v in items:
        if k in out:raise PilotError('duplicate JSON key: '+k)
        out[k]=v
    return out

def load(path):
    def bad(x):raise PilotError('non-finite JSON: '+x)
    return json.loads(Path(path).read_text(),object_pairs_hook=_pairs,parse_constant=bad)

def write(path,obj):
    with Path(path).open('x') as f:
        json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)
        f.write('\n');f.flush();os.fsync(f.fileno())

def verify_parent(parent=PARENT):
    parent=Path(parent).resolve()
    lock=parent/'SOURCE_INPUT_LOCK.json'
    if sha(lock)!=LOCK_SHA:raise PilotError('inherited source/input lock changed')
    pins=load(lock)['pins']
    for name,digest in pins.items():
        p=(parent/name).resolve()
        if not p.is_relative_to(parent) or p==parent or sha(p)!=digest:
            raise PilotError('inherited source/input changed: '+name)
    return len(pins)

def execution_commands(parent,batch,confirmed_hash):
    if re.fullmatch(r'[0-9a-f]{64}',confirmed_hash) is None:raise PilotError('exact SHA256 required')
    parent=Path(parent);batch=Path(batch)
    if not parent.is_absolute() or not batch.is_absolute():raise PilotError('absolute bound paths required')
    cli=[sys.executable,str(parent/'source/batch.py')]
    return [
        cli+['authorize','--batch',str(batch),'--confirm-sha256',confirmed_hash,'--nodes','m64','--authorize-native'],
        cli+['run','--batch',str(batch),'--max-new-nodes','1'],
        cli+['collect','--batch',str(batch),'--output',str(batch.parent.parent/'PILOT_RETURN.json')],
    ]

def _call(cmd,session,label,timeout):
    """Synchronous subprocess boundary; whole process group is killed on timeout."""
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
    with (session/(label+'.stdout')).open('x') as out,(session/(label+'.stderr')).open('x') as err:
        proc=subprocess.Popen(cmd,stdout=out,stderr=err,env=env,start_new_session=True)
        try:return proc.wait(timeout=timeout)
        except BaseException:
            os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            raise

def resource_snapshot():
    """Read-only preceding snapshot, not a substituted admission observation."""
    result={'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'role':'PRECEDING_OBSERVATION_ONLY_NOT_GUARD_OVERRIDE'}
    for name in ('cpu.max','memory.max','memory.current','memory.events'):
        p=Path('/sys/fs/cgroup')/name
        result[name]=p.read_text() if p.exists() else None
    result['affinity']=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None
    return result

def prepare(session,workers):
    verify_parent()
    if type(workers) is not int or workers not in (1,2,3):raise PilotError('workers must be 1, 2 or 3')
    session=Path(session)
    if not session.is_absolute():raise PilotError('absolute new session path required')
    session=session.resolve()
    session.mkdir(exist_ok=False)
    write(session/'REQUEST.json',{'schema':'R4AH_M64_REQUEST_V1','scope':['m64'],'phase':'PREPARE_ONLY','parent':str(PARENT.resolve()),'source_lock_sha256':LOCK_SHA,'launcher_sha256':sha(__file__),'workers':workers,'global_ceiling':CEILING})
    write(session/'PRECEDING_RESOURCE_SNAPSHOT.json',resource_snapshot())
    command=[sys.executable,str(PARENT/'source/batch.py'),'prepare','--output',str(session/'batch'),'--workers',str(workers)]
    try:
        rc=_call(command,session,'prepare',150)
        if rc:raise PilotError('parent preparation failed; inspect prepare.stderr; no automatic retry')
        batch=session/'batch/BATCH.json'
        obj=load(batch)
        if obj['root']!=str(PARENT.resolve()) or obj['output']!=str(session/'batch'):
            raise PilotError('prepared parent/output binding')
        write(session/'PREPARED.json',{'batch':str(batch),'batch_sha256':sha(batch),'actual_authorization':False,'atomic_integrals':0})
        return {'status':'PREPARED_NOT_AUTHORIZED','batch_sha256':sha(batch)}
    except BaseException as e:
        write(session/'PREPARATION_FAILED.json',{'classification':'RUNTIME_PREPARATION_BLOCKED','exception_type':type(e).__name__,'message':str(e),'atomic_integrals':0,'automatic_retry':False,'global_ceiling':CEILING})
        raise

def _validate_session(session,confirmed_hash):
    verify_parent();session=Path(session).resolve()
    if (session/'PREPARATION_FAILED.json').exists():raise PilotError('failed preparation; use a new externally prepared session')
    prepared=load(session/'PREPARED.json');request=load(session/'REQUEST.json')
    batch=session/'batch/BATCH.json'
    if prepared['batch']!=str(batch) or prepared['batch_sha256']!=confirmed_hash or sha(batch)!=confirmed_hash:
        raise PilotError('confirmed BATCH identity mismatch')
    if request['scope']!=['m64'] or request['source_lock_sha256']!=LOCK_SHA or request['launcher_sha256']!=sha(__file__) or request['parent']!=str(PARENT.resolve()):
        raise PilotError('request/launcher scope changed')
    if (batch.parent/'AUTHORIZATION.json').exists():raise PilotError('existing authorization not accepted by first-launch wrapper')
    if any((batch.parent/'runs').iterdir()):raise PilotError('existing point attempt; recovery must be explicit')
    return session,batch

def execute(session,confirmed_hash,authorized):
    if authorized is not True:raise PilotError('explicit --authorize-native required')
    session,batch=_validate_session(session,confirmed_hash)
    commands=execution_commands(PARENT.resolve(),batch,confirmed_hash)
    write(session/'EXECUTE_REQUEST.json',{'schema':'R4AH_M64_EXECUTE_REQUEST_V1','batch_sha256':confirmed_hash,'authorized_nodes':['m64'],'max_new_nodes':1,'requested_scientific_attempts':1,'global_ceiling':CEILING})
    phase='authorize'
    try:
        for phase,command,timeout in zip(('authorize','run','collect'),commands,(60,1860,300)):
            rc=_call(command,session,phase,timeout)
            if rc:raise PilotError(f'{phase} failed with exit {rc}; all outputs retained')
        packet=load(session/'PILOT_RETURN.json')
        if packet.get('fixture') is not False or packet.get('D_read') is not False or packet.get('M9_recomputed') is not False or packet.get('physical_source_admission') is not False:
            raise PilotError('fixture or forbidden scientific claim in return')
        if packet['available_nodes']!=1 or [x['node_id'] for x in packet['per_node']]!=['m64']:
            raise PilotError('unexpected first-pilot scope')
        if not packet['per_node'][0]['point_target_met']:raise PilotError('point accuracy target not met')
        if len(packet['windows'])!=2 or any(w['total_upper'] is not None for w in packet['windows']):
            raise PilotError('single point cannot certify both complete stencils')
        if packet['global_ceiling']!=CEILING:raise PilotError('global ceiling changed')
        write(session/'PILOT_ACCEPTANCE.json',{'status':'M64_ONLY_RETURN_ACCEPTED','batch_sha256':confirmed_hash,'return_sha256':sha(session/'PILOT_RETURN.json'),'new_points':1,'remaining_points':9,'both_stencil_total_upper':[None,None],'global_ceiling':CEILING})
        return {'status':'M64_ONLY_RETURN_ACCEPTED','next':'RETURN_TO_RESEARCH_THREAD_BEFORE_REMAINING_9'}
    except BaseException as e:
        write(session/'EXECUTION_FAILED.json',{'phase':phase,'exception_type':type(e).__name__,'message':str(e),'scientific_evaluations':'UNKNOWN_INSPECT_RETAINED_NODE_EVIDENCE','automatic_retry':False,'global_ceiling':CEILING})
        raise

def bundle(session,output):
    """Byte export only; no collect, native execution, or source revalidation."""
    session=Path(session).resolve();output=Path(output)
    if not session.is_dir() or not output.is_absolute():raise PilotError('session and absolute new ZIP path required')
    output=output.resolve()
    if output.is_relative_to(session):raise PilotError('return ZIP cannot be inside its own source tree')
    paths=[]
    for p in sorted(session.rglob('*')):
        if p.is_symlink():raise PilotError('symlink in return tree')
        if p.is_file():paths.append(p)
    pins={str(p.relative_to(session)):sha(p) for p in paths}
    if 'RETURN_PAYLOAD_SHA256.json' in pins:raise PilotError('reserved manifest name in return tree')
    if not pins:raise PilotError('empty session')
    with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,p.relative_to(session))
        z.writestr('RETURN_PAYLOAD_SHA256.json',json.dumps({'schema':'R4AH_RETURN_BYTE_MANIFEST_V1','pins':pins},sort_keys=True,indent=2)+'\n')
    with zipfile.ZipFile(output) as z:
        if z.testzip() is not None:raise PilotError('ZIP CRC mismatch')
        for p,h in pins.items():
            if hashlib.sha256(z.read(p)).hexdigest()!=h:raise PilotError('return byte race/mismatch')
    return {'archive':str(output),'bytes':output.stat().st_size,'sha256':sha(output),'payloads':len(pins),'science_performed_by_export':0}

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='action',required=True)
    q=sub.add_parser('prepare');q.add_argument('--session',required=True);q.add_argument('--workers',type=int,default=1)
    q=sub.add_parser('execute');q.add_argument('--session',required=True);q.add_argument('--confirm-batch-sha256',required=True);q.add_argument('--authorize-native',action='store_true')
    q=sub.add_parser('bundle');q.add_argument('--session',required=True);q.add_argument('--output',required=True)
    a=p.parse_args()
    try:
        if a.action=='prepare':r=prepare(a.session,a.workers)
        elif a.action=='execute':r=execute(a.session,a.confirm_batch_sha256,a.authorize_native)
        else:r=bundle(a.session,a.output)
        print(json.dumps(r,sort_keys=True))
    except (PilotError,OSError,subprocess.SubprocessError) as e:
        print(f'{type(e).__name__}: {e}',file=sys.stderr);raise SystemExit(2)
if __name__=='__main__':main()
