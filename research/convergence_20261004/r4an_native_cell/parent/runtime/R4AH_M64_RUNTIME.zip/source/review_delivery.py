"""R4AH read-only audit, not an atomic rerun or a separate human review."""
import ast,hashlib,json,sqlite3,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=root/'r4ag';checks=[]
def check(name,cond):
    if not cond:raise AssertionError(name)
    checks.append(name)
m=load(parent/'MANIFEST.json')
# Support the exact parent manifest shape; inspect rather than infer.
pins=m['pins'] if 'pins' in m else m['files']
if isinstance(pins,list):pins={x['path']:x['sha256'] for x in pins}
for p,h in pins.items():
    if isinstance(h,dict):h=h['sha256']
    check('parent_byte:'+p,sha(parent/p)==h)
state=load(root/'FINAL_STATE.json');attempt=load(root/'evidence/PREPARE_RECEIPT.json')
check('actual_prepare_exit',attempt['returncode']==1)
check('guard_witness','available memory admission' in (root/'evidence/PREPARE.stderr').read_text())
check('preceding_snapshot_not_admitted',attempt['observation']['memory_available']<attempt['required_bytes'])
check('no_guard_change',not attempt['mutated_policy'] and not attempt['fixture_used'])
check('no_new_integral',state['actual_shifted_integrals']==0)
check('no_completed_point',(not list(root.glob('runtime*/runs/*/COMPLETED.json'))))
check('no_runtime_authorization',(not list(root.glob('runtime*/AUTHORIZATION.json'))))
check('not_closed',state['status']=='BLOCKED_RUNTIME_AVAILABLE_MEMORY')
check('null_stencils',state['full_stencil_total_upper']==[None,None])
check('new_tests_record','33 passed' in (root/'evidence/FINAL_LAUNCHER_TESTS.txt').read_text())
check('red_observed','1 failed' in (root/'evidence/RED_M64_LAUNCH.txt').read_text())
ast.parse((root/'source/m64_launch.py').read_text());checks.append('launcher_syntax')
a=sqlite3.connect('file:'+str(parent/'BASS_CR_SOURCE_DATABASE_20261003_v19.sqlite')+'?mode=ro',uri=True)
b=sqlite3.connect('file:'+str(root/'BASS_CR_SOURCE_DATABASE_20261003_v20.sqlite')+'?mode=ro',uri=True)
check('db_current_all13_unchanged',a.execute('SELECT * FROM current_research_gap_status ORDER BY gap_id').fetchall()==b.execute('SELECT * FROM current_research_gap_status ORDER BY gap_id').fetchall())
for (v,) in a.execute("SELECT name FROM sqlite_master WHERE type='view'"):
    check('db_view:'+v,a.execute(f'SELECT * FROM "{v}"').fetchall()==b.execute(f'SELECT * FROM "{v}"').fetchall())
check('db_integrity',b.execute('PRAGMA integrity_check').fetchone()[0]=='ok')
check('runtime_row_only',b.execute('SELECT count(*) FROM r4ah_runtime_attempts').fetchone()[0]==1)
a.close();b.close()
print(json.dumps({'status':'READ_ONLY_RUNTIME_AND_BYTE_AUDIT_PASS','checks':len(checks),'check_names':checks,'atomic_integrals':0,'is_independent_human_review':False,'does_not_establish':'actual NCP or numerical pilot success'},indent=2))
