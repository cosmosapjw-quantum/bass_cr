"""Changed-area launcher tests only. No inherited suite or atomic integral."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'source'))
import m64_launch as m

def test_exact_m64_only_authorization_and_one_node_cap():
    commands=m.execution_commands(Path('/parent'), Path('/session/batch/BATCH.json'), 'a'*64)
    assert len(commands)==3, 'prepare is not execute; authorize/run/collect required'
    assert commands[0][commands[0].index('--nodes')+1:] == ['m64','--authorize-native']
    assert '--confirm-sha256' in commands[0] and 'all10' not in str(commands)
    assert commands[1][commands[1].index('--max-new-nodes')+1] == '1'
    assert commands[2][2] == 'collect'

import json
import hashlib
import zipfile
import pytest

@pytest.mark.parametrize('value',['','a'*63,'G'*64, 'a'*65,'../unsafe'])
def test_sha_argument_is_exact(value):
    with pytest.raises(m.PilotError):m.execution_commands(Path('/p'),Path('/b/BATCH.json'),value)

def test_relative_paths_rejected():
    with pytest.raises(m.PilotError):m.execution_commands(Path('p'),Path('/b'), 'a'*64)

def test_real_parent_lock_bytes():
    assert m.verify_parent()==49

@pytest.mark.parametrize('workers',[0,4,True,-1])
def test_invalid_worker_profile_never_dispatches(tmp_path,monkeypatch,workers):
    monkeypatch.setattr(m,'_call',lambda *a:pytest.fail('must not launch'))
    with pytest.raises(m.PilotError):m.prepare(tmp_path/'no_create',workers)
    assert not (tmp_path/'no_create').exists()

def test_preparation_failure_retains_logs_and_has_no_authorization(tmp_path,monkeypatch):
    session=tmp_path/'test_only_prepare_failure'
    calls=[]
    def failed(cmd,path,label,timeout):
        calls.append(cmd)
        (path/(label+'.stderr')).write_text('available memory admission')
        return 1
    monkeypatch.setattr(m,'_call',failed)
    with pytest.raises(m.PilotError):m.prepare(session,1)
    f=m.load(session/'PREPARATION_FAILED.json')
    assert f['atomic_integrals']==0 and f['automatic_retry'] is False
    assert 'available memory' in (session/'prepare.stderr').read_text()
    assert len(calls)==1 and calls[0][2]=='prepare'
    assert not list(session.rglob('AUTHORIZATION.json'))
    with pytest.raises(FileExistsError):m.prepare(session,1)
    assert len(calls)==1

def _prepare_fake_boundary(tmp_path,monkeypatch):
    """Mock only the subprocess boundary. Never a production/runtime admission."""
    session=tmp_path/'TEST_ONLY_SYNTHETIC_SESSION'
    calls=[]
    def fake(cmd,path,label,timeout):
        calls.append((label,cmd))
        assert label=='prepare'
        b=path/'batch';b.mkdir();(b/'runs').mkdir()
        m.write(b/'BATCH.json',{'root':str(m.PARENT.resolve()),'output':str(b),'fixture':'TEST_ONLY_NO_NATIVE_EXECUTION'})
        return 0
    monkeypatch.setattr(m,'_call',fake)
    r=m.prepare(session,1)
    return session,r['batch_sha256'],calls

def _packet():
    # Boundary protocol sample only. Does not call the source's scientific API.
    return {'fixture':False,'D_read':False,'M9_recomputed':False,'physical_source_admission':False,
            'available_nodes':1,'per_node':[{'node_id':'m64','point_target_met':True}],
            'windows':[{'total_upper':None},{'total_upper':None}],'global_ceiling':m.CEILING.copy()}

def test_prepare_does_not_authorize_or_run(tmp_path,monkeypatch):
    s,h,calls=_prepare_fake_boundary(tmp_path,monkeypatch)
    assert [x[0] for x in calls]==['prepare']
    assert m.load(s/'PREPARED.json')['actual_authorization'] is False
    assert not (s/'EXECUTE_REQUEST.json').exists()

def test_explicit_approval_required(tmp_path,monkeypatch):
    s,h,_=_prepare_fake_boundary(tmp_path,monkeypatch)
    with pytest.raises(m.PilotError):m.execute(s,h,False)
    assert not (s/'EXECUTE_REQUEST.json').exists()

def test_hash_mismatch_blocks_before_any_launch(tmp_path,monkeypatch):
    s,h,calls=_prepare_fake_boundary(tmp_path,monkeypatch)
    with pytest.raises(m.PilotError):m.execute(s,'a'*64,True)
    assert len(calls)==1

def test_authorization_scope_cannot_inherit_all10(tmp_path,monkeypatch):
    s,h,calls=_prepare_fake_boundary(tmp_path,monkeypatch)
    m.write(s/'batch/AUTHORIZATION.json',{'authorized_nodes':['all10']})
    with pytest.raises(m.PilotError):m.execute(s,h,True)
    assert len(calls)==1

def test_existing_node_attempt_never_replayed(tmp_path,monkeypatch):
    s,h,calls=_prepare_fake_boundary(tmp_path,monkeypatch)
    (s/'batch/runs/m64').mkdir()
    with pytest.raises(m.PilotError):m.execute(s,h,True)
    assert len(calls)==1

def test_single_pilot_boundary_sequence_and_no_second_run(tmp_path,monkeypatch):
    s,h,calls=_prepare_fake_boundary(tmp_path,monkeypatch)
    def success(cmd,path,label,timeout):
        calls.append((label,cmd))
        if label=='collect':m.write(path/'PILOT_RETURN.json',_packet())
        return 0
    monkeypatch.setattr(m,'_call',success)
    r=m.execute(s,h,True)
    assert r['status']=='M64_ONLY_RETURN_ACCEPTED'
    assert [c[0] for c in calls]==['prepare','authorize','run','collect']
    assert m.load(s/'EXECUTE_REQUEST.json')['authorized_nodes']==['m64']
    assert m.load(s/'PILOT_ACCEPTANCE.json')['both_stencil_total_upper']==[None,None]
    with pytest.raises(FileExistsError):m.execute(s,h,True)
    assert len(calls)==4

@pytest.mark.parametrize('bad_case',['extra_node','wrong_node','wide','full_stencil','fixture','D_read','M9','physical','global'])
def test_invalid_first_return_rejected(tmp_path,monkeypatch,bad_case):
    s,h,_=_prepare_fake_boundary(tmp_path,monkeypatch)
    p=_packet()
    if bad_case=='extra_node':p['available_nodes']=2
    if bad_case=='wrong_node':p['per_node'][0]['node_id']='p64'
    if bad_case=='wide':p['per_node'][0]['point_target_met']=False
    if bad_case=='full_stencil':p['windows'][0]['total_upper']='0'
    if bad_case=='fixture':p['fixture']=True
    if bad_case=='D_read':p['D_read']=True
    if bad_case=='M9':p['M9_recomputed']=True
    if bad_case=='physical':p['physical_source_admission']=True
    if bad_case=='global':p['global_ceiling']['production']='PASS'
    def fake(cmd,path,label,timeout):
        if label=='collect':m.write(path/'PILOT_RETURN.json',p)
        return 0
    monkeypatch.setattr(m,'_call',fake)
    with pytest.raises(m.PilotError):m.execute(s,h,True)
    assert (s/'EXECUTION_FAILED.json').is_file()
    assert not (s/'PILOT_ACCEPTANCE.json').exists()

def test_run_failure_stops_before_collect_and_preserves_status(tmp_path,monkeypatch):
    s,h,_=_prepare_fake_boundary(tmp_path,monkeypatch);labels=[]
    def fake(cmd,path,label,timeout):
        labels.append(label);return 1 if label=='run' else 0
    monkeypatch.setattr(m,'_call',fake)
    with pytest.raises(m.PilotError):m.execute(s,h,True)
    assert labels==['authorize','run']
    assert m.load(s/'EXECUTION_FAILED.json')['scientific_evaluations'].startswith('UNKNOWN')

def test_return_bundle_is_create_only_and_exact(tmp_path):
    s=tmp_path/'failed_session';s.mkdir();(s/'error.log').write_bytes(b'actual failure evidence\n')
    out=tmp_path/'return.zip';r=m.bundle(s,out)
    assert r['science_performed_by_export']==0
    with zipfile.ZipFile(out) as z:
        a=json.loads(z.read('RETURN_PAYLOAD_SHA256.json'));data=z.read('error.log')
        assert a['pins']['error.log']==hashlib.sha256(data).hexdigest()
    with pytest.raises(FileExistsError):m.bundle(s,out)

def test_recursive_bundle_rejected(tmp_path):
    with pytest.raises(m.PilotError):m.bundle(tmp_path,tmp_path/'return.zip')

def test_symlink_bundle_rejected(tmp_path):
    s=tmp_path/'session';s.mkdir();(s/'link').symlink_to('/etc/hosts')
    with pytest.raises(m.PilotError):m.bundle(s,tmp_path/'return.zip')

def test_duplicate_json_and_nonfinite_rejected(tmp_path):
    p=tmp_path/'x.json'
    for txt in ('{"a":1,"a":2}','{"x":NaN}'):
        p.write_text(txt)
        with pytest.raises(m.PilotError):m.load(p)
