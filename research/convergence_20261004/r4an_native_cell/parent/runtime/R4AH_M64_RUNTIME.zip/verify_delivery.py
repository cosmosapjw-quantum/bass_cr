#!/usr/bin/env python3
"""Verify this release's bytes only. Never build or execute native code."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent).resolve()
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,digest in manifest['pins'].items():
    p=(root/name).resolve()
    if not p.is_relative_to(root) or p==root or p.is_symlink():raise SystemExit('UNSAFE_PATH: '+name)
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    if h.hexdigest()!=digest:raise SystemExit('SHA_MISMATCH: '+name)
print(json.dumps({'status':'ALL_RELEASE_PAYLOAD_SHA256_MATCH','files':len(manifest['pins']),'atomic_integrals':0}))
