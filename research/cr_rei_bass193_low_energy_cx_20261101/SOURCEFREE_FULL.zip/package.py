from pathlib import Path
import hashlib,json,zipfile,sys,tempfile,subprocess,os
ROOT=Path(__file__).resolve().parent
OUT=Path('/mnt/data')
SOURCE=OUT/'REI_F4_CCC_HHE_FIRST_COLLISION_20261031_FULL.zip'
ORIGINAL=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert ORIGINAL=='4f2682e5885040fa69f0fe05095505cb7724b2d84c4707af8e1a78c8db41cb52'
public=OUT/'BASS_CR_REI_BASS193_LOW_ENERGY_CX_SOURCEFREE_20261101.zip'
private=OUT/'BASS_CR_REI_BASS193_LOW_ENERGY_CX_SOURCE_INCLUSIVE_20261101.zip'
M=json.loads((ROOT/'MANIFEST.json').read_text())
paths=[Path(item['path']) for item in M['files']]+[Path('MANIFEST.json')]
with zipfile.ZipFile(public,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in paths: z.write(ROOT/p,p.as_posix())
with zipfile.ZipFile(public) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(paths)
 for x in M['files']:
  b=z.read(x['path']);assert hashlib.sha256(b).hexdigest()==x['sha256'] and len(b)==x['size']
with zipfile.ZipFile(private,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 z.write(public,public.name)
 z.write(SOURCE,'frozen_sources/'+SOURCE.name)
with zipfile.ZipFile(private) as z:
 assert z.testzip() is None
 assert hashlib.sha256(z.read('frozen_sources/'+SOURCE.name)).hexdigest()==ORIGINAL
# Source-free archive isolated cold-restoration, independent input supplied as file.
with tempfile.TemporaryDirectory(prefix='basscr-rei-cx-cold-') as t:
 t=Path(t)
 with zipfile.ZipFile(public) as z:z.extractall(t)
 proc=subprocess.run(['bash',str(t/'REPRODUCE.sh')],env={**os.environ,'REI_SOURCE_ZIP':str(SOURCE)},capture_output=True,text=True,timeout=45)
 if proc.returncode:
  print('REPLAY_FAIL',proc.stderr[-1200:]);sys.exit(2)
 for file in ['results/BASS193_H_HPLUS_CX_SOURCE_CONDITIONAL_192.csv','results/RESULT.json'] + ['figures/'+n for n in sorted((ROOT/'figures').iterdir()) for _ in ()]:
  a=(ROOT/file).read_bytes();b=(t/file).read_bytes();assert a==b,('REPLAY_BYTES',file)
 for f in sorted((ROOT/'figures').iterdir()):
  name='figures/'+f.name
  assert (ROOT/name).read_bytes()==(t/name).read_bytes(),('FIG_REPLAY_BYTES',name)
 assert 'Ran 14 tests' in proc.stderr
print(json.dumps({'public_path':str(public),'public_bytes':public.stat().st_size,'public_SHA256':hashlib.sha256(public.read_bytes()).hexdigest(),
'private_path':str(private),'private_bytes':private.stat().st_size,'private_SHA256':hashlib.sha256(private.read_bytes()).hexdigest(),
'source_original_SHA256':ORIGINAL,'stage_checkpoints':20,'public_entries':len(paths),'private_entries':2,
'cold_replay':'CSV_JSON_8_SCIENCE_FIGURES_BYTE_EXACT','normal_tests':'14/14 PASS','opt_tests':'14/14 PASS'},indent=2))
