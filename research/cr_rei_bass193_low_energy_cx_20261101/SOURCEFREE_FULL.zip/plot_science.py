#!/usr/bin/env python3
"""Four independent scientific figures of source-conditional BASS-CR CX event rates."""
from pathlib import Path
import argparse,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def plot(csv_path:Path,out:Path):
    with csv_path.open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
    if len(rows)!=192:raise ValueError('source-clock rows')
    a=lambda key:np.asarray([float(x[key]) for x in rows])
    z=a('z_low');order=np.argsort(z);s=lambda key:a(key)[order]
    out.mkdir(parents=True,exist_ok=True)
    plt.rcParams['svg.hashsalt']='BASS_CR_REI_CX_20261101'
    common=dict(dpi=170,bbox_inches='tight')
    fig,ax=plt.subplots(figsize=(7.8,4.7))
    ax.plot(z[order],s('fit_window_rate_fraction'),label='3–200 km/s / all-fit model weight')
    ax.axhline(.95,linestyle='--',alpha=.65,label='95% fit-weight reference')
    ax.set(xlabel='Redshift z (interval endpoint)',ylabel='Fraction of fitted CX rate in speed window',ylim=(-.04,1.06),title='Velocity-domain coverage of resonant H⁺ + H exchange')
    ax.legend(fontsize=8,loc='lower left');ax.grid(alpha=.25);fig.savefig(out/'FIG01_CX_SPEED_WINDOW_COVERAGE.png',**common);fig.savefig(out/'FIG01_CX_SPEED_WINDOW_COVERAGE.svg',bbox_inches='tight',metadata={'Date':'2026-11-01'});plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.8,4.7))
    ax.plot(z[order],s('events_per_H_frozen_end_exposure'))
    ax.set(xlabel='Redshift z (interval endpoint)',ylabel='Event capacity / H per frozen-end interval',yscale='log',title='Original BASS193 H⁺ + H collision exposure (not history integral)')
    ax.grid(alpha=.25);fig.savefig(out/'FIG02_CX_FROZEN_ENDPOINT_EXPOSURE.png',**common);fig.savefig(out/'FIG02_CX_FROZEN_ENDPOINT_EXPOSURE.svg',bbox_inches='tight',metadata={'Date':'2026-11-01'});plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.8,4.7))
    ax.plot(z[order],s('nu_neutral_over_H_eff'))
    ax.set(xlabel='Redshift z (interval endpoint)',ylabel='Neutral collision frequency / expansion rate',yscale='log',title='Charge-exchange encounter rate vs source expansion clock')
    ax.grid(alpha=.25);fig.savefig(out/'FIG03_CX_NEUTRAL_OVER_EXPANSION.png',**common);fig.savefig(out/'FIG03_CX_NEUTRAL_OVER_EXPANSION.svg',bbox_inches='tight',metadata={'Date':'2026-11-01'});plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.8,4.7))
    ind=np.argsort(a('T_saved_K'))
    ax.plot(a('T_saved_K')[ind],a('kcx_fit_window_cm3_s')[ind],label='3–200 km/s speed contribution')
    ax.plot(a('T_saved_K')[ind],a('kcx_full_fit_extrapolated_cm3_s')[ind],linestyle='--',label='All-velocity fit extension (NOT admitted)')
    ax.set(xlabel='BASS193 saved H/He gas temperature (K)',ylabel='CX ⟨σg⟩ (cm³ s⁻¹)',title='BASS-CR source window: low-velocity extrapolation excluded')
    ax.legend(fontsize=8);ax.grid(alpha=.25);fig.savefig(out/'FIG04_CX_MODEL_K_T_COVERAGE.png',**common);fig.savefig(out/'FIG04_CX_MODEL_K_T_COVERAGE.svg',bbox_inches='tight',metadata={'Date':'2026-11-01'});plt.close(fig)
    return sorted(p.name for p in out.iterdir())

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source-csv',required=True,type=Path);ap.add_argument('--out',required=True,type=Path)
    x=ap.parse_args();print(plot(x.source_csv,x.out))
