# Source-owned BASS193 finite-window Thomson receiver (REI-consumer sentinel)

## Authority and assumptions

Signature (-,+,+,+), `c` in m/s, `σ_T` in m², proper time in s, proper electron density in m⁻³. Target is the **finite FLRW proper-time interval z=20→2** tabulated by original BASS193. Do not extrapolate to z<2 or z>20 and do not interpret it as full CMB optical depth.

- Original 193 epoch `BASS193_ELECTRON_FEEDBACK` has a saved full 21-charge electron fraction `xe_saved` and a source-defined *static-response* comparison `xe_star` at identical epoch and baryon number density `nb_m3`. These are distinct models/closures, not two statistical confidence bands.
- The source `PR302_THERMAL_192.csv` owns 192 proper time intervals. The PR303 H/He species `xHII`, `xHeII`, `xHeIII` permit the independent restricted H/He electron density crosswalk. No source history is evolved or adjusted in this work.
- PR #311 raw source archive verified byte-exact. It includes original BASS193 and source inputs, not just the derivative CCC collision rates. The six CCC collisions are *not* used here. CR=OFF.

## Direct derivation

For a locally comoving Thomson scatterer the directional optical depth along the homogeneous FLRW null worldline is

\[
 d\tau = c\,\sigma_T n_e(t)\,dt,\qquad n_e^{(21)}(t_i)=n_{b,i}x_{e,i}.
\]

Two endpoint estimates, both applied to the **same** saved source clock and backgrounds, are

\[
 \Delta\tau^{\rm trap}_j = \frac{c\sigma_T\Delta t_j}{2}\left(n_{e,j}+n_{e,j+1}\right),\qquad
 \Delta\tau^{\rm right}_j=c\sigma_T\Delta t_j\,n_{e,j+1}.
\]

This is quadrature sensitivity, **not** a bound on the unknown between-snapshot electron history. From observer-facing end (`j=191`, z=2) backwards,

\[
 \tau_j=\sum_{k=j}^{191}\Delta\tau_k,\quad \tau_{192}=0,\quad
 P_j=e^{-\tau_{j+1}}\left[1-e^{-\Delta\tau_j}\right],\qquad
 \sum_{j=0}^{191}P_j=1-e^{-\tau_0}.
\]

Thus `bin_visibility` is the chance of scattering in a bin **conditioned on transmission from z=2**, not the entire last-scattering probability across recombination and z<2. The saved `P_j / [ln(1+z_high)-ln(1+z_low)]` is a *discrete per-log-redshift response*, not the full conformal-time CMB visibility `g(η)`.

The H/He-only electron contribution is the source-matched projection

\[
 n_e^{\rm HHe}=n_b f_{\rm Href}
   \{x_{\rm HII}+Y_{\rm He/H}[x_{\rm HeII}+2x_{\rm HeIII}]\}.
\]

`xe_saved` and `xe_star` are full 21-species **source-owned** electron fractions, while this projected H/He abundance is only a crosscheck. Agreement observed here does not permit replacing the full source in another physical history.

## Scientific claim and scope

The measured difference between `tau_star` and `tau_saved` is the effect of **two available source-owned state closures on the same finite-window Thomson receiver**. It is neither CR-on/off sensitivity, cosmological model error, physical REI H/He integration, Bianchi-directional observable, nor a fit to external CMB likelihood. BASS is the owner of the final photon/Thomson transfer; this is a consumer crosswalk that it can independently import after provenance and geometry matching.

Literature context: Shull & Venkatesan (2007) arXiv:astro-ph/0702323 discusses separating the redshift contributions to Thomson optical depth; the present source values come only from the archived project CSVs, not from that paper.
