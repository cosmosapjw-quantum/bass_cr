# F04D → event-jet receiver binding

Repo cosmosapjw-quantum/bass_cr, 동일 research/r4q-gap-closure-20261001 branch. 다음 보조 노드는 BASS-CR-CHAT-F04E_EVENT_JET_RECEIVER_BINDING이다. 새로운 강제 선행 gate가 아니다.

먼저 최신 refs를 읽는다. 이번 수신 receiver는 b553698a114fbff05640ab6ecb95d260410de492이다. owner가 이미 parent를 고정하고 해당 정적 FT03 map에 대해 F04 completed를 게시했다. 과거 ACTUAL_PARENT_DOMAIN_NOT_FROZEN, 정적 certificate NOT_RUN을 현 blocker로 되살리지 않는다. Parent manifest와 EXECUTION_STATE에 남은 옛 prerequisite 문자열은 최종 checker receipt 및 F04_actual_map_certificate와 구분한다. 현재 읽은 owner의 다음 canonical task는 REI-F05이며 다음 chat은 REI-CHAT-FLRW06_NATIVE_SPECTRAL_STAGE_REGRESSION이다. 새 ref에서 전진했으면 그 delta를 따른다.

읽기 순서는 TASK_RETURN.json, INTAKE_ACK.json, SOURCE_BINDING.json, REPORT_KO.md §§3–7, results/run01/SUMMARY.json이다. 미분 결과가 필요할 때만 CENTRAL_PARENT_JETS/MIXED_RESIDUAL_BLOCKS를 읽는다. inputs/OWNER_PARENT_EXTRACT는 원 manifest 전체 bytes가 아닌 선택 필드다. Exact compiled DR constants와 native-normalized parent bits를 F04C의 재계산 literal로 치환하지 않는다.

이번 구현은 R_p/R_zp/R_pp 및 implicit first/second derivatives, reconstructed 7state와 PI9/CI3/RR3/DR2 사건·escape의 same-parent two-half 합성까지 완료했다. 24 focused tests, mixed272, coordinate1512, finite-difference50 검증을 반복할 이유는 없다. Python reference의 새 15개 diagnostic point refinements를 native 실행, 15개 history 또는 uniform proof라고 부르지 않는다. Physical source parameters는 모두 고정이고 log-step은 형식적 점미분 방향이지 여덟 번째 certified uncertainty가 아니다.

다음은 실제 receiver의 F05 또는 그 이후 event-consuming call site 하나가 어떤 state/time/units/accepted-step identity를 요구하는지 읽고 이번25-output contract와 매핑하는 작업이다. native event/escape bits가 이미 있으면 재실행 없이 필요한 필드만 읽는다. 부족한 것은 실제 실행이 필요한 최소 관측 필드로 특정하고, 임의의 stdout 숫자를 actual source-site 기록처럼 만들지 않는다. 실제 receiver에 별도 instrumented entrypoint가 없으면 source-bound adapter 계약과 필요한 최소 변경안을 먼저 산출하되 implementation-verified라 하지 않는다.

기본 불변식: full discarded events는 accepted 누적량에서 제외한다. Half1 endpoint의 사건/온도를 half2로 대체하지 않는다. 모든 full/half는 같은 original parent를 공유하고 first-half Hessian을 전파한다. Escape는 여기서는 정적 incremental energy이므로 expanding a^3/a^4 가중치를 붙일 때 receiver의 실제 source-stage 정의와 time convention을 먼저 정한다. Static F04 certificate를 expanding history 또는 event-jet remainder 전체의 승인으로 옮기지 않는다.

Production physical admission HOLD, precision atomic PARKED, CR_OFF_FASTEST를 유지한다. G02 unresolved, capture=false, all_bound OPEN, b_grid NO_GO는 그대로다. 실제 CR dispatch 관측은 이번에도 하지 않았으며 unobserved=null이다. 원자/full-K/R4AQ/318patch/소비된 실행 승인 재사용은 금지한다.

같은 branch 새 경로에 append-only/non-force 게시하고, 동일 새 immutable archive를 Drive parent1zzbClTE3qzz8gaiQwopXJqVk9ZGBawYZ와 Dropbox /BASS_DERIVATION_DOSSIERS_20260912/ATOMIC_REIONIZATION_HANDOFF_20261004_v1/에 create-only 백업한다. 실제 provider ACK·ID·size로 R1을 닫고 full restore와 구분한다. 이번 ZIP/게시/원격 영수증은 별도 DELIVERY_RECEIPT.json 또는 Git 게시 요약에서 읽는다.
