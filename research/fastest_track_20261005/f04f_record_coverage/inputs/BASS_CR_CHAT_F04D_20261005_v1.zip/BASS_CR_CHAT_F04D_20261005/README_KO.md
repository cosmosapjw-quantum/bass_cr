# F04D 실행 패키지

실제 FT03 원 parent의 mixed derivatives와 same-parent two-half 사건/escape jets를 담는다. 과학 결론은 REPORT_KO.md, 현재 상태와 제한은 TASK_RETURN.json, 다음 연구는 NEXT_HANDOFF_KO.md를 읽는다.

Python과 mpmath가 필요하다. 이 패키지는 Rust/production interval checker를 부르지 않는다.

```bash
python -m unittest discover -s tests -v
python research/run_f04d.py --output results/NEW_DIAGNOSTIC
```

두 번째 명령은 존재하는 출력 디렉터리를 덮어쓰지 않는다. 이미 받은 결과를 단순히 계승할 때 위 명령을 다시 실행할 필요는 없다. source 변경이나 새 목적이 있을 때만 사용한다. ./results/run01/이 이번 진단의 저장 결과다.

Owner의 정적 F04 완료를 수신했으며 그 interval checker를 재실행하지 않았다. 이 reference는 event derivatives의 유한점 구현 확인이며 event-jet uniform bounds, native floating rounding, 물리적 fitting error를 인증하지 않는다. 추가 log-step 방향은 owner7차원 certified parent에 포함되지 않는다.
