# BASS-CR-CHAT-F04D: original-parent 혼합 미분과 사건·escape의 두-half 합성

## 1. 결과와 바뀐 기준 상태

이번 보조 루프는 F04C의 네 미지수 `(x_HII,x_HeII,x_HeIII,eta=ln(T/1 K))`를 실제 owner의 정규화된 일곱 initial-state parent에 연결했다. 혼합 편미분, 암시적 해의 1·2차 parent 미분, photon 재구성, 두 half-step의 사건 17개와 escape 누적량의 1·2차 미분을 구현했다. 코드와 새 유한점 검산은 완료했지만 production Rust를 바꾸거나 새로운 uniform certificate를 발급한 작업은 아니다.

시작 bass_cr HEAD는 `3c7d7d4b811dd5f6eeafe60bafa1308a52dc1cf2`이다. Receiver `b553698a114fbff05640ab6ecb95d260410de492`는 이미 실제 parent를 고정하고, 해당 **정적 FT03 수치 영역**의 F04 완료를 게시했다. 원 parent 부재와 해당 정적 map certificate 미실행이라는 이전 blocker는 더 이상 현재 상태가 아니다. 이번에는 owner의 독립 MPFI checker를 읽고 결과를 수신했으며 실행하지 않았다. 새로운 결과를 기존 F04의 최초 인증으로 주장하지 않는다.

Owner checker receipt의 세 site 수축상수 상계는 약 `3.8120824e-9, 1.9066700e-9, 2.6395996e-9`, full/two-half local bounds는 `9.534453118819423e-9, 4.601848744068603e-10, 1.519527255699016e-11, 8.185094581543662e-10`, 최대 public width는 `1.5867951486958153e-6`이다. 이들은 **외부 증거 수신값**이지 이번 채팅에서 재계산한 interval 결과가 아니다. 과거 parent manifest의 prospective status와 EXECUTION_STATE의 옛 prerequisite 항목에는 미완료 문자열이 남아 있지만, 현재 REI-F04 completed 및 F04_actual_map_certificate, 별도 checker receipt가 후속 결과다. 기록을 소급 덮어쓰지 않는다.

완료 범위는 원 46,080-node history, expanding S0, 물리적 fitting error, CR-on의 승인까지 확장되지 않는다. Receiver의 현재 다음 canonical task는 REI-F05다. 이 스레드의 보조 산출물을 새 필수 gate로 만들지 않는다.

## 2. 원 parent와 숫자 identity

Owner parent는

\[
q=(x_H,x_1,x_2,w,p_0,p_1,p_2),\quad
w=\frac{u}{n_H\varepsilon_{\rm eV}},\quad p_g=\frac{N_g}{n_H}
\]

이다. `epsilon_eV`는 1 eV에 해당하는 erg 에너지다. 따라서 w와 정규화된 escape는 1 eV/H를 단위로 표시한 숫자이며, 사건은 H 핵 한 개당 개수다. 물리 밀도와 반응율은 원 source처럼 proper cm^-3와 초를 사용한다. 핵밀도, 광자 에너지·단면적, 모든 source realization을 고정하며 h=10^9 s이다.

일곱 반경은 `(1e-7,1e-7,1e-7,1e-5,1e-8,1e-8,1e-8)`로 이미 owner가 지정했다. 이는 수학적 검증을 위한 initial-state 근방이고 물리 오차 분포가 아니다. q0, c, kB, eV 변환, threshold, photon energy, sigma는 parent manifest의 binary64 bits를 사용했다. 최초 fixture 공식에서 q0나 sigma를 다시 만들지 않았다. Normalized native center를 다시 물리 단위로 곱하는 것과 원 native 초기 u의 bit identity가 같은 주장도 하지 않는다. 여기서 대상은 **owner가 고정한 정규화 실수 map**이다.

추가로 `ft03_map_constants.json`의 `dr_a,b1,b2,b12`를 정확히 바인딩했다. 특히

\[
b_{12}-\bigl(b_1+b_2\bigr)_{\mathrm{real}}
=4.3655745685100555419921875\times10^{-11}\ {\rm K}
\]

이다. 저장된 b12는 b1+b2를 정확 실수로 재계산한 숫자로 대체하지 않는다. 이는 수치 입력 identity의 차이이지 새로운 물리 불확실성이 아니다. 기본 kB_EOS와 rate 내부 kB가 같다는 비트 조건도 확인했다. 임의 kB 교체는 지원하지 않는다.

`inputs/OWNER_PARENT_EXTRACT.json`은 원 manifest의 선택 필드 전사본이다. 전체 manifest bytes를 복원했다는 뜻이 아니다. 반면 constants JSON과 checker receipt는 로컬로 보관한 전체 bytes의 Git blob을 원격 값과 일치시켰다. F04C archive의 SHA256을 확인한 후 필요한 `rates.py` 한 파일만 vendoring했으며 원 bytes를 변경하지 않았다. 새 compiled-DR adapter는 별도 파일이다.

## 3. 혼합 미분과 잔차 scale

모든 source parameter를 고정한 네 잔차를

\[
R(z,q,h)=0,\quad z=(x_H,x_1,x_2,\eta)
\]

로 쓴다. 원 F04C의 열 잔차를 이번에는 `Ustar=nH*epsilon_eV`라는 **고정 scale**로 표현했다. Source의 max/floor가 들어간 native residual_norm은 미분하지 않는다. Parent의 w0는 진짜 미분 변수이고 residual scale로 다시 사용하지 않았다.

A=R_z가 가역이고 같은 국소 root branch가 존재하면 직접 미분하여

\[
z_{,a}=-A^{-1}R_{,a},
\]

\[
z_{,ab}=-A^{-1}\left(R_{,ab}+R_{z,a}z_{,b}
+R_{z,b}z_{,a}+R_{zz}[z_{,a},z_{,b}]\right)
\]

를 얻는다. 마지막 식은 두 차례의 chain rule로 얻으며 mixed 항을 버릴 수 없다. 구현에서는 V를 `(z_q;I)`로 쌓아 각 잔차의 전체 Hessian에 `V.T H_R V`를 적용한다. 이 식은 중간에 비선형으로 주어진 old-state의 Hessian까지 포함할 수 있다.

양의 가역 scale S(q)를 곱한 잔차를 사용해도 실제 root와 모든 scale 미분을 포함하면 root 미분은 같지만, `S_q R_z`, `S_q R_q` 등의 mixed 항을 일부만 남기면 그렇지 않다. 이번 구현은 애초에 고정 scale을 선택해 이 불필요한 변수를 제거했다. 네 좌표의 미분을 일곱 좌표로 복원할 때에는 EOS와 `p_g=p_g0/(1+h*kappa_g(x))`의 explicit parent dependence도 함께 미분한다.

실제 API에는 R_p, R_zp, R_pp와 z_p,z_pp가 있다. 원 parent 일곱 좌표 외에 `lambda=ln(h/h_ref)`를 **점에서의 형식적인 미분 방향**으로 추가했다. 이것은 여덟 번째 certified uncertainty 변수가 아니며 h-domain을 확장하지 않았다. Source parameters는 owner 정의에 따라 모두 고정했고 독립적인 rate noise를 발명하지 않았다. 필요한 경우 출력으로부터 `Y_h=Y_lambda/h`, `Y_hh=(Y_lambdalambda-Y_lambda)/h^2`, `Y_qh=Y_qlambda/h`를 얻는다.

## 4. 같은 original parent를 보존하는 두-half 합성

한 BE map을 Phi_tau라고 놓으면

\[
y_1=\Phi_{h/2}(q),\qquad y_2=\Phi_{h/2}(y_1)
\]

이다. h가 고정일 때

\[
D_qy_2=J_2J_1,
\]

\[
D_q^2(y_2)_i=J_1^T(H_2)_iJ_1
+\sum_j(J_2)_{ij}(H_1)_j.
\]

첫 half의 Hessian이 두 번째 항에 반드시 들어간다. 이미 owner checker가 이 정적 state 합성을 수행했으므로 그것을 다시 인증하지 않았다. 이번 구현에서는 동일 parent frame의 jet을 첫 half에서 두 번째 half로 전달하고, 별도의 local-stage derivative를 위 식으로 pullback한 결과와도 대조했다. 서로 다른 parent frame을 섞으면 거절한다.

lambda까지 포함하면 두 half 모두 `tau=(h_ref/2) exp(lambda)`를 사용한다. tau_lambda=tau와 tau_lambdalambda=tau, state-time mixed 항이 생긴다. 첫 half로 full-step 후보를 대신하거나, 두 half의 lambda를 서로 독립적인 난수로 다루지 않았다.

이 구현이 진행한 새 범위는 **사건과 escape의 누적량**이다. 각 사건율 벡터 e(y)에 대해

\[
\mathcal E_{1/2}(q)=\frac h2 e(y_1)+\frac h2 e(y_2)
\]

를 그대로 미분한다. RR·DR의 kinetic/escape energy는 각 endpoint의 T와 n_e에서 평가한다. 마지막 endpoint 하나의 사건율에 h를 곱한 것은 같은 quantity가 아니다. Outputs는 state 7개, PI 9개·CI 3개·RR 3개·DR 2개의 누적 사건, incremental escape 1개로 총25개다. 기존 native producer의 stored event bits를 새로 관측한 결과는 아니며 고정된 exact-real source 식의 reference 출력이다.

## 5. 미분 보존식

f_He=nHe/nH로 놓고 정규화한 전자+광자 inventory를

\[
I_N=x_H+f_{He}(x_1+2x_2)+\sum_gp_g
\]

로 정의한다. 같은 endpoint의 사건을 쓰면

\[
L_N=I_N(y_2)-I_N(q)-\sum_a\mathcal C_a
+\sum_a\mathcal R_a+\sum_k\mathcal D_k=0.
\]

에너지는

\[
I_E=w+\chi_Hx_H+f_{He}\{\chi_1x_1+(\chi_1+\chi_2)x_2\}
+\sum_gE_gp_g,
\]

\[
L_E=I_E(y_2)-I_E(q)+\mathcal E_{esc}=0.
\]

반응별 PI의 photon/binding/heat, CI의 binding/thermal, RR·DR의 binding/kinetic/escape 항이 상쇄되기 때문에 얻는 source-bound 항등식이다. 상수·모형의 physical accuracy를 증명한 것이 아니다. 같은 매끄러운 parent에서 미분하면 1차와 2차 식도0이다. 따라서 새 derivative transport가 깨지면 값의 보존식이 작더라도 미분 보존식이 이를 드러낼 수 있다.

75-digit reference 실행에서 두-half의 최대 절댓값은 다음과 같았다. 작은 수들은 MP 연산 잔여값이며 outward-rounded rigorous bounds가 아니다.

| 장부 | 값 | gradient 최대 | Hessian 최대 |
|---|---:|---:|---:|
| 수 inventory | 1.16e-77 | 1.48e-76 | 6.95e-79 |
| 에너지 inventory | 1.57e-74 | 5.17e-75 | 9.04e-76 |

폐기된 full 후보의 사건과 escape를 잘못 더하는 부정 대조는 수 inventory에 `6.3560413180e-6` H^-1, 에너지 inventory에 `4.2212986080e-7` (1 eV/H 단위)의 defect를 만들었다. 이때 gradient/Hessian도0이 아니었다. 이를 현재 production 코드의 발견된 bug라고 주장하지 않는다. 의도적으로 잘못 연결한 경로를 탐지하는 시험이다.

## 6. 실제 새로운 검산

새 단위시험24개를 실행했다. 최초 composition 시험1개는 assertion RED→GREEN 로그가 있고, 나머지23개는 tests-after다. 모든 시험이 PASS다. 이전 F04C의23시험, F04B의42시험, 기존 Rust crate, owner의 MPFI/interval certificate, 원자 reference campaign은 다시 실행하지 않았다.

별도의 diagnostic 실행은 다음을 확인했다.

* R_zp 128성분과 R_pp의 대칭 독립 성분144개, 합272개를 source 식의 고정밀 수치미분과 대조했다. 단위 floor를 포함한 최대 scaled discrepancy는 약8.64e-78이며 사전 기준은1e-45였다.
* full, half1, half2에서 네 미지수→일곱 출력 경로의 Jacobian/Hessian을 일곱 unknown BE 식의 implicit differentiation과 대조했다. 총1512개의 미분 성분, 최대 절대 차이는 약2.30e-75였다. 같은 source 표현을 사용하는 두 좌표 경로의 비교이지 독립 원자물리 구현 검증이 아니다.
* Owner box 안의 네 initial-state perturbation에서 새 reference endpoint를 계산하고 Richardson 유한차분으로 누적 출력25개의 1·2차 방향미분50개를 대조했다. 최대 상대 차이는1.27e-26이며 사전 기준은1e-9였다. 이 비교에서는 h를 고정했다.
* Diagnostic 실행의 중심/perturbed full·half map point refinements는15개이며 각 최대 iteration budget은8이다. 최대 normalized residual은1.63e-74였다. 같은 세 점만의 반복 인증이 아니라 새 mixed/event derivative 대조 목적이다. 단위시험과 초기 smoke 실행의 별도 제한된 계산까지 이15개에 포함한 것으로 해석하지 않는다.

예를 들어 two-half HII의 initial thermal-coordinate 응답은

\[
\partial x_H^{(1/2,1/2)}/\partial w_0
=1.69698276085\times10^{-6},
\quad
\partial^2x_H^{(1/2,1/2)}/\partial w_0^2
=2.17990623503\times10^{-7}.
\]

고정계수 F03의0과 달리 온도 결합이 살아 있다. 이 부호와 크기는 해당 고정 모형·중심점의 결과이고 전역 단조성이나 물리적 우주론 예측의 검증은 아니다.

Mpmath point refinement, automatic second-order differentiation, source값 유한차분을 검증했다. 75자리 작업 정밀도가75자리의 엄밀 정확성을 보장하지 않는다. Native FT03 실행, native rounding enclosure, production event callback binding은 이번0회다. 독립 human/agent review 또는 proof assistant 검증도 수행하지 않았다.

## 7. 재현·파일 계약

최소 실행은 `python -m unittest discover -s tests -v`와 `python research/run_f04d.py --output NEW_DIRECTORY`다. Diagnostic은 기존 output 디렉터리를 거절한다. 원격 접속이나 archive 회수가 필요하지 않으며, dependencies는 Python과 mpmath뿐이다. 코드에 실제 production inference·원자 적분·HPC launch 기능은 없다.

`results/run01/CENTRAL_PARENT_JETS.json`에 source-site별 state/events/escape 값·gradient·Hessian, `MIXED_RESIDUAL_BLOCKS.json`에 mixed residual blocks, 나머지 결과에는 대조값·오차·refinement 기록이 있다. MP 결과는70자리 표시 문자열로 저장했으며 exact interval endpoints로 표시하지 않았다. `inputs/`의 bit-string 입력은 별도로 보존한다.

부족한 범위는 본 repo의 machine-readable TASK_RETURN과 NEXT_HANDOFF에 명시했다. 특히 새 event jets의 uniform remainder, actual native event/escape bits와의 접속, source physical uncertainty, expanding measure의 stage weighting은 이번 인증이 아니다. Static event 결과를 재이온화 전역 history로 자동 확장하지 않는다.

## 8. 소스와 방법론 근거

[1] rei_bianchi@b553698a114fbff05640ab6ecb95d260410de492, `runs/rei_fastest_v1/map_certificate/parent_manifest.json` (blob ab4e317c...), `certificate.json` (blob70969be...), `checker_receipt.json` (blob283efad...). Parent 선택 필드, receipt 전체, certificate의 초기 일부만 읽었다. 전체 certificate archive restore/실행은 하지 않았다.

[2] 같은 commit의 `runtime_returns/evidence/F04_certificate/checker.py` (blob9f169d8e...), `tools/check_map_certificate.py` (blob8fde751e...). Source 표현, same-parent composition과 범위/잔차 확인 절차를 읽었으며 MPFI checker를 실행하지 않았다.

[3] 같은 commit의 `runtime_inputs/ft03_map_constants.json` (blobf53cd5ac...), `runtime_returns/EXECUTION_STATE.json` (blob73d628da...) 및 REI-F04의 현재 completed 반환. 옛 prerequisite status와 후속 완료를 구별했다.

[4] 전달된 BASS_CR_CHAT_F04C_20261005_v1.zip, SHA256 bd39f3e8de95d48115a425211580d412f820f751d0ea773ce33f90c1c7419b85. 필요한 rate reference만 hash를 확인하여 상속했다.

[5] Blondel et al., “Efficient and Modular Implicit Differentiation,” arXiv:2105.15183. Residual/optimality condition과 nonlinear solver를 분리하는 방법론 배경으로 초록을 확인했다. 위 2차 미분식과 사건 보존식은 본 보고서에서 직접 유도했으며 그 논문의 특정 정리를 검증한 것으로 쓰지 않았다.
