"""New F04D finite-point verification; never invokes Rust or the owner checker."""
import argparse,json,sys,time,platform
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from mpmath import mp
from ft03_parent import *

def serial(x):
    if isinstance(x,Jet):return {'value':serial(x.v),'gradient':serial(x.g),'hessian':serial(x.H),'frame':list(x.frame)}
    if isinstance(x,mp.matrix):return [[serial(x[i,j]) for j in range(x.cols)] for i in range(x.rows)]
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [serial(v) for v in x]
    if isinstance(x,mp.mpf):return mp.nstr(x,70)
    return x

def normjet(q):return {'value':abs(q.v),'gradient':max(map(abs,q.g)),'hessian':max(map(abs,q.H))}
def err(a,b):return abs(a-b)/max(mp.mpf(1),abs(a),abs(b))
def outputs(s):return s['state']+s['events']+[s['escape']]

def seven_coordinate_check(m,old,h,s):
    frame=old[0].frame;joint=tuple(f'y_{i}' for i in range(7))+frame
    yy=[Jet.variable(y.v,joint,i) for i,y in enumerate(s['state'])]
    oo=[v.embed(joint,7) for v in old];hh=h.embed(joint,7)
    f7,_,_=m.source(yy);rr=[yy[i]-oo[i]-hh*f7[i] for i in range(7)]
    y7,_=implicit_from_residual(rr,7,frame,[v.v for v in yy])
    differences=[a-b for a,b in zip(y7,s['state'])]
    return max(max(map(abs,d.g)) for d in differences),max(max(map(abs,d.H)) for d in differences)

def point_outputs(m,ref,q,h):
    zf=ref.solve(q,h);yf=m.reconstruct(zf,q,h)
    z1=ref.solve(q,h/2);y1=m.reconstruct(z1,q,h/2)
    z2=ref.solve(y1,h/2);y2=m.reconstruct(z2,y1,h/2)
    _,e1,s1=m.source(y1);_,e2,s2=m.source(y2)
    return y2+[h/2*(a+b) for a,b in zip(e1,e2)]+[h/2*(s1+s2)]

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--output',type=Path,required=True);args=pa.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    mp.dps=75;t0=time.monotonic();m=Source();ref=Refiner(m);old,h=original_parent(m)
    full=step(m,ref,old,h);h1=step(m,ref,old,h/2);h2=step(m,ref,h1['state'],h/2)
    accepted=h2['state']+[a+b for a,b in zip(h1['events'],h2['events'])]+[h1['escape']+h2['escape']]
    summary={'task':'BASS-CR-CHAT-F04D','mp_dps':mp.dps,'owner_parent_dimensions':7,
      'extra_formal_log_step_direction':'pointwise only; not in the owner certified parent',
      'native_runs':0,'owner_checker_runs':0,'old_science_suites_replayed':0,'interval_box_expansions':0,
      'implementation_scope':'New real-map point derivatives and cumulative event jets, not native rounding enclosure or a new uniform certificate'}
    led={}
    for name,st,ev,esc in [('full',full['state'],full['events'],full['escape']),('two_half',h2['state'],accepted[7:24],accepted[24])]:
        led[name]={k:normjet(v) for k,v in ledger(m,old,st,ev,esc).items()}
    assert max(v for lane in led.values() for l in lane.values() for v in l.values())<mp.mpf('1e-50')
    summary['ledger_maxima']=led
    equivalence=[]
    for name,o,hh,ss in [('full',old,h,full),('half1',old,h/2,h1),('half2',h1['state'],h/2,h2)]:
        g,H=seven_coordinate_check(m,o,hh,ss);assert max(g,H)<mp.mpf('1e-45')
        equivalence.append({'site':name,'gradient_max_abs':g,'hessian_max_abs':H})
    summary['four_vs_seven_coordinate_derivatives']=equivalence
    summary['four_vs_seven_derivative_components_checked']=3*7*(8+64)
    # The new mixed blocks alone are checked, not the already-completed F04C z-only suite.
    z=full['z'];args0=tuple(z)+tuple(m.q0)+(mp.mpf(0),)
    checks=[];mx=mp.mpf(0)
    for row in range(4):
        def fn(*v):return m.residual(v[:4],v[4:11],m.h0*mp.exp(v[11]))[row]
        for i in range(4):
            for j in range(8):
                order=[0]*12;order[i]+=1;order[4+j]+=1
                exact=mp.diff(fn,args0,tuple(order));got=full['mixed']['R_all_hess'][row][i,4+j]
                ee=err(exact,got);mx=max(mx,ee);assert ee<mp.mpf('1e-45')
                checks.append(['R_zp',row,i,j,got,exact,ee])
        for i in range(8):
            for j in range(i,8):
                order=[0]*12;order[4+i]+=1;order[4+j]+=1
                exact=mp.diff(fn,args0,tuple(order));got=full['mixed']['R_all_hess'][row][4+i,4+j]
                ee=err(exact,got);mx=max(mx,ee);assert ee<mp.mpf('1e-45')
                checks.append(['R_pp',row,i,j,got,exact,ee])
    summary['mixed_derivative_components_checked']=len(checks);summary['mixed_derivative_max_scaled_error']=mx
    # Independent centered finite differences of newly refined map values, with
    # Richardson cancellation. All four initial-state perturbations are inside
    # the owner's fixed box; h itself stays fixed for this numerical check.
    direction=mp.matrix([r*(1 if i%2==0 else -1) for i,r in enumerate(m.radii)]+[0])
    eps=mp.mpf(1)/4;v0=[x.v for x in accepted];samples={}
    for a in (eps,-eps,eps/2,-eps/2):
        q=[m.q0[i]+a*direction[i] for i in range(7)]
        assert all(abs(q[i]-m.q0[i])<=m.radii[i] for i in range(7))
        samples[a]=point_outputs(m,ref,q,m.h0)
    fd=[];maxfd=mp.mpf(0)
    for i,x in enumerate(accepted):
        first=[];second=[]
        for e in (eps,eps/2):
            first.append((samples[e][i]-samples[-e][i])/(2*e))
            second.append((samples[e][i]-2*v0[i]+samples[-e][i])/(e*e))
        f1=(4*first[1]-first[0])/3;f2=(4*second[1]-second[0])/3
        d1=(x.g.T*direction)[0];d2=(direction.T*x.H*direction)[0]
        er1=abs(f1-d1)/max(abs(d1),mp.mpf('1e-40'));er2=abs(f2-d2)/max(abs(d2),mp.mpf('1e-40'))
        assert max(er1,er2)<mp.mpf('1e-9');maxfd=max(maxfd,er1,er2)
        fd.append({'output':i,'analytic_first':d1,'fd_first':f1,'relative_first':er1,'analytic_second':d2,'fd_second':f2,'relative_second':er2})
    summary['directional_map_derivatives_checked']=2*len(accepted);summary['directional_max_relative_error']=maxfd
    # Negative controls: discarded full trial cannot be included in accepted ledgers.
    bad=ledger(m,old,h2['state'],[a+f for a,f in zip(accepted[7:24],full['events'])],accepted[24]+full['escape'])
    assert abs(bad['energy'].v)>mp.mpf('1e-12')
    summary['discarded_full_trial_negative_control']={k:normjet(v) for k,v in bad.items()}
    summary['full_half_central_observable_differences']=[full['state'][i].v-h2['state'][i].v for i in range(3)]+[mp.log(m.temp([x.v for x in full['state']]))-mp.log(m.temp([x.v for x in h2['state']]))]
    summary['thermal_parent_response']={'dxHII_dw0_full':full['state'][0].g[3],'dxHII_dw0_twohalf':accepted[0].g[3],'d2xHII_dw0_squared_twohalf':accepted[0].H[3,3]}
    summary['fixed_compiled_constant_difference']={'b12_minus_real_sum_b1_b2':m.b12-(m.b1+m.b2)}
    summary['point_refinement_count_in_this_diagnostic_run']=len(ref.records)
    summary['point_refinement_max_residual']=max(r['residual_norm'] for r in ref.records)
    summary['wall_seconds']=time.monotonic()-t0;summary['status']='PASS_NEW_BOUNDED_POINT_CHECKS'
    names=STATE_NAMES+EVENT_NAMES+('escaped_energy_over_nH_eV',)
    files={'SUMMARY.json':summary,'MIXED_PARTIAL_CHECKS.json':checks,'DIRECTIONAL_CHECKS.json':fd,
      'CENTRAL_PARENT_JETS.json':{'names':names,'full':outputs(full),'half1_increment':outputs(h1),'half2_increment_original_parent':outputs(h2),'two_half_cumulative':accepted},
      'MIXED_RESIDUAL_BLOCKS.json':full['mixed'],'POINT_REFINEMENTS.json':ref.records}
    for name,data in files.items():(args.output/name).write_text(json.dumps(serial(data),indent=2)+'\n')
    print(json.dumps(serial(summary),indent=2))

if __name__=='__main__':main()
