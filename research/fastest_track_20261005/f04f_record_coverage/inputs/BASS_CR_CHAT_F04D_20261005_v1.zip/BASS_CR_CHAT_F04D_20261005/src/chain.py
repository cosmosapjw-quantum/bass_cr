"""Second-order composition: D(g o f)=Dg Df and D2(g o f)."""
from mpmath import mp

def chain2(outer_jac, outer_hess, inner_jac, inner_hess):
    """Compose unscaled derivatives, not Taylor coefficients divided by two."""
    m,k=outer_jac.rows,outer_jac.cols
    n=inner_jac.cols
    if inner_jac.rows!=k or len(outer_hess)!=m or len(inner_hess)!=k:
        raise ValueError('COMPOSITION_SHAPE')
    if any(H.rows!=k or H.cols!=k for H in outer_hess):raise ValueError('OUTER_HESSIAN_SHAPE')
    if any(H.rows!=n or H.cols!=n for H in inner_hess):raise ValueError('INNER_HESSIAN_SHAPE')
    J=outer_jac*inner_jac
    H=[inner_jac.T*outer_hess[i]*inner_jac + sum((outer_jac[i,j]*inner_hess[j] for j in range(k)),mp.matrix(n)) for i in range(m)]
    return J,H
