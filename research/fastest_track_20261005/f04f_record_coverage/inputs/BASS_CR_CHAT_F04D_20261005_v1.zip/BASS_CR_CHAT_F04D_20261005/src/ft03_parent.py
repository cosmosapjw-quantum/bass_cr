"""Pinned normalized FT03 real map and mixed implicit parent derivatives.

No production solver or interval checker is called. The 7 owner parent
coordinates are fixed by the receipt. Optional log(h/h_ref) is a pointwise
formal differentiation direction, NOT a certified extra uncertainty variable.
"""
from pathlib import Path
import sys,json,struct
from mpmath import mp
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from f04c_rates import rates as inherited_rates, f
from jet2 import Jet,val,exp,log,bundle
from chain import chain2

STATE_NAMES=('x_HII','x_HeII','x_HeIII','w_u_over_nH_eV','p0_over_nH','p1_over_nH','p2_over_nH')
EVENT_NAMES=tuple(f'PI_{a}_{g}' for a in range(3) for g in range(3))+tuple(f'CI_{a}' for a in range(3))+tuple(f'RR_{a}' for a in range(3))+('DR_0','DR_1')
BASE=Path(__file__).resolve().parents[1]

def decode_bits(s):
    if not isinstance(s,str) or len(s)!=16:raise ValueError('BINARY64_BITS')
    try:v=struct.unpack('>d',bytes.fromhex(s))[0]
    except (ValueError,struct.error):raise ValueError('BINARY64_BITS')
    if not mp.isfinite(v):raise ValueError('NONFINITE_BITS')
    return mp.mpf(v)

class Source:
    def __init__(self,parent_path=None,constant_path=None):
        self.parent=json.loads(Path(parent_path or BASE/'inputs/OWNER_PARENT_EXTRACT.json').read_text())
        if tuple(self.parent['coordinate_ids'])!=STATE_NAMES:raise ValueError('PARENT_COORDINATES')
        p=self.parent
        self.q0=list(map(decode_bits,p['center_bits']))
        self.nh,self.nhe,self.c,self.kb,self.ev,*rest=map(decode_bits,p['constants_bits'])
        self.chi=rest[:3];self.energy=rest[3:];self.fhe=self.nhe/self.nh
        self.sigma=[[decode_bits(p['sigma_bits'][3*a+g]) for g in range(3)] for a in range(3)]
        cs=json.loads(Path(constant_path or BASE/'inputs/ft03_map_constants.json').read_text())
        self.da,self.b1,self.b2,self.b12=[decode_bits(cs[k]) for k in ('dr_a_bits','b1_bits','b2_bits','b12_bits')]
        self.h0=mp.mpf(p['h_s']);self.radii=list(map(mp.mpf,p['radii']))
        if self.kb!=f('1.380649e-16'):raise ValueError('EOS_RATE_KB_IDENTITY')
        if self.nh<=0 or self.nhe<=0:raise ValueError('NUCLEAR_DENSITY_DOMAIN')
    def temp(self,y):
        return 2*self.ev*y[3]/(3*self.kb*(1+self.fhe+y[0]+self.fhe*(y[1]+2*y[2])))
    def check(self,y):
        if len(y)!=7 or any(not mp.isfinite(val(a)) for a in y):raise ValueError('STATE_SHAPE_OR_NONFINITE')
        v=list(map(val,y))
        if min(v)<0 or v[0]>1 or v[1]+v[2]>1:raise ValueError('STATE_DOMAIN')
        if not 30000<=val(self.temp(y))<=110000:raise ValueError('TEMPERATURE_DOMAIN')
    def coefficients(self,T):
        r=inherited_rates(val(T))
        # Bind the map's published compiled constants rather than re-evaluating
        # their source products. In particular b12 is an independent saved bit value.
        r['dr']=[];r['dr1']=[];r['dr2']=[];r['dr_energy']=[]
        for k,B in enumerate((self.b1,self.b12)):
            a=(1 if k==0 else f('.3'))*self.da*val(T)**(-mp.mpf('1.5'))*mp.exp(-B/val(T))
            g=-mp.mpf('1.5')+B/val(T)
            r['dr'].append(a);r['dr1'].append(a*g);r['dr2'].append(a*(g*g-B/val(T)))
            r['dr_energy'].append(self.kb*B)
        if isinstance(T,Jet):
            eta=log(T)
            for key in ('alpha','beta','K','dr'):
                r[key]=[eta.chain(a,r[key+'1'][i],r[key+'2'][i]) for i,a in enumerate(r[key])]
        return r
    def source(self,y):
        """Return normalized RHS, 17 event rates/H, escaped energy rate/(nH eV)."""
        self.check(y);T=self.temp(y);r=self.coefficients(T)
        x=y[:3];ne=self.nh*x[0]+self.nhe*(x[1]+2*x[2])
        lower=[1-x[0],self.fhe*(1-x[1]-x[2]),self.fhe*x[1]]
        upper=[x[0],self.fhe*x[1],self.fhe*x[2]]
        zero=x[0]*0;j=[zero for _ in range(3)];pd=[zero for _ in range(3)]
        photo=[];ci=[];rr=[];Q=zero;escape=zero
        for a in range(3):
            C=lower[a]*ne*r['beta'][a];R=upper[a]*ne*r['alpha'][a]
            K=upper[a]*ne*r['K'][a]/self.ev
            ci.append(C);rr.append(R);j[a]=C-R
            Q=Q-self.chi[a]*C-K;escape=escape+self.chi[a]*R+K
            for g in range(3):
                P=self.c*self.nh*lower[a]*self.sigma[a][g]*y[4+g]
                photo.append(P);j[a]=j[a]+P;pd[g]=pd[g]-P
                Q=Q+(self.energy[g]-self.chi[a])*P
        dr=[]
        for k in range(2):
            D=upper[1]*ne*r['dr'][k];dr.append(D);j[1]=j[1]-D
            Q=Q-D*r['dr_energy'][k]/self.ev
            escape=escape+D*(self.chi[1]+r['dr_energy'][k]/self.ev)
        return [j[0],(j[1]-j[2])/self.fhe,j[2]/self.fhe,Q,*pd],photo+ci+rr+dr,escape
    def reconstruct(self,z,old,h):
        x=z[:3];T=exp(z[3]);npH=1+self.fhe+x[0]+self.fhe*(x[1]+2*x[2])
        w=mp.mpf('1.5')*self.kb*npH*T/self.ev
        lo=[1-x[0],self.fhe*(1-x[1]-x[2]),self.fhe*x[1]]
        kap=[self.c*self.nh*sum(lo[a]*self.sigma[a][g] for a in range(3)) for g in range(3)]
        return [*x,w,*[old[4+g]/(1+h*kap[g]) for g in range(3)]]
    def residual(self,z,old,h):
        if val(h)<0 or not mp.isfinite(val(h)):raise ValueError('STEP_DOMAIN')
        y=self.reconstruct(z,old,h);F,_,_=self.source(y)
        # Fixed Ustar=nH*eV_erg, independent of differentiated old thermal input.
        return [y[i]-old[i]-h*F[i] for i in range(4)]
    @property
    def energy_weights(self):
        return [self.chi[0],self.fhe*self.chi[1],self.fhe*(self.chi[1]+self.chi[2]),1,*self.energy]
    @property
    def count_weights(self):return [1,self.fhe,2*self.fhe,0,1,1,1]

class Refiner:
    """Bounded high-precision point refiner; not a uniform/root inclusion proof."""
    def __init__(self,model,max_iterations=8,tol='1e-62'):
        self.m=model;self.max_iterations=max_iterations;self.tol=mp.mpf(tol);self.cache={};self.records=[]
    def solve(self,q,h):
        q=list(map(val,q));h=val(h);self.m.check(q)
        if h<0 or not mp.isfinite(h):raise ValueError('STEP_DOMAIN')
        key=tuple(a._mpf_ for a in [*q,h])+(mp.prec,)
        if key in self.cache:return self.cache[key][:]
        z=[*q[:3],mp.log(self.m.temp(q))];frame=('z0','z1','z2','eta')
        norms=[]
        for iteration in range(self.max_iterations+1):
            r=self.m.residual(z,q,h);norm=max(map(abs,r));norms.append(norm)
            if norm<self.tol:
                self.cache[key]=z[:];self.records.append({'h':h,'iterations':iteration,'residual_norm':norm,'norms':norms});return z
            if iteration==self.max_iterations:break
            rz=self.m.residual([Jet.variable(a,frame,i) for i,a in enumerate(z)],q,h)
            _,J,_=bundle(rz);delta=mp.lu_solve(J,-mp.matrix(r))
            accepted=False
            for k in range(16):
                trial=[z[i]+delta[i]/2**k for i in range(4)]
                try:rr=self.m.residual(trial,q,h)
                except ValueError:continue
                if max(map(abs,rr))<norm:z=trial;accepted=True;break
            if not accepted:raise RuntimeError('POINT_NEWTON_LINESEARCH_FAILED')
        raise RuntimeError('POINT_NEWTON_NONCONVERGENCE')

def implicit_from_residual(rjets,nunknown,frame,root):
    """Differentiate R(z(p),p)=0; caller separately establishes the root."""
    _,allJ,allH=bundle(rjets);n=len(frame);k=nunknown
    if len(rjets)!=k or allJ.cols!=k+n:raise ValueError('IMPLICIT_SHAPE')
    A=allJ[:,:k];B=allJ[:,k:];inv=A**-1;S=-inv*B
    V=mp.matrix(k+n,n)
    for i in range(k):
        for j in range(n):V[i,j]=S[i,j]
    for j in range(n):V[k+j,j]=1
    total=[V.T*H*V for H in allH]
    HH=[-sum((inv[i,a]*total[a] for a in range(k)),mp.matrix(n)) for i in range(k)]
    jets=[Jet(root[i],mp.matrix(list(S[i,:])),HH[i],frame) for i in range(k)]
    # mp.matrix(row entries) is a column vector, as required by Jet.
    return jets,dict(R_z=A,R_p=B,R_all_hess=allH,Z_p=S,Z_pp=HH)

def step(model,refiner,old,h):
    if len(old)!=7 or not all(isinstance(x,Jet) for x in old):raise ValueError('OLD_JETS_REQUIRED')
    frame=old[0].frame;n=len(frame)
    if any(x.frame!=frame for x in old) or (isinstance(h,Jet) and h.frame!=frame):raise ValueError('PARENT_FRAME_MISMATCH')
    z=refiner.solve(old,h);joint=tuple(f'unknown_{i}' for i in range(4))+frame
    zz=[Jet.variable(a,joint,i) for i,a in enumerate(z)]
    oo=[x.embed(joint,4) for x in old]
    hh=h.embed(joint,4) if isinstance(h,Jet) else h
    residual=model.residual(zz,oo,hh)
    zj,mixed=implicit_from_residual(residual,4,frame,z)
    state=model.reconstruct(zj,old,h);_,event,esc=model.source(state)
    event=[h*e for e in event];esc=h*esc
    return dict(state=state,events=event,escape=esc,z=z,zjets=zj,mixed=mixed)

def compose_outputs(outputs,inner):
    v,J,H=bundle(outputs);_,G,K=bundle(inner)
    JJ,HH=chain2(J,H,G,K);frame=inner[0].frame
    return [Jet(v[i],mp.matrix(list(JJ[i,:])),HH[i],frame) for i in range(len(outputs))]

def ledger(model,old,new,events,escape):
    count=sum(model.count_weights[i]*(new[i]-old[i]) for i in range(7))-sum(events[9:12])+sum(events[12:17])
    energy=sum(model.energy_weights[i]*(new[i]-old[i]) for i in range(7))+escape
    return dict(number=count,energy=energy)

def original_parent(model,with_log_step=True):
    frame=STATE_NAMES+(('log_h_over_h_ref',) if with_log_step else ())
    old=[Jet.variable(x,frame,i) for i,x in enumerate(model.q0)]
    h=model.h0*Jet.variable(0,frame,7).exp() if with_log_step else model.h0
    return old,h
