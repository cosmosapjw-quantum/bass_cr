"""Small dense second-order jets for bounded reference calculations, not intervals."""
from dataclasses import dataclass
from mpmath import mp

@dataclass
class Jet:
    v: object
    g: object
    H: object
    frame: tuple

    @classmethod
    def const(cls,v,frame):
        n=len(frame); return cls(mp.mpf(v),mp.matrix(n,1),mp.matrix(n),tuple(frame))
    @classmethod
    def variable(cls,v,frame,index):
        r=cls.const(v,frame)
        if not 0<=index<len(frame):raise ValueError('VARIABLE_INDEX')
        r.g[index]=1;return r
    def coerce(self,x):
        if isinstance(x,Jet):
            if x.frame!=self.frame:raise ValueError('PARENT_FRAME_MISMATCH')
            return x
        return Jet.const(x,self.frame)
    def __add__(self,x):
        b=self.coerce(x);return Jet(self.v+b.v,self.g+b.g,self.H+b.H,self.frame)
    __radd__=__add__
    def __neg__(self):return Jet(-self.v,-self.g,-self.H,self.frame)
    def __sub__(self,x):return self+-self.coerce(x)
    def __rsub__(self,x):return self.coerce(x)+-self
    def __mul__(self,x):
        b=self.coerce(x)
        return Jet(self.v*b.v,self.g*b.v+b.g*self.v,self.H*b.v+b.H*self.v+self.g*b.g.T+b.g*self.g.T,self.frame)
    __rmul__=__mul__
    def chain(self,value,first,second):
        return Jet(mp.mpf(value),first*self.g,first*self.H+second*(self.g*self.g.T),self.frame)
    def reciprocal(self):
        if self.v==0:raise ValueError('ZERO_DENOMINATOR')
        return self.chain(1/self.v,-1/self.v**2,2/self.v**3)
    def __truediv__(self,x):return self*self.coerce(x).reciprocal()
    def __rtruediv__(self,x):return self.coerce(x)*self.reciprocal()
    def exp(self):
        e=mp.exp(self.v);return self.chain(e,e,e)
    def log(self):
        if self.v<=0:raise ValueError('LOG_DOMAIN')
        return self.chain(mp.log(self.v),1/self.v,-1/self.v**2)
    def embed(self,frame,offset):
        n=len(self.frame);r=Jet.const(self.v,frame)
        if offset<0 or offset+n>len(frame):raise ValueError('EMBED_SHAPE')
        for i in range(n):
            r.g[offset+i]=self.g[i]
            for j in range(n):r.H[offset+i,offset+j]=self.H[i,j]
        return r

def val(x):return x.v if isinstance(x,Jet) else mp.mpf(x)
def exp(x):return x.exp() if isinstance(x,Jet) else mp.exp(x)
def log(x):return x.log() if isinstance(x,Jet) else mp.log(x)

def bundle(jets):
    if not jets:raise ValueError('EMPTY_BUNDLE')
    frame=jets[0].frame
    if any(x.frame!=frame for x in jets):raise ValueError('PARENT_FRAME_MISMATCH')
    return mp.matrix([x.v for x in jets]),mp.matrix([list(x.g) for x in jets]),[x.H.copy() for x in jets]
