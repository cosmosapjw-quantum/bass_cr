import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from mpmath import mp
from chain import chain2
class ChainTests(unittest.TestCase):
    def test_inner_curvature_is_not_dropped(self):
        # f(z)=z^2 and z(p)=p^2 at p=2: (f o z)''=48, not 32.
        J,H=chain2(mp.matrix([[8]]),[mp.matrix([[2]])],mp.matrix([[4]]),[mp.matrix([[2]])])
        self.assertEqual(J[0,0],32)
        self.assertEqual(H[0][0,0],48)
if __name__=='__main__':unittest.main()
