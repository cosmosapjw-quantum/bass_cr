import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from mpmath import mp
from jet2 import Jet,bundle
from ft03_parent import *
from chain import chain2

class JetTests(unittest.TestCase):
    def setUp(self):mp.dps=75
    def test_product_cross_terms(self):
        fr=('a','b');a=Jet.variable(2,fr,0);b=Jet.variable(3,fr,1);q=a*b
        self.assertEqual(q.H[0,1],1);self.assertEqual(q.H[1,0],1)
    def test_log_exp_chain(self):
        z=Jet.variable(2,('q',),0);q=z.exp().log();self.assertLess(abs(q.v-2),mp.mpf('1e-70'));self.assertLess(abs(q.H[0,0]),mp.mpf('1e-70'))
    def test_parent_frame_mismatch_rejected(self):
        with self.assertRaisesRegex(ValueError,'PARENT_FRAME'):Jet.variable(1,('full_parent',),0)+Jet.variable(1,('half_parent',),0)
    def test_zero_division_rejected(self):
        with self.assertRaises(ValueError):Jet.const(0,('q',)).reciprocal()
    def test_nonpositive_log_rejected(self):
        with self.assertRaises(ValueError):Jet.const(-1,('q',)).log()
    def test_chain_shape_rejected(self):
        with self.assertRaises(ValueError):chain2(mp.matrix(2),[mp.matrix(1)],mp.matrix(3),[mp.matrix(3)])
    def test_missing_inner_hessian_detected(self):
        J,H=chain2(mp.matrix([[8]]),[mp.matrix([[2]])],mp.matrix([[4]]),[mp.matrix([[2]])])
        wrong=4*2*4
        self.assertEqual(H[0][0,0]-wrong,16)
    def test_scalar_implicit_mixed_parameter(self):
        # z + h*z^2 - q=0, z=1, q=2, h=1. q(s)=2+s, h(s)=exp(s).
        joint=('z','s');z=Jet.variable(1,joint,0);s=Jet.variable(0,joint,1)
        rr=z+s.exp()*z*z-(2+s)
        out,_=implicit_from_residual([rr],1,('s',),[mp.mpf(1)])
        # First derivative is 0; second is -1/3, from h'' z^2.
        self.assertEqual(out[0].g[0],0)
        self.assertAlmostEqual(out[0].H[0,0],-mp.mpf(1)/3,places=60)

class ParentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        mp.dps=75;cls.m=Source();cls.ref=Refiner(cls.m);cls.old,cls.h=original_parent(cls.m)
        cls.full=step(cls.m,cls.ref,cls.old,cls.h)
        cls.a=step(cls.m,cls.ref,cls.old,cls.h/2)
        cls.b=step(cls.m,cls.ref,cls.a['state'],cls.h/2)
    def assertJetZero(self,q,tol='1e-50'):
        self.assertLess(max([abs(q.v),*map(abs,q.g),*map(abs,q.H)]),mp.mpf(tol))
    def test_owner_initial_and_constant_bits(self):
        self.assertEqual(self.m.q0[0],decode_bits('3feccccccccccccd'))
        self.assertEqual(self.m.b12,decode_bits('412135e886f9cb6f'))
    def test_new_root_residuals(self):
        self.assertEqual(len(self.ref.records),3)
        self.assertTrue(all(r['residual_norm']<mp.mpf('1e-62') for r in self.ref.records))
    def test_full_number_energy_differential_ledgers(self):
        for v in ledger(self.m,self.old,self.full['state'],self.full['events'],self.full['escape']).values():self.assertJetZero(v)
    def test_twohalf_number_energy_differential_ledgers(self):
        ev=[a+b for a,b in zip(self.a['events'],self.b['events'])];esc=self.a['escape']+self.b['escape']
        for v in ledger(self.m,self.old,self.b['state'],ev,esc).values():self.assertJetZero(v)
    def test_discarded_full_events_detected(self):
        ev=[a+b+f for a,b,f in zip(self.a['events'],self.b['events'],self.full['events'])]
        v=ledger(self.m,self.old,self.b['state'],ev,self.a['escape']+self.b['escape']+self.full['escape'])
        self.assertGreater(abs(v['energy'].v),mp.mpf('1e-12'))
    def test_full_thermal_parent_response_not_zero(self):
        self.assertGreater(abs(self.full['state'][0].g[3]),mp.mpf('1e-10'))
    def test_residual_parent_hessian_shapes(self):
        m=self.full['mixed'];self.assertEqual((m['R_p'].rows,m['R_p'].cols),(4,8))
        self.assertEqual((m['R_all_hess'][0].rows,m['R_all_hess'][0].cols),(12,12))
    def test_final_output_hessian_symmetry(self):
        out=self.b['state']+self.b['events']+[self.b['escape']]
        for q in out:self.assertLess(max(map(abs,q.H-q.H.T)),mp.mpf('1e-55'))
    def test_wrong_parent_frame_stage_two_rejected(self):
        bad=self.a['state'][:];j=bad[1];bad[1]=Jet(j.v,j.g,j.H,tuple('bad'+x for x in j.frame))
        with self.assertRaisesRegex(ValueError,'PARENT_FRAME'):step(self.m,self.ref,bad,self.h/2)
    def test_source_temperature_domain(self):
        bad=self.m.q0[:];bad[3]=0
        with self.assertRaisesRegex(ValueError,'TEMPERATURE'):self.m.source(bad)
    def test_negative_step_rejected(self):
        with self.assertRaisesRegex(ValueError,'STEP_DOMAIN'):self.ref.solve(self.m.q0,-1)
    def test_nan_bits_rejected(self):
        with self.assertRaisesRegex(ValueError,'NONFINITE'):decode_bits('7ff8000000000000')
    def test_bit_length_rejected(self):
        with self.assertRaisesRegex(ValueError,'BINARY64'):decode_bits('1')
    def test_half_local_chain_matches_shared_parent(self):
        # Differentiate stage 2 in its own seven old-state coordinates + the
        # same log full-step parameter, then explicitly pull back to original parent.
        fr=STATE_NAMES+('log_h_over_h_ref',)
        old=[Jet.variable(q.v,fr,i) for i,q in enumerate(self.a['state'])]
        h=self.m.h0/2*Jet.variable(0,fr,7).exp()
        local=step(self.m,self.ref,old,h)
        outer=local['state']+local['events']+[local['escape']]
        inner=self.a['state']+[Jet.variable(0,fr,7)]
        pulled=compose_outputs(outer,inner)
        direct=self.b['state']+self.b['events']+[self.b['escape']]
        for a,b in zip(pulled,direct):self.assertJetZero(a-b,'1e-55')
    def test_zero_step_identity(self):
        old,_=original_parent(self.m,with_log_step=False)
        r=Refiner(self.m);out=step(self.m,r,old,mp.mpf(0))
        for a,b in zip(out['state'],old):self.assertJetZero(a-b,'1e-55')
        for a in out['events']+[out['escape']]:self.assertJetZero(a,'1e-55')

if __name__=='__main__':unittest.main()
