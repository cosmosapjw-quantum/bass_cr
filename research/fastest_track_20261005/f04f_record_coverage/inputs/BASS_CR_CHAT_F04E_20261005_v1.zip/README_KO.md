# F04E 실행 결과

TASK_RETURN.json이 최종 상태다. 초기 logs/ENVIRONMENT.json의 rustc=null/native_runs=0은 설치 전 snapshot이며 현재 상태가 아니다. 상세 결과는 REPORT_KO.md, native proof of execution은 results/native01/EXECUTION.json과03.stdout, 새 분석 결과는 results/binding01/SUMMARY.json이다.

기존 F05 accepted transaction25개 값과 native 두 half의 값이 bit-for-bit로 맞는다. Reference gradient/Hessian의 단위변환은 제공하지만 native derivatives 또는 uniform event bound는 검증하지 않았다. Physics native BE calls2, full/history/certificate replay0이다.

코드 검토/후처리: `python -m unittest discover -s tests -v`; `python research/analyze_binding.py --output NEW_DIR`. Python과 mpmath가 필요하다. 이미 저장된 결과를 읽는 경로이며 native를 실행하지 않는다. `runtime/run_observation.py --execute --output NEW_DIR --rustc /PATH/TO/rustc`는 실제 두 BE를 다시 실행하는 별도 경로다. 동일 관측을 다시 만들 필요는 없다.

ZIP은 self-contained code/source/기존 첫 두 records/신규 native observation/retained reference jets와 근거 로그를 포함한다. Rust toolchain, 새 executable, old full gzip과 reference campaigns는 제외한다. 새 observations의 생성을 입증하는 compiler·source·binary hashes는 남긴다. GPG 서명 검증은 public key 부재로 미완료다.

Manifest의 모든 payload를 검사한 뒤 필요한 파일만 읽는다. Signed hexadecimal rational은 Fraction(int(numerator_hex,16),int(denominator_hex,16))로 정확히 복원한다. Actual Git/Drive/Dropbox delivery는 ZIP 밖의 *_DELIVERY_RECEIPT.json 또는 게시 문서에 있다.
