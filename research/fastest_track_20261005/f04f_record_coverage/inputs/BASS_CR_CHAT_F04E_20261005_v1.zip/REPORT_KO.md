# F04E: 실제 F05 accepted 기록과 사건·escape 계약의 연결

## 1. 이번 결과와 범위

F04D의 25출력 계약을 기존 REI-F05의 첫 accepted transaction에 연결했다. 저장된 거래 기록을 다시 적분하지 않고 읽었으며, 그 기록이 보존하지 않았던 두 half의 개별 사건률·사건 수·온도·escape를 실제 원본 FT03 코드의 두 BE 호출로 관측했다. 최종 상태7개·사건17개·escape increment1개가 기존 accepted 기록과 모두 binary64 비트 단위로 일치했다. 상태 중심의 추가14개 값과 모형20개 비트도 일치했다.

정적 F04 인증과 F05 전체 이력의 최초 성공은 owner의 이전 성과로 유지한다. 이번에는 독립 checker, full trial, history, old focused suite, reference root solve를 실행하지 않았다. 수신한 새 Rust 도구체인으로 실제 물리 native BE 호출2회를 수행했지만 새 production 코드·acceptance gate를 receiver에 추가하지 않았다. F08 owner의 코드는 변경하지 않았다.

완료한 것은 read-only adapter와 선택된 record의 **값 및 source-stage binding**이다. Retained reference gradient/Hessian의 단위변환도 산출했다. 그러나 binary64 실행 프로그램을 미분했다거나 event jets의 uniform remainder를 인증했다고 주장하지 않는다. Physical/scientific admission은 HOLD다.

## 2. 기준 소스와 복원

시작 및 종료 경계에서 확인한 bass_cr는 `565df6d2c2c3dc1f97abbc1ee0dac70521256861`, branch `research/r4q-gap-closure-20261001`이다. F04D 이후 추가된 두 commit은 공통 연구 동기화 문서와 백업 pointer였다. 최신 `docs/research_sync/REI-REC-BASS-SYNC02-20261005/HANDOFF_KO.md`를 읽어 F05 완료와 F04E의 선택적 소비 범위를 확인했다.

Receiver snapshot은 `rei_bianchi@7c5469101f8d6ef027c8c3119cc5c053e15ba1d9`, branch `forward/rust-reion-kernels-20260922`이다. F05는 정적 0..1e12s의 7000 accepted-step 이력과 whole-interval checker PASS를 보고한다. 그 보고를 수신했으며 이번 시험 수에 합산하지 않았다. F08·FLRW06·다른 원자 repo의 닫힌 campaign도 재실행하지 않았다.

Dropbox의 실제 F05 mirror에서 다음 세 파일을 회수했다. 단순한 provider ACK가 아니라 로컬 bytes의 Git blob이 해당 receiver commit과 일치하는지 직접 확인했다.

| 파일 | bytes | 일치한 Git blob |
|---|---:|---|
| source_identity.dat | 182814 | 4fa48a5a05faeeeb83170697ce38a1569101c0ce |
| level_0_transactions.jsonl.gz | 2514942 | 19163079b3b651b141e410c1744d853a213f97fd |
| checker_receipt.json | 1476 | 4bdd2f72d62c89ca587c818f19248e69460dda67 |

`source_identity.dat`는 first_interval이 compile-time에 기록한 파일명·byte length·원문 묶음이다. 이를 길이 기준으로 해석하여22개 원본 파일을 복원했다. 새 probe는 그중 hhe_events, microstep, thermal, atomic_provider, ft03_rates, ft03_controlled의 원 bytes6개를 그대로 포함한다. Minimal crate가 제공한 것은 에러 enum과 public 재export뿐이며 물리 함수 본문은 수정하지 않았다. F08의 최신 working implementation을 이 옛 실행 source 대신 섞지 않았다.

정본 `.gz`에서 첫 두 행만 별도 파일로 보존했다. 첫 accepted record가 이번 native 관측 대상이고, 두 번째 행은 누적 escape와 incremental escape를 구분하는 read-only 회귀시험에만 사용했다. 전체 `.gz`는 회수·hash 확인했지만 최종 패키지에서는 단일 record 재현에 불필요하므로 생략한다. 원 gzip identity, 첫 행 원 bytes와 SHA, 해당 source container는 남긴다.

## 3. Rust 환경의 실제 검증

첨부한 environment script는 `/mnt/data/rust-1.94.1-prefix`의 PATH·library path를 지정한다. 새 toolchain archive의 SHA256은 `294b3d81fa72e62581276290c60c81eb8b58498d333d422ca1dfc432877d0c40`, 크기는192287020bytes다. 로컬 prefix에 필요한 rustc·host std·cargo를 복원했으며 global 설치나 네트워크 package 설치는 하지 않았다. `install.sh`는 읽었지만 실행하지 않았다.

실행된 rustc는 `1.94.1 (e408947bf 2026-03-25)`, commit `e408947bfd200af42db322daf0fadfe7e26d3bd1`, LLVM21.1.8이다. Toolchain smoke의 compile/run과 이번 native 물리 probe의 compile/run은 모두 exit0이다. 이전의 이 환경 rustc 부재 blocker는 해소됐다. RUSTCORE 첨부는 별도 `bianchi_rustcore` crate로 확인했으며 F05 소스 대용으로 사용하거나 build하지 않았다.

암호학적 배포자 인증은 별개다. Detached signature 확인은 로컬 public key 부재로 `No public key`에서 끝났고 공식 checksum/key의 직접 네트워크 회수도 실패했다. 따라서 **사용자 제공 bytes의 local hash와 실제 실행은 확인했지만 공식 서명 authenticity는 NOT_VERIFIED**다. 이를 bad signature나 compiler 실행 실패로 분류하지 않는다. Toolchain 전체·폰트·불필요한 바이너리는 결과 ZIP에 넣지 않았다.

## 4. 실제 consumer와 25출력의 의미

실제 F05 경로는 `first_interval.rs::record`와 `adaptive_history.rs::certified_ft03_trial`이다. 원 record는 accepted flag, old/state8좌표, dt, parent box와 center, full/half1/half2 site의 normalized center, 합산한17events, ledgers를 저장한다. 실제 accepted state는 half2이며 events는 원 `Ft03Events::plus(half1.events,half2.events)`다.

F05가 사용한 StepControl은 max_iterations=200, residual_tolerance=1e-15다. F04의 과거 기본값80/1e-14를 가져오지 않았다. 첫 record의 t0=0, h=1e9s를 고정했다. 추가 probe는 h/2=5e8s의 half1과 half2만 실제 `ft03_implicit_step`으로 평가했다. Full solve와 interval math는 호출하지 않았다. 후속 `ft03_rhs` 두 번은 저장 endpoint에서 필요한 rate 필드를 관측하기 위한 재평가다. 내부 be_endpoint_residual 메모리를 interception한 것으로 부르지 않는다.

두 endpoint의 물리 state와 rate bits를 출력하고 원 plus로 events를 합산했다. 결과는 다음과 같다.

| 비교/관측 | 결과 |
|---|---|
| final7state + accepted17events + escape increment | 25/25 bit identity |
| 두 half의 normalized center | 14/14 bit identity |
| model constants11 + cross sections9 | 20/20 bit identity |
| half1 / half2 iterations | 3 / 3 |
| half1 T / half2 T [K] | 49999.78787800223 / 49999.575801042796 |
| source reported residual norm | 9.860056429103134e-17 / 1.5215560008779607e-16 |

새 probe에는 자체 accepted 선언이 없다. Acceptance는 기존 F05 record와 그에 결합된 owner checker에서 계승하며, source/input/step identity와 위25개 값의 재현으로 observation을 그 record에 연결한다. 해당 시점의 native derivatives나 interval proof를 새로 발급한 것이 아니다.

## 5. 단위변환과 retained jet 계약

F04D의 정규화 좌표는 q=(xH,xHeII,xHeIII,w,p0,p1,p2), w=u/(nH*epsilon_eV), p=N/nH다. Physical output의 에너지 scale은 nH*epsilon_eV, photon·reaction count scale은 nH이며 분율 scale은1이다. Escape는 state의 누적 값이 아니라 `escaped_new-escaped_old`로 변환한다.

일곱 physical initial coordinates를 P라 쓰고 q=S P, 물리 출력 V=D O(q)로 쓰면 고정 nH·epsilon_eV에서

\[
D_PV=D\,D_qO\,S,\qquad
(D_P^2V)_i=D_i S^{\mathsf T}(D_q^2O)_i S.
\]

이 선형변환을 이전에 저장한25출력의70자리 decimal approximation에 Fraction으로 적용했다. 변환 산술은 exact지만 입력 derivative 자체의 수치근사 오차가 없어지지는 않는다. 8번째 log-step 방향은 이전처럼 형식적인 점미분 방향이며 새 certified uncertainty가 아니다. Native FP 알고리즘의 derivative를 측정한 것이 아니다.

중요한 입력 차이도 보존했다. 원 native physical old.u를 정확한 nH*epsilon_eV로 나눈 값과 F04D의 saved normalized center는 엄밀하게 같지 않다. normalized input의 최대 차이는1.4574269354471891e-15다. 따라서 이전 exact-real root certificate와 이번 physical native record를 무조건 같은 입력으로 간주하지 않았다.

이 차이를 포함한 단순 finite parity에서 state7의 normalized 최대 절대차는7.246594223321078e-16, nonzero event·escape의 최대 상대차는1.8606620581117634e-15였다. 사전 기준1e-12와5e-12를 각각 통과했고 원래 막힌 PI3채널은 정확0이다. 저장 J/H로 계산한 입력 이동 Taylor 진단도 제공하지만 새로운 remainder가 없으므로 증명 상계로 사용하지 않는다. 같은 실제 endpoint에서 source를80자리 MP로 직접 평가한 event-rate 최대 상대차는2.1875690796504245e-15다. 이것도 유한점 비교이며 공식 physical accuracy나80자리 보장을 뜻하지 않는다.

## 6. 동일 stage의 잔차·장부·assembly 분리

각 half에서 저장 binary64 값을 정확 유리수로 읽는다. r=Delta y-h_j*fhat, r_escape=Delta escape-h_j*f_escapehat로 두고, 전자+광자 수 가중치 wN=(nH,nHe,2nHe,0,1,1,1)를 사용한다. CI-RR-DR의 net event density를 E, 같은 관측 rate의 net을 e라 쓰면

\[
D_N=w_N\Delta y-E
=w_Nr+h_j(w_N\hat f-\hat e)-(E-h_j\hat e).
\]

이는 solver-coordinate residual, source의 산술 장부 차이, event multiplication/assembly의 차이를 분리하는 정확한 항등식이다. fhat와 event rate는 현재 endpoint에서 재평가한 실제 source 출력이며 원 solver 내부 버퍼에서 직접 추출한 것은 아니다.

동일한 binding/photon energy의 가중치 wE를 사용하면

\[
D_E=w_E\Delta y+\Delta e_{esc}
=w_Er+r_{esc}+h_j(w_E\hat f+\hat f_{esc}).
\]

두 half에서 이 항등식을 정확 분수로 확인했다. Accepted event의 floating addition도 별도로 기록한다. Eacc-(E1+E2)의 rational difference를0으로 버리지 않았다. 이 항을 포함하면 aggregate number defect는 두 stage defect의 합에서 정확하게 복원되고 에너지의 누적 escape는 망원합된다.

선택 record의 총 number defect는 -3.7214657111635744e-17 per H, energy defect는 -7.234257889366825e-16 eV/H다. 이는 저장된 실수 값의 실제 차이며 uniform uncertainty bound가 아니다. 원 F05 acceptance를 새로운 scalar 진단으로 대체하지 않는다.

## 7. stage 가중치의 식별 불가능성

합산 사건 E=E1+E2만 알고 stage weights w1,w2가 다르면, W=w1 E1+w2 E2는 E만으로 정해지지 않는다. 같은 합을 보존한 E1→E1-delta, E2→E2+delta에 대해 W는 (w2-w1)delta만큼 달라진다. 원 endpoint rates, temperature, species와 별개로 성립하는 단순한 정보 손실이다.

최종 stage weight만 전체에 곱하면 정확 오차는

\[
W-w_2(E_1+E_2)=(w_1-w_2)E_1.
\]

이번 PI_0_0의 관측 두 half 사건에 인위적 weights=(1,2)를 사용한 부정 대조에서는 이 오차가 -1.6562983444554425e-9 cm^-3였다. 이 weights는 실제 scale factor나 FLRW expansion을 계산한 것이 아니다. 실제 stage 가중치가 없음을 숨기기 위한 대입도 아니다. 둘이 같으면 aggregate가 충분하다는 양성 대조도 있다.

비음수 사건 수이며 weights만 주어졌을 때는 min(w1,w2)E≤W≤max(w1,w2)E만 보장할 수 있고, 일반적으로 더 좁은 값은 stage 정보가 필요하다. Escape에도 이 모형의 비음수 increment일 때 같은 논리가 적용된다. 부호가 있는 work term에는 이 비음수 가정을 자동 이식하지 않는다. Parent-dependent weight의 derivative가 필요한 경우에도 w*E의 product-rule cross terms가 별도로 필요하다. 이번 retained static jets만으로 expanding a^3/a^4 measure를 승인하지 않는다.

## 8. 검증·미완료·후속

새 focused tests28개와5개 Python 파일의 syntax 검사 통과. 그중 rejected-path 거절1개에 실제 assertion RED→GREEN을 보존했고 나머지27개는 tests-after다. 25값 bit reproduction, record/site/time/model validation, missing fields·NaN·음수 사건, escape increment, exact linear jet transform과 stage-weight 반례를 검사했다. 독립 human/agent review와 proof assistant 검증은 없다.

물리 native probe 실행1회, 두 BE 호출, 같은 endpoint RHS 재평가2회, 별도 toolchain smoke1회다. Native history·full-trial·old suite·interval checker·원자 적분·reference root solve·새 numerical differentiation·owner box 확장·F08 mutation은0이다. 물리 native 실행은 성공했고 실패 retry는 없었다. GPG key 부재와 direct network 회수 실패는 환경/인증 blocker로 별도 보존했다.

새 code는 read-only F05 adapter와 compiled observation wrapper다. Receiver production 경로를 수정하지 않았고 native derivative consumer나 uniform event/escape Taylor remainder는 아직 없다. 이미 완료된 정적 state certificate 및 F05 history는 유지한다. CR_OFF_FASTEST, precision atomic PARKED, G02 unresolved, physical production HOLD, capture=false, all_bound OPEN, b_grid NO_GO와 CR 관측 null을 유지한다. Legacy atomic 승인·318patch·full-K·CR-on은 사용하지 않았다.

다음 선택적 보조 작업은 기존 owner의 static source/site box를 재사용한 event/escape observable enclosure 확장, 또는 실제 새 F08 accepted-stage consumer의 read-only 연결이다. Live contract에서 요구된 범위만 택하며 새로운 mandatory gate를 만들지 않는다. 이번 native two-half와28시험을 동일 목적으로 반복하지 않는다.

## 9. 재현과 evidence

`python -m unittest discover -s tests -v`와 `python research/analyze_binding.py --output NEW_DIRECTORY`는 기존 저장 observation을 읽는 검토 경로다. 이미 완료한 물리 관측은 재실행할 필요가 없다. `runtime/run_observation.py --execute --output NEW_DIRECTORY`는 두 BE를 실제 다시 호출하는 별도 명시적 경로이고 create-only다. 읽기 전용 분석과 분리했다. 필요한6개 physics source 원 bytes와 당시 source_identity container, old record, emitted bit CSV, 실제 argv·exit와 compiler/binary hashes를 패키지에 보존한다.

Reference derivatives는 F04D archive에서 필요한 파일만 검증해 상속했다. 전체 old archive, Rust toolchain, 불필요한 executable, RUSTCORE contents, 다른 reference campaign을 ZIP에 넣지 않았다. 저장 JSON의 signed hexadecimal 분자·분모는 Fraction(int(numerator_hex,16),int(denominator_hex,16))로 읽는다.

게시/백업의 최종 성공은 ZIP 밖의 실제 DELIVERY_RECEIPT 및 Git 요약에 기록한다. ZIP 안에 미래 provider 성공을 미리 쓰지 않는다. R1 upload identity와 이번 특정3파일의 실제 source readback, 전체 archive restore, 과학적 검증을 구분한다.
