"""Create an immutable, compact evidence archive; omit toolchains and executables."""
from pathlib import Path
import json,zipfile,hashlib
BASE=Path(__file__).resolve().parents[1]
OUT=BASE.parent/(BASE.name+'_v1.zip')
EXCLUDE={'inputs/RUST_TAR_FILELIST.txt','inputs/rust_install.sh','runtime/toolchain_smoke',
         'results/native01/observe_stages','inputs/receiver/level_0_transactions.jsonl.gz','FILE_MANIFEST.json'}
def keep(p):
    r=p.relative_to(BASE).as_posix()
    return p.is_file() and r not in EXCLUDE and '__pycache__' not in p.parts and 'gnupg' not in p.parts and p.suffix!='.pyc'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    if OUT.exists():raise FileExistsError(OUT)
    paths=sorted(p for p in BASE.rglob('*') if keep(p))
    manifest={'schema':'bass-cr.payload-manifest.v1','task':'F04E','files':[
        {'path':p.relative_to(BASE).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths],
        'excluded_raw_recovered_gzip_identity':'inputs/RECEIVER_RECOVERY.json',
        'excluded_binaries':'compiler and probe executable bytes omitted; execution hashes preserved'}
    mp=BASE/'FILE_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in paths+[mp]:z.write(p,p.relative_to(BASE).as_posix())
    with zipfile.ZipFile(OUT) as z:
        assert z.testzip() is None
        for f in manifest['files']:
            data=z.read(f['path']);assert len(data)==f['bytes'] and sha(data)==f['sha256']
        members=len(z.namelist())
    receipt={'archive':OUT.name,'bytes':OUT.stat().st_size,'sha256':sha(OUT.read_bytes()),
             'members':members,'payload_count':len(manifest['files']),'CRC_and_payload_hashes_verified':True,
             'manifest_sha256':sha(mp.read_bytes())}
    (OUT.parent/(BASE.name+'_ARCHIVE_IDENTITY.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
