"""Read-only analysis of one existing F05 transaction and the bounded site observation.

No native invocation, root finding, numerical differentiation or old suite replay.
"""
from pathlib import Path
import argparse,json,sys,hashlib,struct
from fractions import Fraction as F
from mpmath import mp
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'src'))
from receiver_binding import (exact,binary64_bits,parse_observation,record_to_contract,
    normalize_state,scales,transform_reference_jet,weighted_stage_total,NAMES)
sys.path.insert(0,str(BASE/'vendor/f04d/src'))
from ft03_parent import Source

def enc(x):
    if isinstance(x,F):return {'numerator_hex':hex(x.numerator),'denominator_hex':hex(x.denominator)}
    if isinstance(x,mp.mpf):return mp.nstr(x,65)
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    return x

def m(x):
    x=exact(x);return mp.mpf(x.numerator)/mp.mpf(x.denominator)

def diffbits(a,b):return binary64_bits(a)==binary64_bits(b)
def maximum(a):return max(map(abs,a),default=F(0))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False);mp.dps=80
    def save(name,obj):(args.output/name).write_text(json.dumps(enc(obj),indent=2,ensure_ascii=False)+'\n')
    rec=json.loads((BASE/'inputs/F05_FIRST_TRANSACTION.json').read_text())
    obs=parse_observation((BASE/'results/native01/03.stdout').read_text())
    parent=json.loads((BASE/'vendor/f04d/inputs/OWNER_PARENT_EXTRACT.json').read_text())
    expected_model=parent['constants_bits'];model_matches=[binary64_bits(v)==b for v,b in zip(obs['CONSTANTS'],expected_model)]
    sigma_matches=[binary64_bits(v)==b for v,b in zip(sum([obs[f'SIGMA{a}'] for a in range(3)],[]),parent['sigma_bits'])]
    if not all(model_matches+sigma_matches):raise ValueError('SOURCE_MODEL_BIT_MISMATCH')
    nh,nhe,c,kb,ev,*energy=obs['CONSTANTS'];chi=energy[:3];Eg=energy[3:]
    if obs['CONTROL']!=[1e9,5e8,1e-15,200.0]:raise ValueError('CONTROL_BINDING')
    if not all(diffbits(a,b) for a,b in zip(obs['OLD'],rec['old_state'])):raise ValueError('OLD_INPUT_BITS')
    contract=record_to_contract(rec,nh,ev)
    physical_native=obs['HALF2_STATE'][:7]+obs['SUM_EVENTS']+[obs['ESCAPE_INCREMENT'][2]]
    value_matches=[diffbits(a,b) for a,b in zip(physical_native,contract['physical'])]
    centers=[]
    for label,site in [('HALF1',rec['sites'][1]),('HALF2',rec['sites'][2])]:
        y=obs[label+'_STATE'];normalized=y[:3]+[y[3]/(nh*ev)]+[v/nh for v in y[4:7]]
        centers.append([diffbits(a,b) for a,b in zip(normalized,site['center'])])
    if not all(value_matches) or not all(sum(centers,[])):
        save('BIT_MISMATCH.json',{'names':NAMES,'matches25':value_matches,'centers':centers})
        raise ValueError('F05_REPLAY_VALUE_MISMATCH')
    save('RECORD_BINDING_EXACT.json',{'record_sha256':sha(BASE/'inputs/F05_FIRST_TRANSACTION.json'),
         'observation_sha256':sha(BASE/'results/native01/03.stdout'),'names':NAMES,
         'existing_record_normalized':contract['normalized'],'observed_physical':list(map(exact,physical_native)),
         'native_output25_bits_match':value_matches,'half_centers14_bits_match':centers,
         'model20_bits_match':model_matches+sigma_matches,'normalized_input':contract['initial_normalized'],
         'acceptance_inherited':True,'new_interval_verification':False})
    # Stored 70-digit jets remain numerical approximations. All unit operations here are exact.
    prior=json.loads((BASE/'vendor/f04d/results/run01/CENTRAL_PARENT_JETS.json').read_text())
    if tuple(prior['names'])!=NAMES:raise ValueError('REFERENCE_NAMES')
    jets=prior['two_half_cumulative'];values=[F(j['value']) for j in jets]
    q0=[F(struct.unpack('>d',bytes.fromhex(v))[0]) for v in parent['center_bits']]
    dq=[contract['initial_normalized'][i]-q0[i] for i in range(7)]+[F(0)]
    native_norm=[exact(v)/s for v,s in zip(physical_native,scales(nh,ev))]
    rawerr=[native_norm[i]-values[i] for i in range(25)]
    predicted=[];physical_jets=[];output_scales=scales(nh,ev)
    input_inverse=[1/x for x in output_scales[:7]]+[F(1)]
    for i,j in enumerate(jets):
        g=[F(row[0]) for row in j['gradient']];H=[[F(a) for a in row] for row in j['hessian']]
        predicted.append(values[i]+sum(g[a]*dq[a] for a in range(8))+F(1,2)*sum(H[a][b]*dq[a]*dq[b] for a in range(8) for b in range(8)))
        v,grad,hess=transform_reference_jet(values[i],g,H,output_scales[i],input_inverse)
        physical_jets.append({'name':NAMES[i],'value':v,'gradient':grad,'hessian':hess})
    relative=[abs(rawerr[i]/values[i]) for i in range(7,25) if values[i]]
    zero_indices=[i for i in range(7,25) if not values[i]]
    parity=maximum(rawerr[:7])<F('1e-12') and max(relative)<F('5e-12') and all(native_norm[i]==0 for i in zero_indices)
    if not parity:raise ValueError('PREREGISTERED_FINITE_PARITY_FAILED')
    save('UNIT_TRANSFORMED_REFERENCE_JETS.json',{'source_sha256':sha(BASE/'vendor/f04d/results/run01/CENTRAL_PARENT_JETS.json'),
         'status':'LINEAR_UNIT_TRANSFORM_OF_STORED_REFERENCE_APPROXIMATIONS',
         'parents':['xH0','xHeII0','xHeIII0','u0_erg_cm3','N0_cm3','N1_cm3','N2_cm3','log_h_over_href'],
         'native_program_derivatives':False,'uniform_remainder':None,'outputs':physical_jets})
    save('VALUE_PARITY_EXACT.json',{'delta_normalized_input':dq,'raw_output_differences':rawerr,
         'input_shift_taylor_diagnostic_difference':[native_norm[i]-predicted[i] for i in range(25)],
         'shift_diagnostic_has_uniform_remainder':False,'same_exact_input_as_F04D':all(x==0 for x in dq),
         'state_max_abs':maximum(rawerr[:7]),'event_escape_max_relative':max(relative),'disabled_exact_zero_indices':zero_indices})
    # Rational residual decomposition on SAME-POINT observed float RHS and event rates.
    nhq,nheq,evq=map(exact,(nh,nhe,ev));half=exact(rec['dt_s'])/2
    wN=[nhq,nheq,2*nheq,F(0),F(1),F(1),F(1)]
    wE=[nhq*exact(chi[0])*evq,nheq*exact(chi[1])*evq,nheq*(exact(chi[1])+exact(chi[2]))*evq,
        F(1),*[exact(e)*evq for e in Eg]]
    net=lambda e:sum(e[9:12])-sum(e[12:15])-sum(e[15:17])
    stage_reports=[];source_reports=[];model=Source();state_scale=output_scales[:7]
    for label,old in [('HALF1',obs['OLD']),('HALF2',obs['HALF1_STATE'])]:
        old=list(map(exact,old));new=list(map(exact,obs[label+'_STATE']));rhs=list(map(exact,obs[label+'_RHS']))
        rates=list(map(exact,obs[label+'_RATES']));events=list(map(exact,obs[label+'_EVENTS']))
        esc_rate=exact(obs[label+'_AUX'][1]);r=[new[i]-old[i]-half*rhs[i] for i in range(7)]
        resc=new[7]-old[7]-half*esc_rate
        epsN=sum(wN[i]*rhs[i] for i in range(7))-net(rates)
        epsEvt=net(events)-half*net(rates)
        dN=sum(wN[i]*(new[i]-old[i]) for i in range(7))-net(events)
        epsE=sum(wE[i]*rhs[i] for i in range(7))+esc_rate
        dE=sum(wE[i]*(new[i]-old[i]) for i in range(7))+new[7]-old[7]
        assert dN==sum(wN[i]*r[i] for i in range(7))+half*epsN-epsEvt
        assert dE==sum(wE[i]*r[i] for i in range(7))+resc+half*epsE
        stage_reports.append({'stage':label,'dt_s':half,'stored_rhs_residual':r,'escape_residual':resc,
            'source_number_arithmetic_defect':epsN,'event_count_assembly_defect':epsEvt,
            'number_ledger_defect':dN,'source_energy_arithmetic_defect':epsE,'energy_ledger_defect':dE,
            'event_assembly_all17':[events[i]-half*rates[i] for i in range(17)],
            'identities_exact':True,'temperature_K_observed':obs[label+'_AUX'][0]})
        # Independent high precision evaluation at exact normalized PHYSICAL observed state;
        # no reference root computation, and no numerical derivatives performed.
        y=[m(new[i]/state_scale[i]) for i in range(7)]
        fr,er,esc=model.source(y);physical_fr=[fr[i]*m(state_scale[i]) for i in range(7)]
        physical_er=[e*m(nhq) for e in er]
        rateerr=[abs(m(rates[i])-physical_er[i])/abs(physical_er[i]) for i in range(17) if physical_er[i]!=0]
        source_reports.append({'stage':label,'native_T_minus_exact_EOS_T':m(exact(obs[label+'_AUX'][0]))-model.temp(y),
            'event_rate_relative_discrepancy_max':max(rateerr),
            'rhs_physical_differences':[m(rhs[i])-physical_fr[i] for i in range(7)],
            'escape_rate_difference':m(esc_rate)-esc*m(nhq*evq),
            'scope':'same observed point, source reevaluation; not full floating-program enclosure'})
    e1=list(map(exact,obs['HALF1_EVENTS']));e2=list(map(exact,obs['HALF2_EVENTS']));ea=list(map(exact,obs['SUM_EVENTS']))
    final=list(map(exact,obs['HALF2_STATE']));initial=list(map(exact,obs['OLD']))
    agg_arith=[ea[i]-e1[i]-e2[i] for i in range(17)]
    totalN=sum(wN[i]*(final[i]-initial[i]) for i in range(7))-net(ea)
    totalE=sum(wE[i]*(final[i]-initial[i]) for i in range(7))+final[7]-initial[7]
    assert totalN==sum(r['number_ledger_defect'] for r in stage_reports)-net(agg_arith)
    assert totalE==sum(r['energy_ledger_defect'] for r in stage_reports)
    save('STAGE_RESIDUAL_DECOMPOSITION_EXACT.json',{'stages':stage_reports,'aggregate_addition_defects':agg_arith,
         'total_number_defect':totalN,'total_energy_defect':totalE,
         'internal_rate_memory_intercepted':False,'deterministic_same_endpoint_rhs_reevaluated':True})
    save('SOURCE_POINT_COMPARISON.json',source_reports)
    # Counterexample: SAME stored aggregate, DIFFERENT weighted moment; not a new FLRW experiment.
    weight=[F(1),F(2)];actual=weighted_stage_total([e1[0],e2[0]],weight)
    endpoint_only=weight[1]*(e1[0]+e2[0]);difference=actual-endpoint_only
    assert difference==(weight[0]-weight[1])*e1[0] and difference!=0
    # A partition shift keeps the total fixed but changes the weighted total.
    shift=e1[0]/2;alternate=weighted_stage_total([e1[0]-shift,e2[0]+shift],weight)
    assert (e1[0]-shift)+(e2[0]+shift)==e1[0]+e2[0] and alternate!=actual
    save('STAGE_WEIGHT_COUNTEREXAMPLE.json',{'synthetic_weights':weight,'physical_cosmological_weights':False,
        'event':'PI_0_0','total_same':e1[0]+e2[0],'weighted_observed_partition':actual,
        'weighted_alternative_partition':alternate,'final_endpoint_only_error':difference,
        'theorem':'aggregate alone does not identify unequal stage weighting'})
    summary={'task':'F04E','status':'SCOPED_RECORD_VALUE_AND_STAGE_BINDING_PASS',
        'record_value_bits_matching':sum(value_matches),'record_value_bits_total':25,
        'source_model_bits_matching':sum(model_matches+sigma_matches),'source_model_bits_total':20,
        'half_normalized_centers_bits_matching':sum(sum(centers,[])),'half_normalized_centers_total':14,
        'native_BE_calls':2,'full_trial_calls':0,'native_certification_calls':0,'history_replay':False,
        'reference_root_solves':0,'new_derivative_evaluations':0,'inherited_reference_jet_outputs':25,
        'native_temperatures_K':[obs[s+'_AUX'][0] for s in ['HALF1','HALF2']],
        'native_iterations':[int(obs[s+'_AUX'][3]) for s in ['HALF1','HALF2']],
        'native_reported_residual_norms':[obs[s+'_AUX'][2] for s in ['HALF1','HALF2']],
        'delta_q0_max':float(maximum(dq)),
        'finite_reference_state_max_abs':float(maximum(rawerr[:7])),
        'finite_reference_event_escape_max_relative':float(max(relative)),
        'disabled_channels_exact_zero':len(zero_indices),
        'source_event_rate_relative_discrepancy_max':float(max(mp.mpf(r['event_rate_relative_discrepancy_max']) for r in source_reports)),
        'total_number_defect_per_H':float(totalN/nhq),
        'total_energy_defect_eV_per_H':float(totalE/(nhq*evq)),
        'synthetic_final_stage_weight_error_PI0_cm3':float(difference),
        'native_derivatives_verified':False,'event_uniform_remainder_verified':False,
        'physical_admission':'HOLD','CR_dispatch_observations':None}
    save('SUMMARY.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
