//! Additional observation of the two half-step sites of one existing F05 record.
//! This program does NOT run the history, interval checker or full trial.
#![allow(dead_code)]
#[derive(Debug)] pub enum ForwardError { InvalidInput(&'static str) }
#[path="../receiver_snapshot/rust/rei_microphysics/src/hhe_events.rs"] mod hhe_events;
#[path="../receiver_snapshot/rust/rei_microphysics/src/microstep.rs"] mod microstep;
#[path="../receiver_snapshot/rust/rei_microphysics/src/thermal.rs"] mod thermal;
#[path="../receiver_snapshot/rust/rei_microphysics/src/atomic_provider.rs"] mod atomic_provider;
#[path="../receiver_snapshot/rust/rei_microphysics/src/ft03_rates.rs"] mod ft03_rates;
#[path="../receiver_snapshot/rust/rei_microphysics/src/ft03_controlled.rs"] mod ft03_controlled;
pub use hhe_events::*;
pub use microstep::StepControl;
pub use atomic_provider::{Absorber,AtomicProvider};
use ft03_controlled::*;
include!("record_input.rs");
fn emit(name: &str, values:&[f64]) {
    for (i,v) in values.iter().enumerate() {
        println!("{name},{i},{:016x},{v:.17e}",v.to_bits());
    }
}
fn state(name:&str, s:&HHeState) {
    emit(name,&[s.fractions[0],s.fractions[1],s.fractions[2],s.u_erg_cm3,
        s.photon_cm3[0],s.photon_cm3[1],s.photon_cm3[2],s.escaped_erg_cm3]);
}
fn events(name:&str,e:&Ft03Events) {
    let mut v=Vec::with_capacity(17);
    for a in 0..3 { v.extend(e.photo_per_cm3[a]); }
    v.extend(e.collision_per_cm3); v.extend(e.recombination_per_cm3); v.extend(e.dr_per_cm3);
    emit(name,&v);
}
fn stage(name:&str,m:&Ft03Model,s:&Ft03Step) {
    state(&format!("{name}_STATE"),&s.state);
    events(&format!("{name}_EVENTS"),&s.events);
    let r=ft03_rhs(m,&s.state).expect("same endpoint RHS");
    emit(&format!("{name}_RHS"),&r.derivative);
    let mut rates=Vec::with_capacity(17);
    for a in 0..3 {rates.extend(r.photo_per_cm3_s[a]);}
    rates.extend(r.collision_per_cm3_s);rates.extend(r.recombination_per_cm3_s);rates.extend(r.dr_per_cm3_s);
    emit(&format!("{name}_RATES"),&rates);
    emit(&format!("{name}_AUX"),&[m.gas.temperature(&s.state).unwrap(),
         r.escaped_energy_rate,s.residual_norm,s.iterations as f64]);
}
fn main() {
    let m=Ft03Model::controlled().expect("pinned model");
    emit("CONSTANTS",&[m.gas.n_h_cm3,m.gas.n_he_cm3,m.gas.c_cm_s,m.gas.kb_erg_k,m.gas.ev_erg,
        m.gas.threshold_ev[0],m.gas.threshold_ev[1],m.gas.threshold_ev[2],
        m.gas.photon_energy_ev[0],m.gas.photon_energy_ev[1],m.gas.photon_energy_ev[2]]);
    for a in 0..3 {emit(&format!("SIGMA{a}"),&m.gas.sigma_cm2[a]);}
    let old=HHeState {fractions:[f64::from_bits(OLD_BITS[0]),f64::from_bits(OLD_BITS[1]),f64::from_bits(OLD_BITS[2])],
        u_erg_cm3:f64::from_bits(OLD_BITS[3]),
        photon_cm3:[f64::from_bits(OLD_BITS[4]),f64::from_bits(OLD_BITS[5]),f64::from_bits(OLD_BITS[6])],
        escaped_erg_cm3:f64::from_bits(OLD_BITS[7])};
    state("OLD",&old);
    let dt=f64::from_bits(DT_BITS);let control=StepControl{max_iterations:200,residual_tolerance:1e-15};
    emit("CONTROL",&[dt,dt/2.,control.residual_tolerance,control.max_iterations as f64]);
    let h1=ft03_implicit_step(&m,&old,dt/2.,control).expect("half1 observation");
    let h2=ft03_implicit_step(&m,&h1.state,dt/2.,control).expect("half2 observation");
    stage("HALF1",&m,&h1);stage("HALF2",&m,&h2);
    events("SUM_EVENTS",&h1.events.plus(h2.events));
    emit("ESCAPE_INCREMENT",&[h1.state.escaped_erg_cm3-old.escaped_erg_cm3,
        h2.state.escaped_erg_cm3-h1.state.escaped_erg_cm3,
        h2.state.escaped_erg_cm3-old.escaped_erg_cm3]);
    println!("BE_CALLS,2");
}
