// Generated from the exact stored F05 JSON line.
const OLD_BITS:[u64;8]=[0x3feccccccccccccd,0x3fd3333333333333,0x3fe3333333333333,0x3ce3a803a7d621e9,0x3ed4f8b588e368f1,0x3ea0c6f7a0b5ed8e,0x3e7ad7f29abcaf49,0x0];
const DT_BITS:u64=0x41cdcd6500000000;
