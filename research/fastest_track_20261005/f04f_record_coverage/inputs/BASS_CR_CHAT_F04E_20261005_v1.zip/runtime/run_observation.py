"""Bounded, create-only execution; explicit --execute required to observe 2 BE sites."""
from pathlib import Path
import argparse,hashlib,json,struct,subprocess,os,time
BASE=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--output',type=Path,required=True)
    p.add_argument('--rustc',type=Path,default=Path('/mnt/data/rust-1.94.1-prefix/bin/rustc'));a=p.parse_args()
    if not a.execute:raise SystemExit('Use --execute only for the explicitly bounded two-site observation.')
    a.output.mkdir(parents=True,exist_ok=False)
    src=BASE/'receiver_snapshot/rust/rei_microphysics/src'
    lock=json.loads((BASE/'inputs/RECEIVER_SOURCE_IDENTITIES.json').read_text())
    # Snapshot hash list is an intake artifact; the original container hash is recorded separately.
    recordpath=BASE/'inputs/F05_FIRST_TRANSACTION.json';record=json.loads(recordpath.read_text())
    if record.get('accepted') is not True or record['dt_s']!=1e9 or record['t0_s']!=0:
        raise ValueError('OBSERVATION_SCOPE')
    bits=lambda v:struct.unpack('>Q',struct.pack('>d',v))[0]
    generated='// Generated from the exact stored F05 JSON line.\nconst OLD_BITS:[u64;8]=['+','.join(hex(bits(v)) for v in record['old_state'])+'];\nconst DT_BITS:u64='+hex(bits(record['dt_s']))+';\n'
    inputrs=BASE/'runtime/record_input.rs'
    if inputrs.exists() and inputrs.read_text()!=generated:raise ValueError('INPUT_CONFLICT')
    inputrs.write_text(generated)
    env=os.environ.copy();prefix=a.rustc.parent.parent
    env['LD_LIBRARY_PATH']=str(prefix/'lib')+':'+env.get('LD_LIBRARY_PATH','')
    exe=a.output/'observe_stages'
    commands=[['/usr/bin/env','true'],[str(a.rustc),'-vV'],[str(a.rustc),'--edition=2021','-O',str(BASE/'runtime/observe_stages.rs'),'-o',str(exe)],[str(exe)]]
    receipt={'source_contract':'read-only F05 accepted record0; no full/certification/history','commands':[],
             'record_sha256':sha(recordpath),'wrapper_sha256':sha(BASE/'runtime/observe_stages.rs'),'input_rs_sha256':sha(inputrs),
             'rustc_sha256':sha(a.rustc),'physics_BE_calls_planned':2,'physics_BE_calls_completed':0,
             'source_files':{n:sha(src/n) for n in ['hhe_events.rs','microstep.rs','thermal.rs','atomic_provider.rs','ft03_rates.rs','ft03_controlled.rs']}}
    for i,argv in enumerate(commands):
        start=time.perf_counter();r=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=45)
        (a.output/f'{i:02d}.stdout').write_text(r.stdout);(a.output/f'{i:02d}.stderr').write_text(r.stderr)
        receipt['commands'].append({'argv':argv,'exit_code':r.returncode,'wall_s':time.perf_counter()-start})
        (a.output/'EXECUTION.json').write_text(json.dumps(receipt,indent=2)+'\n')
        if r.returncode:raise SystemExit(f'FAILED_COMMAND_{i}: '+r.stderr)
    receipt['physics_BE_calls_completed']=2;receipt['binary_sha256']=sha(exe)
    (a.output/'EXECUTION.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'build_exit':receipt['commands'][2]['exit_code'],'run_exit':receipt['commands'][3]['exit_code'],'physics_BE_calls':2,'output':str(a.output)}))
if __name__=='__main__':main()
