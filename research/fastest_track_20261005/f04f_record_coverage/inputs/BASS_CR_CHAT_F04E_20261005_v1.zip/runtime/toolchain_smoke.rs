fn main(){assert_eq!(2u64.pow(10),1024); println!("RUST_SMOKE_PASS");}
