import sys,unittest,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from receiver_binding import record_to_contract
class AcceptedPath(unittest.TestCase):
    def test_rejected_trial_is_not_an_accepted_event_payload(self):
        record=json.loads((ROOT/'inputs/F05_FIRST_TRANSACTION.json').read_text())
        record['accepted']=False
        with self.assertRaisesRegex(ValueError,'NOT_ACCEPTED'):
            record_to_contract(record,1e-4,1.602176634e-12)
if __name__=='__main__':unittest.main()
