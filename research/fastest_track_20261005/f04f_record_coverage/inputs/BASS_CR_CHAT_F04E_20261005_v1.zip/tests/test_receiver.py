"""Focused tests for NEW receiver mapping, not the old scientific campaigns."""
import copy,json,sys,unittest
from fractions import Fraction as F
from pathlib import Path
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE/'src'))
from receiver_binding import (record_to_contract,exact,parse_observation,transform_reference_jet,
                             weighted_stage_total,binary64_bits,NAMES,scales)
NH=1e-4;EV=1.602176634e-12

def rec():return json.loads((BASE/'inputs/F05_FIRST_TRANSACTION.json').read_text())
def obs_text():return (BASE/'results/native01/03.stdout').read_text()

class Boundary(unittest.TestCase):
    def test_actual_record_exposes_25_values_and_unobserved_stage_fields(self):
        a=record_to_contract(rec(),NH,EV)
        self.assertEqual(len(a['normalized']),25);self.assertEqual(a['names'],NAMES)
        self.assertIsNone(a['stage_events']);self.assertIsNone(a['native_derivatives'])
    def test_existing_second_record_escape_is_increment_not_total(self):
        r=json.loads((BASE/'inputs/F05_SECOND_TRANSACTION.json').read_text());a=record_to_contract(r,NH,EV)
        self.assertEqual(a['physical'][24],F(r['state'][7])-F(r['old_state'][7]))
        self.assertNotEqual(a['physical'][24],F(r['state'][7]))
    def test_wrong_model_is_rejected(self):
        r=rec();r['model_id']='other'
        with self.assertRaisesRegex(ValueError,'MODEL_ID'):record_to_contract(r,NH,EV)
    def test_reordered_half_sites_rejected(self):
        r=rec();r['sites'][1],r['sites'][2]=r['sites'][2],r['sites'][1]
        with self.assertRaisesRegex(ValueError,'SOURCE_SITE_ORDER'):record_to_contract(r,NH,EV)
    def test_full_step_time_cannot_be_used_for_half(self):
        r=rec();r['sites'][1]['step_s']=r['dt_s']
        with self.assertRaisesRegex(ValueError,'SOURCE_SITE_TIME'):record_to_contract(r,NH,EV)
    def test_zero_duration_rejected(self):
        r=rec();r['dt_s']=0
        with self.assertRaisesRegex(ValueError,'TIME_DOMAIN'):record_to_contract(r,NH,EV)
    def test_missing_event_channel_rejected(self):
        r=rec();r['events']['dr'].pop()
        with self.assertRaisesRegex(ValueError,'DR_SHAPE'):record_to_contract(r,NH,EV)
    def test_negative_event_rejected(self):
        r=rec();r['events']['collision'][0]=-1
        with self.assertRaisesRegex(ValueError,'NEGATIVE_EVENT'):record_to_contract(r,NH,EV)
    def test_nonfinite_state_rejected(self):
        r=rec();r['state'][3]=float('nan')
        with self.assertRaisesRegex(ValueError,'NONFINITE'):record_to_contract(r,NH,EV)
    def test_helium_simplex_rejected(self):
        r=rec();r['state'][1:3]=[.6,.6]
        with self.assertRaisesRegex(ValueError,'STATE_DOMAIN'):record_to_contract(r,NH,EV)
    def test_negative_escape_increment_rejected(self):
        r=rec();r['old_state'][7]=1
        with self.assertRaisesRegex(ValueError,'NEGATIVE_ESCAPE'):record_to_contract(r,NH,EV)
    def test_nonpositive_unit_scale_rejected(self):
        with self.assertRaisesRegex(ValueError,'UNIT_SCALE_DOMAIN'):record_to_contract(rec(),0,EV)
    def test_normalization_uses_exact_product_not_float_product(self):
        a=record_to_contract(rec(),NH,EV);u=F(rec()['old_state'][3])
        self.assertEqual(a['initial_normalized'][3],u/(F(NH)*F(EV)))
        self.assertNotEqual(a['initial_normalized'][3],F(rec()['parent_center'][3]))

class Observation(unittest.TestCase):
    def test_observed_25_values_reproduce_existing_record_bits(self):
        r=rec();a=record_to_contract(r,NH,EV);o=parse_observation(obs_text())
        native=o['HALF2_STATE'][:7]+o['SUM_EVENTS']+[o['ESCAPE_INCREMENT'][2]]
        self.assertEqual([binary64_bits(v) for v in native],[binary64_bits(v) for v in a['physical']])
    def test_different_stage_temperatures_are_not_collapsed(self):
        o=parse_observation(obs_text())
        self.assertNotEqual(o['HALF1_AUX'][0],o['HALF2_AUX'][0])
    def test_float_event_sum_matches_original_native_addition(self):
        o=parse_observation(obs_text())
        self.assertEqual([binary64_bits(a+b) for a,b in zip(o['HALF1_EVENTS'],o['HALF2_EVENTS'])],
                         [binary64_bits(v) for v in o['SUM_EVENTS']])
    def test_duplicate_csv_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'DUPLICATE'):parse_observation(obs_text()+obs_text().splitlines()[0]+'\n')
    def test_incorrect_decimal_cannot_claim_native_bits(self):
        t=obs_text();line=t.splitlines()[0];new=','.join(line.split(',')[:3]+['2.0'])
        with self.assertRaisesRegex(ValueError,'DECIMAL_BIT_MISMATCH'):parse_observation(t.replace(line,new,1))
    def test_missing_native_rate_is_not_invented(self):
        lines=[s for s in obs_text().splitlines() if not s.startswith('HALF1_RATES,0,')]
        with self.assertRaisesRegex(ValueError,'MISSING_FIELDS'):parse_observation('\n'.join(lines))
    def test_wrong_call_count_rejected(self):
        with self.assertRaisesRegex(ValueError,'BE_CALLS_SCOPE'):parse_observation(obs_text().replace('BE_CALLS,2','BE_CALLS,3'))

class JetsAndMeasures(unittest.TestCase):
    def test_exact_linear_jet_transform_nontrivial_cross_terms(self):
        v,g,h=transform_reference_jet(7,[2,3],[[5,11],[11,13]],17,[F(1,19),F(1,23)])
        self.assertEqual(v,119);self.assertEqual(g,[F(34,19),F(51,23)])
        self.assertEqual(h[0][1],F(187,19*23));self.assertEqual(h[1][0],h[0][1])
    def test_reference_jet_roundtrip_is_lossless(self):
        j=(F('1.23456789'),[F('3.4'),F('5.6')],[[F(3),F(7)],[F(7),F(5)]])
        x=transform_reference_jet(*j,F(2,7),[F(3,11),F(13,17)])
        y=transform_reference_jet(*x,F(7,2),[F(11,3),F(17,13)])
        self.assertEqual(y,j)
    def test_jet_shape_mismatch_rejected(self):
        with self.assertRaisesRegex(ValueError,'HESSIAN_SHAPE'):transform_reference_jet(1,[1,2],[[1,2]],1,[1,1])
    def test_aggregate_cannot_substitute_for_unknown_stage_values(self):
        with self.assertRaisesRegex(ValueError,'STAGE_VALUES_UNOBSERVED'):weighted_stage_total(None,[1,2])
    def test_same_aggregate_different_partitions_produce_different_weights(self):
        self.assertEqual(sum([1,3]),sum([2,2]))
        self.assertNotEqual(weighted_stage_total([1,3],[2,5]),weighted_stage_total([2,2],[2,5]))
    def test_equal_weights_do_allow_aggregation(self):
        self.assertEqual(weighted_stage_total([F(1,3),F(2,7)],[5,5]),5*(F(1,3)+F(2,7)))
    def test_fixed_site_energy_shares_telescope(self):
        o=parse_observation(obs_text());a=F(o['OLD'][7]);b=F(o['HALF1_STATE'][7]);c=F(o['HALF2_STATE'][7])
        self.assertEqual((b-a)+(c-b),c-a)

if __name__=='__main__':unittest.main()
