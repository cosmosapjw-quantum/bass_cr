# c64-g3 native 실행 경로의 구현 명세

상태: DESIGN_COMPLETE_NATIVE_IMPLEMENTATION_PENDING. 이 문서의 새 native 파일 경로는 제안 경로이며 아직 존재하는 실행 명령으로 취급하지 않는다. 기존 TP2E cache-only 실행, cloud_preflight.py, run_cache.sh만 이 배포본에서 실행 가능하다.

## F0. 원본 이식과 cache-only 비교

구현된 파일: cloud_preflight.py, run_cache.sh. 기존 TP2E package는 upstream/에서 불변으로 제공한다.

입력은 원 TP2D RETURN ZIP, 원 TP2E ZIP, 현재 VM의 CPU affinity/cgroup/memory 정보다. 출력은 create-only host/input receipt와 원 TP2E entrypoint가 생성하는 새 RETURN ZIP이다. 입력 archive SHA 불일치에는 rc=3과 INPUT_IDENTITY_BLOCKED, output 충돌에는 argparse error 또는 shell rc=3을 반환하며 기존 결과를 쓰지 않는다. inventory 성공은 native 승인이나 과학 PASS가 아니다.

새 테스트는 logical quota·memory 제한·RSS 미측정·입력 hash·output 충돌·외부 작업 디렉터리 CLI·thread 환경 강제를 검사한다. 기존 C++ engine은 로드하지 않고 새 공간적분은 0회다. 원 TP2E의 실제 archive admission과 M4 결과는 cloud 또는 local의 첫 실행에서 확인한다.

## F1. 새 Intel native build와 engine admission

제안 파일: native/cloud_engine.py, native/engine_admission.py, tests/test_engine_admission.py.

입력 인터페이스: engine_admission(source_root, historical_archive, new_build_dir, frozen_policy, out_dir) -> ENGINE_ADMISSION.json. 원본 source closure, historical archive grant, BASIS bytes를 읽는다. compiler argv/version, CPU/ISA, libc, Python/numeric dependency, fresh library SHA를 별도 ENGINE_IDENTITY.json으로 출력한다.

새 C++ source는 pinned source hash와 동일해야 한다. 첫 빌드는 generic x86-64/fast-math 금지로 제한한다. 원 library SHA를 새 값으로 바꿔 과거 기록을 재사용하지 않는다. 같은 원 BASIS coefficient payload를 이용해 지정된 중앙·양쪽 tail·q/h 전이 sample에서 full S/H/D를 계산한다. 원 q/h ladder의 첫 독립 수렴 pair 선택 의미를 유지한다.

Acceptance tests:
- source 변조, basis 내용/순서 변조, 누락된 library receipt는 명시적 identity blocker다.
- 기존 selected full 행렬과 rtol=1e-11, atol=1e-12 비교를 통과해야 한다. 이는 raw quadrature convergence 1e-9 gate를 대체하지 않는다.
- 양방향 D, Hermiticity, metric positivity, 기존 connection sentinel을 별도 기록한다.
- raw 배열의 bitwise 차이는 기록하되 cross-platform이라는 이유만으로 tolerance를 넓히지 않는다.
- selected q/h 변화는 POLICY_SELECTION_DRIFT로 보류한다.
- 원 provider의 library hash check를 production 코드에서 no-op으로 만들지 않는다. 새 adapter가 새 engine identity를 직접 검증한다.

실행 환경/컴파일 오류와 numerical parity 오류를 다른 status로 반환한다. 서로 다른 engine 간 데이터는 명시적인 import grant 없이는 같은 cache namespace에 넣지 않는다.

## F2. 정확한 시점별 task pool과 calibration

제안 파일: native/task_plan.py, native/worker_pool.py, native/task_store.py, calibrate_cloud.py, tests/test_cloud_pool.py.

입력 인터페이스: qualify_times(times_hex, engine_admission, basis_payload, policy, resource_plan, run_budget, out_dir) -> TASK_MANIFEST.json. task identity에는 정확한 time_hex와 data/engine identity가 들어간다. resource_plan의 worker 수와 log 문구는 numerical identity와 분리한다. 기존 qid를 재작성하지 않으며 import의 old/new 연결을 보존한다.

Worker는 하나의 시간에서 전체 finite ladder를 순차 평가한다. q/h 후보를 완료순으로 먼저 도착한 것부터 선택하지 않는다. same-center memo는 해당 worker의 해당 exact time에서만 재사용한다. 적분 내부의 합산순서와 native kernel은 변경하지 않는다. parent는 유일한 manifest writer다.

최대 in-flight task는 worker 수에 비례하는 작은 유한값으로 둔다. 하나의 시간의 payload가 persisted/validated되기 전에 완료로 세지 않는다. 새로운 제출은 deadline 또는 첫 오류에서 멈추며, in-flight의 완료/중단/저장 실패를 별도로 기록한다. 잠정 결과를 PASS로 둔 채 final save 실패를 무시하는 경로는 금지한다.

Calibration 입력은 profile 간 동일한 192개 distinct time, 동일한 cold store 정책이다. 1-worker 중앙 pilot에서 peak RSS를 먼저 잰다. 자원 한도를 만족하는 16/32/48/60만 실행하고, 좋은 두 profile을 반복 측정한다. 최고 median throughput의 97% 범위 안에서는 적은 workers를 선택하는 정책을 사용한다. 이런 tuning은 수치 허용오차 변경이 아니다.

Acceptance tests:
- serial/spawn의 선택 q/h와 결과 행렬 parity; 시간순서가 아닌 완료순서로 결과를 모아도 replay 결과 동일.
- task starvation을 막는 profile별 최소 task 수 확인; duplicate/warm cache는 throughput 계산에서 분리.
- worker exception, SIGINT, disk-full, fsync 실패, partial payload에서 정확한 실패 receipt와 원본 보존.
- stale context, hash tamper, time_hex 변조는 fail-closed. 동일 context의 persisted task만 resume 가능.
- cap 초과·RSS 미측정·불명확 cgroup에는 자동 대규모 실행 금지.
- 단순 tests에서는 실제 Git repo를 temporary fixture로 만들거나 모든 외부 Git 경계를 명시적으로 대체한다. 가짜 head 문자열을 real ancestry gate로 보내지 않는다.

## F3. 고차 temporal 실험과 partial-result 보고

제안 파일: run_cloud_transport.py, native/transport_reducer.py, native/return_report.py, tests/test_cloud_transport.py.

입력은 F1 engine admission, F2 resource profile, 원 reference import grant, 사전에 선택한 CF4 method와 [24,48,96,192] ladder, 명시적인 wall/cost budget이다. 이 budget 값은 현재 사용자에게 제공되지 않았으므로 자동 heavy launch를 하지 않는다.

CF4 각 단계의 실제 Gauss time을 task_plan이 정의하고 fixed hex로 저장한다. midpoint와 Gauss를 nearby-time 대응으로 바꾸지 않는다. 모든 required operator가 준비되면 기존 metric-frame G 정의로 각 step exponential을 구성하고 chronological order로 곱한다. 같은 N의 state propagation을 60개 worker에 잘라 최종 벡터를 임의 평균하지 않는다.

원 reference는 imported_reference=true, reference_engine_id=historical로 표기한다. 새 engine과의 representative parity는 uniform interval error 증명으로 승격하지 않는다. 기존 M4 cache-only 결과와 새 CF4 결과는 다른 실험/방법 identity를 가진다.

Acceptance tests:
- exact-solution 비가환 시간의존 행렬에서 4차 수렴; exponential 순서/commutator 부호 negative control.
- finite basis의 실제 candidate/reference 거리 <=1e-6, 인접 candidate 차이 <=1e-6, norm drift <=1e-8. Norm 통과만으로 시간오차 PASS 금지.
- finite ladder 소진은 TEMPORAL_REFINEMENT_UNRESOLVED이며 threshold 변경이나 자동 ladder 증설 금지.
- failure에도 reference receipt, completed candidate/pair, operator audit, resource cost ledger를 RETURN_REPORT에 남긴다.
- requested/returned/persisted/qualified count를 분리하고 미완료 query를 all_qualified=true에 포함하지 않는다.
- capture=false, production=HOLD, all_bound=OPEN, b_grid=NO_GO, continuous_global_supremum_bound=false가 성공·실패·복구 모두 유지된다.

## 실행 경계

F1~F3는 설계만 완료됐다. 구현과 신규 테스트 이후에만 native cloud 실행 명령을 배포한다. F0의 기존 cache-only M4로 목적이 이미 달성되면 같은 질문을 위해 F1~F3의 비싼 전파를 자동 시작하지 않는다. 별도 원자물리/capture 질문이 열리지 않는 한 과학적 범위를 넓히지 않는다.
