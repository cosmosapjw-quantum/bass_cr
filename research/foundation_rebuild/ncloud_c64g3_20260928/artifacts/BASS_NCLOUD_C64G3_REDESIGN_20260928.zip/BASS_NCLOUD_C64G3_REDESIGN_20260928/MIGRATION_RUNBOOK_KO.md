# c64-g3 이전과 첫 실행

이 순서는 사용자가 이미 생성했거나 생성하기로 정한 VM에서 직접 수행할 명령이다. 클라우드 생성·설치·과금 실행을 이 대화에서 수행한 것은 아니다. 새 native 병렬 runner는 아직 설계 단계이며 여기에는 실행 명령을 만들어 넣지 않았다.

## 1. 로컬에서 가져갈 것

반드시 필요한 파일:

1. BASS_NCLOUD_C64G3_REDESIGN_20260928.zip (이 설계·이전 도구, 원 TP2E ZIP 포함)
2. tp2d_runtime_self_qualified_20260927T074944Z_RETURN.zip (전체 원 결과, 요약본으로 대체 불가)
3. 아래에서 만드는 requirements-compute.txt와 LOCAL_PYTHON.txt

새 native 작업에 필요한 추가 자료:

- c954d68 commit을 포함한 bass_cr Git bundle 또는 해당 exact commit의 checkout
- 원 analytic BUILD.json (원 library도 보존하려면 old_build/에 forensic 자료로 옮긴다. cloud에서 자동 실행하지 않는다.)
- 원 compiler/runtime receipt, 가능하면 원 python 환경의 NumPy/BLAS 설정

원 BASIS.json/BASIS.npz와 reference states는 TP2D ZIP 안의 bytes를 사용한다. Dropbox 폴더 전체, .codex/, private keys, .env, API credentials를 보내지 않는다.

로컬 명령 예:

```bash
REPO="$HOME/Dropbox/bianchi/BASS_CR_R3M10_LOCAL_REPRODUCTION_PACKAGE_20260921_v1"
STAGE="$HOME/Downloads/bass_ncloud_input_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir "$STAGE"
cp "$REPO/runs/tp2d_runtime_self_qualified_20260927T074944Z_RETURN.zip" "$STAGE/"
cp "$HOME/Downloads/BASS_NCLOUD_C64G3_REDESIGN_20260928.zip" "$STAGE/"

python3 - <<'PY' > "$STAGE/requirements-compute.txt"
from importlib.metadata import version
for name in ('numpy', 'scipy', 'pytest'):
    print(f'{name}=={version(name)}')
PY
python3 --version > "$STAGE/LOCAL_PYTHON.txt"
(cd "$STAGE" && sha256sum *.zip requirements-compute.txt LOCAL_PYTHON.txt > INPUTS.sha256)
```

이것은 top-level numeric/test package versions의 snapshot이며 전체 OS/wheel 바이트 재현 보장이 아니다. 새 VM에서는 full pip freeze와 BLAS configuration을 따로 보존한다. 설치가 실패하면 최신 버전으로 자동 대체하지 않는다.

선택적 Git bundle: 현재 HEAD가 pinned commit과 일치할 때만 수행한다. 다른 branch를 자동 checkout/reset하지 않는다.

```bash
PIN=c954d68fdc86527453765a563b3a025351163ed9
if test "$(git -C "$REPO" rev-parse HEAD)" = "$PIN"; then
  git -C "$REPO" bundle create "$STAGE/bass_cr_c954d68.bundle" HEAD
  git -C "$REPO" bundle verify "$STAGE/bass_cr_c954d68.bundle"
  (cd "$STAGE" && sha256sum bass_cr_c954d68.bundle >> INPUTS.sha256)
else
  echo 'BUNDLE_NOT_CREATED: current HEAD differs; preserve the working checkout'
fi
```

## 2. 서버와 디스크

일반 한국 VPC / c64-g3 / Ubuntu 24.04 x86_64를 기준으로 한다. 실제 image/region이 다르면 기록한다. CB1/CB2 SSD data volume 약 200GB를 권고한다. 공개 IP를 쓰는 경우 SSH는 실제 작업자의 출발지 IP/CIDR로 제한하고 non-root 작업 계정을 사용한다. 이 문서에는 자동 disk format 명령이 없다.

`/data`는 실제로 연결·마운트가 확인된 작업 볼륨으로 가정한다. 아래를 먼저 확인한다.

```bash
lsblk -f
findmnt -T /data
```

마운트와 경로가 의도한 볼륨임을 확인한 다음 작업 계정에 전용 경로를 만든다.

```bash
sudo install -d -m 0750 -o "$USER" -g "$(id -gn)" /data/bass
ROOT=/data/bass
mkdir -p "$ROOT"/{inputs,code,env,runs,receipts,builds,cache,checkpoints}
```

입력은 SCP/rsync로 해당 inputs 디렉터리에 전송한다. HOST에는 사용자가 실제 만든 SSH 계정@IP를 넣는다. private key 내용은 채팅이나 bundle에 넣지 않는다.

```bash
HOST='YOUR_SSH_USER@YOUR_SERVER_IP'
rsync -a --partial "$STAGE/" "$HOST:/data/bass/inputs/"
```

## 3. 서버 Python 환경

원 Python minor와 가능한 한 맞춘다. 아래는 Ubuntu 24.04의 python3가 그 조건에 맞는 경우의 예시다. 맞지 않으면 이 부분을 그대로 실행하지 말고 해당 minor interpreter를 준비한다.

```bash
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip jq unzip git tmux numactl sysstat build-essential
ROOT=/data/bass
cd "$ROOT/inputs"
sha256sum -c INPUTS.sha256
unzip -q BASS_NCLOUD_C64G3_REDESIGN_20260928.zip -d "$ROOT/code"
DESIGN="$ROOT/code/BASS_NCLOUD_C64G3_REDESIGN_20260928"
unzip -q "$DESIGN/upstream/BASS_TP2E_RESEARCH_20260928.zip" -d "$ROOT/code"
PKG="$ROOT/code/BASS_TP2E_RESEARCH_20260928"

python3 -m venv "$ROOT/env/tp2e"
source "$ROOT/env/tp2e/bin/activate"
python -m pip install --only-binary=:all: -r "$ROOT/inputs/requirements-compute.txt"
python -m pip freeze > "$ROOT/receipts/CLOUD_PIP_FREEZE_$(date -u +%Y%m%dT%H%M%SZ).txt"
```

기존 디렉터리가 있으면 unzip 덮어쓰기를 선택하지 않는다. 기존 환경을 변경하지 말고 새 code/env 경로를 사용한다. threadpoolctl은 추가 측정 도구이며 첫 cache-only 실행에는 필요하지 않다.

## 4. Host/입력 receipt

```bash
ROOT=/data/bass
DESIGN="$ROOT/code/BASS_NCLOUD_C64G3_REDESIGN_20260928"
PKG="$ROOT/code/BASS_TP2E_RESEARCH_20260928"
SOURCE="$ROOT/inputs/tp2d_runtime_self_qualified_20260927T074944Z_RETURN.zip"
HOSTREC="$ROOT/receipts/HOST_$(date -u +%Y%m%dT%H%M%SZ).json"
python "$DESIGN/cloud_preflight.py" \
  --tp2d-archive "$SOURCE" \
  --tp2e-package "$DESIGN/upstream/BASS_TP2E_RESEARCH_20260928.zip" \
  --out "$HOSTREC"
jq '{status, input_checks, host: {machine: .host.machine, logical_affinity_count: .host.logical_affinity_count,
     effective_memory_total_bytes: .host.effective_memory_total_bytes, worker_plan: .host.worker_plan,
     package_versions: .host.package_versions, warnings: .host.warnings}}' "$HOSTREC"
```

이것은 bytes/inventory receipt이며 native engine 승인이나 성능 PASS가 아니다. worker RSS가 아직 없으므로 safe_worker_ceiling=null이 정상이다.

## 5. 기존 cache-only M4

연결 중단에 대비해 먼저 `tmux new -s bass-tp2e`로 session을 연 뒤 아래를 실행한다. 새 tmux shell에서는 venv를 다시 활성화한다.

```bash
ROOT=/data/bass
source "$ROOT/env/tp2e/bin/activate"
DESIGN="$ROOT/code/BASS_NCLOUD_C64G3_REDESIGN_20260928"
PKG="$ROOT/code/BASS_TP2E_RESEARCH_20260928"
SOURCE="$ROOT/inputs/tp2d_runtime_self_qualified_20260927T074944Z_RETURN.zip"
OUT="$ROOT/runs/tp2e_cache_$(date -u +%Y%m%dT%H%M%SZ)"
echo "OUT=$OUT"
bash "$DESIGN/run_cache.sh" "$PKG" "$SOURCE" "$OUT"
RC=$?
echo "EXIT=$RC"
```

wrapper는 shell에서 thread 수를 설정하며 활성화된 venv의 Python을 사용한다. TP2E의 32 tests는 새 CPU/OS/BLAS 환경의 첫 admission으로 실행하지만 원 TP2D의 장시간 물리 계산은 재실행하지 않는다.

## 6. 반환 자료

```bash
jq '{status,original_tp2d_status,new_tests,source_audit,
     new_method_temporal_comparison_qualified,
     comparison:{selected_nstep:.comparison.selected_nstep,historical_replay:.comparison.historical_replay,
                 candidates:.comparison.candidates,pairs:.comparison.pairs,
                 new_operator_evaluations:.comparison.new_operator_evaluations,
                 reference_reintegrated:.comparison.reference_reintegrated},
     capture_execution_allowed,production_admission,first_failure,wall_seconds}' "$OUT/RETURN_REPORT.json"
sha256sum "$OUT/RETURN_REPORT.json" "${OUT}_RETURN.zip"
```

필요한 반환 파일은 새 `${OUT}_RETURN.zip`, HOST receipt, CLOUD_PIP_FREEZE다. 실제 서버의 `lscpu`, affinity, quota, NUMA 결과는 HOST receipt 안에 포함된다. 이 자료가 오기 전에는 실제 Intel CPU 모델, 최고 worker 수, actual cloud M4 결과를 확정하지 않는다.

Cache-only가 성공하면 같은 bounded question 때문에 새 full spatial run을 시작하지 않는다. 추가 실험은 REDESIGN_KO.md의 new-engine lane으로 분리한다. 기존 `probe_native.py --workers 64`를 실행하는 것은 이 재설계가 아니다.

## 7. 종료·보관

성공 또는 실패 후 원본과 결과를 private Object Storage와 로컬 independent copy에 보관한다. provider acknowledgement와 restore verification은 다른 receipt다. 완료 결과에 대한 SHA readback 후 불필요한 VM 운영을 종료한다. VM stop/반납은 콘솔의 실제 상태와 부속 storage/IP 요금을 확인하며 사용자가 수행한다. 이 패키지에는 서버 생성·정지·반납 API나 bucket 삭제 명령이 없다.
