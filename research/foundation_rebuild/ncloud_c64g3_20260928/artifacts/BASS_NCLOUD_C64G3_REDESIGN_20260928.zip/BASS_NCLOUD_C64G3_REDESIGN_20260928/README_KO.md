# BASS NAVER Cloud c64-g3 재설계

## 바로 볼 문서

- REDESIGN_KO.md: CPU·RAM·스토리지·native build·task pool·claim gate의 결정.
- MIGRATION_RUNBOOK_KO.md: 로컬 input 준비, 파일 전송, VM 환경, cache-only 첫 실행.
- IMPLEMENTATION_PLAN_KO.md: 새 native engine/parallel runner의 제안 인터페이스와 acceptance tests.
- CLOUD_DESIGN.json: machine-readable 설계. 기존 runner의 실행 설정 파일은 아니다.
- SOURCE_REVIEW.json, SOURCES.json: 기준 package identity와 원자료.
- VALIDATION.json, evidence/: 이번에 실행한 helper tests 및 검증 범위.

## 이번에 실행 가능한 것

cloud_preflight.py는 입력 SHA와 VM의 read-only inventory, CPU·메모리 상한을 기록한다. worker peak RSS가 없으면 병렬 실행 수를 승인하지 않는다. run_cache.sh는 원 TP2E run_cached_m4.py를 worker/BLAS thread 1 환경에서 실행한다. 원 TP2E package는 upstream/ 아래에 byte-identical ZIP으로 포함된다.

## 아직 구현하지 않은 것

새 Intel C++ build admission adapter, 192-task calibration, 16/32/48/60 병렬 CF4 전체 runner는 설계 대상이다. 기존 probe_native.py에 --workers 64를 주는 것으로 이를 대체하지 않는다.

## 불변 범위

원 TP2D TEMPORAL_REFINEMENT_UNRESOLVED, source/array bytes, historical native build, GitHub branch는 변경하지 않았다. 이 패키지는 cloud resource 생성·정지·삭제 API를 호출하지 않으며 credentials를 요구하지 않는다. 실제 VM access, cloud native benchmark, 실제 BASS M4 계산은 여기서 수행하지 않았다.

## 신규 helper 테스트

패키지 디렉터리에서:

    python3 -m unittest discover -s tests -v
    bash -n run_cache.sh

기존 TP1/TP2D 과학 suite를 호출하는 명령이 아니다. 실제 cache-only 첫 실행은 이동된 환경의 TP2E 신규 suite와 source admission을 수행한다.
