# BASS TP2E 이후: NAVER Cloud c64-g3 재설계

작성: 2026-09-28. 대상: 일반 상용 한국 리전, VPC, c64-g3(vCPU 64, Memory 128GB).

## 0. 결정과 산출물 범위

원 TP2D를 큰 서버에서 처음부터 반복하지 않는다. 먼저 기존 TP2D archive를 읽는 TP2E cache-only M4를 실행한다. 이 경로는 새 C++ 공간적분과 새 DOP853 solve가 없으며, 1개 프로세스와 BLAS 1 thread가 기본이다. 아직 실행되지 않은 새 공간적분에 대해서만 c64-g3의 병렬 자원을 사용한다.

새 native 경로의 단위는 독립적인 하나의 exact-time operator qualification이다. 각 worker가 그 시간의 finite q/h ladder를 순서대로 평가하고, parent가 결과를 검증·저장한다. 모든 required snapshot이 준비된 후 작은 전파 행렬을 물리적 시간순으로 곱한다. MPI, Kubernetes, 여러 VM, 새로운 GPU 경로는 도입하지 않는다.

이 패키지에서 구현된 것은 입력 파일 SHA 확인, read-only host inventory, 측정 RSS 기반 worker 상한 계산, 변경하지 않은 TP2E cache-only 실행 wrapper다. 새 Intel native engine adapter, 자동 worker calibration, 병렬 CF4 계산기는 아래에서 명세한 다음 구현 대상이다. CLOUD_DESIGN.json은 설계 명세이며 기존 실행기에 그대로 전달할 수 있는 설정 파일이 아니다.

서버 생성, 설치, 과금 작업, SSH 접속, native 재컴파일, 실제 cloud benchmark, GitHub 변경은 수행하지 않았다. 원 TP2E 배포 ZIP은 upstream/ 아래에 byte-identical하게 동봉했다.

## 1. 근거와 현 상태

원본 TP2D:

- commit: c954d68fdc86527453765a563b3a025351163ed9
- tree: 0e13583301e271e9a9e8aa0eae3c05eaf8580a1a
- report SHA-256: 528d54f3c373a13c4e21b354721d978670e1317b7fcf6bc92f63df51ea138b7d
- archive SHA-256: 630a80208331b7b37c02a77eae7435f6317d07439a4ea34b11885455fe53fa35
- 판정: TEMPORAL_REFINEMENT_UNRESOLVED
- 전체 wall: 44624.633493182 s
- 최종 operator 시점: 1279개, raw evaluation: 4442회
- N384 reference 거리: 2.634560877280569e-6, N192/N384 차이: 7.904769432369909e-6

이는 단순한 하드웨어 고장이나 norm 불안정이 아니라, 관측상 midpoint 2차 시간 오차와 bounded ladder 부족에 부합한다. 기존 결과를 통째로 다시 계산하지 않는 것이 우선이다. TP2E의 실제 BASS M4 결과는 아직 주어지지 않았다.

검토한 TP2E ZIP의 SHA-256은 0f7af63b234b8ae527ac1c1ba42c28a9cf89b39f79da329d2b73d8aa2896c7b0이다. 정확한 code fingerprint와 finding은 SOURCE_REVIEW.json을 참조한다.

## 2. c64-g3의 실제 의미

공식 server-spec 가이드[N1]의 표기상 c는 High CPU, g3는 KVM 기반 3세대, CPU 타입 공란은 Intel이다. c64-g3a와 혼동하지 않는다. 상품의 64 vCPU를 전용 물리 코어 64개라고 해석하지 않는다. 구체적인 CPU 모델, NUMA, affinity, quota는 할당받은 VM에서 읽는다. guest lscpu topology 자체도 물리 호스트 점유를 보증하지 않는다.

공식 표의 c64/128 상한은 network 5Gbps, storage throughput 1188MB/s, IOPS 100000이다. 이는 서버 상한이며 특정 한 개 디스크에서 보장되는 성능이 아니다. [N1,N3]

작업 디스크는 CB1 또는 CB2 SSD, 초기 제안 200GB다. FB1/FB2는 HDD이므로 작은 per-query 파일과 동기화가 많은 hot path의 기본 선택으로 삼지 않는다. CB1/CB2의 IOPS와 throughput은 볼륨 크기에 따라 달라진다. [N1] OS disk 50GB는 설계 권고이지 고정 제공 사양 주장이 아니다.

기본 권고 OS는 Ubuntu 24.04 LTS x86_64다. 다만 원 계산을 수행한 Python minor/NumPy/SciPy가 재현 가능한 이미지·환경이 우선이며, 기록된 요구 버전 설치가 불가능하면 자동으로 최신 버전으로 대체하지 않는다.

## 3. 두 경로를 분리한다

### A. Imported-cache lane: 즉시 사용 가능한 경로

1. 원 TP2D ZIP 전체를 옮기고 exact SHA를 확인한다. 요약 JSON만으로는 실행할 수 없다.
2. cache-only SourceArchive admission을 수행한다. 이는 원 archive의 manifest, time identity, 저장된 raw cross convergence, selected full matrices를 검사한다.
3. 기존 N384 상태를 작은 행렬로 재생하고 stored endpoint와의 metric distance <=1e-10을 요구한다.
4. 기존 TP2E M4 N=24,48,96,192를 실행한다. 필요한 exact cache key가 없으면 중단한다.
5. reference 거리와 인접 refinement는 각각 <=1e-6, norm drift <=1e-8을 그대로 유지한다.

원 Ryzen의 libmoments.so를 로드하지 않는다. 따라서 이 경로를 위해 Intel에서 공간적분 library를 먼저 빌드할 필요가 없다. 저장 행렬의 byte identity와 cloud LAPACK/BLAS가 계산한 새 결과의 numerical parity는 다른 것이다. 이동한 환경에서 N384 replay가 그 구분을 확인하는 제어 실험이다.

통과하더라도 원 TP2D FAIL은 바뀌지 않고, 새로운 TP2E 비교만 통과한다. 64개 프로세스로 작은 18x18 행렬 곱을 무작정 분산하지 않는다. 이 단계는 많은 CPU가 필요한 단계가 아니며, 아직 VM을 만들지 않았다면 로컬에서 먼저 수행해도 된다.

### B. New-cloud-engine lane: 새 공간적분이 필요할 때

Cache-only M4가 통과하지 않거나 새 시점이 필요한 경우에만 별도로 연다. 새 native library는 새 build identity를 가진다. 기존 GRANT.json의 historical library SHA를 덮어쓰거나 새 바이너리를 구 바이너리로 가장하지 않는다.

새 실험의 기본 후보는 표준 2-Gauss-node CF4, prospective step ladder [24,48,96,192]다. 기존 M4를 계속 확대하는 대안도 가능하지만 실행 전에 method와 ladder를 고정한다. 실행 결과를 보면서 둘 사이를 자동 전환하지 않는다. 두 방법 모두 operator interpolation 없이 필요한 실제 시점을 직접 qualification한다. CF4 formula/helper는 기존 TP2E에 있으나 native 고정-grid 전체 실행기는 이번 산출물에 구현하지 않았다.

한 단계 N의 작업 집합은 2N개의 Gauss node와 필요한 endpoints/diagnostics로 구성한다. 서로 독립인 시점별 operator 계산만 process pool에 분배하고 전파의 chronology는 바꾸지 않는다. N24라면 48개의 Gauss task뿐이므로 worker 60개를 전부 사용할 일이 없다. 작은 단계는 task 수로 worker 수를 제한한다.

DOP853의 adaptive RHS stage는 앞선 state에 의존한다. 같은 solve의 모든 future stage를 독립 작업처럼 사전 분배하지 않는다. 완료된 DOP853 baseline은 archive-backed reference로 재사용하며 '새 독립 reference solve'라고 부르지 않는다.

## 4. 병렬화와 자원 예산

### Worker 수

CPU thread는 worker당 1개다. OMP_NUM_THREADS, OPENBLAS_NUM_THREADS, MKL_NUM_THREADS, NUMEXPR_NUM_THREADS를 NumPy import 전에 1로 설정한다. OMP_DYNAMIC과 MKL_DYNAMIC도 FALSE로 둔다. SciPy 선형대수 호출과 BLAS 내부 thread는 별개이므로 바깥 pool과 중첩하지 않는다. [T1]

process context는 spawn을 명시한다. Python 버전별 기본 start method에 의존하지 않는다. [T2] 기존 same-center memo는 worker별 모듈 binding과 상태를 가지므로 하나의 전역 memo를 threads 사이에 공유하는 경로로 바꾸지 않는다.

단일 프로세스의 native serial admission을 먼저 수행한다. 그 다음 후보는 16,32,48,60 workers다. c64에서는 coordinator·I/O·OS 여유로 논리 CPU 4개를 남긴다. 실제 CPU quota/affinity가 작으면 상한도 줄인다. 무조건 60을 쓰는 설정이 아니다.

M_eff는 /proc/meminfo와 적용 가능한 cgroup hard limit 중 작은 값이다. A_eff는 시스템 MemAvailable와 cgroup limit-current 중 작은 값이다. 메모리 단위는 bytes/GiB로 계산하고 상품의 128GB 표기를 무조건 128GiB로 대입하지 않는다.

M_budget = min(96GiB, 0.75 M_eff, max(0,A_eff-8GiB))
W_memory = floor(max(0,M_budget-4GiB)/(1.5 R_peak))
W_safe = min(CPU 상한, W_memory, 남은 task 수)

R_peak는 cheap tail 시점이 아니라 중앙 q64/h2 등 비싼 시점을 포함한 pilot의 최대 worker RSS다. 96GiB budget을 쓸 수 있는 예에서 R_peak=2GiB이면 W_memory=30이다. 따라서 128GB 서버라고 48/60 workers가 항상 메모리에 맞지 않는다. 위 식은 preflight bound이며 실행 중 memory pressure/OOM 감시를 대체하지 않는다.

RSS가 미측정이면 cloud_preflight.py는 safe_worker_ceiling=null로 기록한다. cgroup mapping/limit이 불명확하면 scaling profile의 자동 승인을 막는다. 실제 작업 실행 권한이나 자원 예약을 수행하는 도구는 아니다.

### Worker 선택 실험

기존 probe_native.py는 25개의 시점만 사용한다. 이것으로 32/48/60 worker 성능을 비교하면 task-starvation과 spawn overhead를 비교할 위험이 있다.

새 calibration은 같은 192개의 서로 다른 exact-time task를 모든 profile에서 사용한다. 최댓값 60의 3배 이상으로 유지하고 negative/positive tail, 중앙, q/h 전이 부근을 포함한다. 반복을 위해 같은 시점을 중복 제출한 뒤 memory cache hit를 native speedup으로 세지 않는다. 각 profile은 cold query store로 시작한다.

우선 16/32/48/60 중 자원 gate를 통과한 값만 비교한다. 좋은 두 후보에서 반복 측정해 median throughput/spread와 비용을 비교한다. 최대 throughput의 97% 이내라면 작은 worker 수를 선택하는 것을 권고한다. 이 97%는 성능 선택 정책이며 scientific tolerance가 아니다.

필수 지표: total wall, per-task wall p50/p95, raw evaluations, peak RSS, CPU user/system/steal, iowait, ctx switches, 저장·fsync 시간, selected q/h, parity. 최초 original/native 1 worker와 memo 1 worker는 성능 효과 분리용 소규모 pilot이며 장시간 192-task serial benchmark를 기본으로 강요하지 않는다.

## 5. 정확성과 provenance

### 새 빌드

Ryzen에서 만든 binary의 ISA 가정을 확인하기 전에는 Intel에서 그대로 실행 가능하다고 가정하지 않는다. 특히 -march=native는 build host의 CPU 기능을 활성화할 수 있다. [T3] 원 build가 실제로 그 옵션을 썼는지는 old BUILD.json에서 별도 확인한다.

첫 cloud 빌드 제안은 -O3 -std=c++17 -shared -fPIC -march=x86-64 -mtune=generic -fno-fast-math -ffp-contract=off다. 이는 기존 빌드와 byte equality를 기대하는 설정이 아니다. SIMD/AVX 최적화는 이후 별도 build lane으로 측정한다.

기록: source closure hashes, C++ source SHA, compiler exact version/argv, lib SHA, machine/CPU flags, libc, Python/NumPy/SciPy, BLAS provider/thread configuration. Old BUILD.json을 새 library에 맞춰 덮지 않는다.

### Basis와 reference

원 BASIS.json/BASIS.npz의 실제 eigenvectors를 그대로 사용한다. 같은 RadialSpec으로 고유벡터를 다시 풀면 부호·퇴화부분 회전·ordering이 바뀔 수 있으므로 새 basis를 묵시적으로 같은 basis로 보지 않는다.

Cloud build를 serial representative points에서 기존 selected S,H,D와 비교한다. 최소한 현재 probe의 rtol=1e-11, atol=1e-12 parity를 유지한다. raw cross pair의 1e-9 gate와 구현 parity는 별도다. bitwise 여부를 기록하되 서로 다른 BLAS/CPU 간 bitwise 불일치만으로 이론 오류라 하지 않는다. Hermiticity, metric rank, selected resolution, 양방향 D와 기존 metric sentinel도 검사한다.

selected q/h가 달라지면 단순 PASS로 묻지 않고 POLICY_SELECTION_DRIFT로 분류한다. floating-point 임계값 경계인지 source/basis 오류인지 판별한 다음 새 policy admission이 필요하다. representative-point parity는 전 시간 구간의 uniform error bound가 아니다.

Cloud CF4를 구 DOP853 reference와 비교하면 cross-build reference 사용이라는 제한을 결과에 남긴다. 재사용 reference가 new cloud engine의 엄밀한 exact reference가 되는 것은 아니다. 엄격한 cross-build claim이 필요하면 검증 범위를 별도 확대하되 cache-only lane에 이 비용을 자동 부과하지 않는다.

### Identity 분리

old archive와 모든 old qid는 불변이다. 새 task의 identity는 basis payload, trajectory, exact time_hex, q/h/effective integration mesh, source closure, binary SHA, sector로 묶는다. 승인 policy는 별도 qualification-policy hash로 묶는다. Controller log 문구나 worker 수가 바뀌었다고 scientific snapshot identity를 바꾸지 않는 설계를 권고한다.

기존 source의 context_id를 임의로 다시 쓰는 migration은 금지다. 명시적 import receipt가 old qid와 archive SHA, selected array SHA, 새 consumer context를 연결한다. cache reuse, 원래 task alias, 독립적인 numerical comparison을 다른 항목으로 기록한다.

## 6. 데이터·복구·과금

/data/bass/inputs는 원본 입력 archive와 manifest, /code는 frozen source, /builds는 엔진별 독립 디렉터리, /cache는 데이터 identity별 snapshot, /runs는 실험별 return, /receipts는 입출력·host identity로 나눈다. 실제 block volume의 mount를 확인하고 사용한다. 이 패키지는 disk format이나 mount 변경을 자동 수행하지 않는다.

hot path에 Dropbox client나 S3 FUSE를 두지 않는다. per-query payload는 attached block SSD에 쓰고 완성된 immutable shard/checkpoint만 외부 백업으로 보낸다. Parent는 유일한 manifest writer이며, worker마다 독립 tmp 파일과 return payload를 쓴다. task acknowledgement는 persisted 상태 이후다. 저장되지 않은 result를 완료로 세지 않는다.

Task ledger는 planned, submitted, running, computed, persisted, validated, failed를 구분한다. End report는 오류가 생겨도 completed reference, completed candidates, query ledger를 남긴다. original TP2D의 초기 false 값이 남는 문제를 새 controller에서 되풀이하지 않는다.

Object Storage 한국 endpoint는 https://kr.object.ncloudstorage.com, API는 S3-compatible이다. [N4] bucket은 private, credential은 read/write scope를 좁힌 별도 계정으로 관리한다. credentials를 archive나 채팅에 넣지 않는다. 파일 content SHA를 manifest/custom metadata로 보관하고 ETag를 SHA-256로 취급하지 않는다. provider ACK/metadata verification과 실제 restore/readback verification은 구분한다.

환경중단·미완료 task는 hash-valid 완료물만 재사용한다. scientific FAIL은 그대로 남겨 새 방법/새 허용 budget의 후속 실험으로 이어간다. near-time key merge, tolerance relaxation, 실패 row 삭제, FAIL→PASS 재표기는 없다.

Heavy native 실행에는 run-level wall/cost budget이 필요하다. 사용자 비용 상한이 주어지지 않았으므로 CLOUD_DESIGN.json의 예산은 null이며 native 자동 실행은 비활성이다. 새 controller는 deadline 전에 새 제출을 멈추고 in-flight 비용과 grace를 기록해야 한다. running native process를 취소하지 못하는 상황까지 포함해 zero-overshoot를 보장하지 않는다.

프로그램 종료나 tmux 종료는 VM 정지가 아니다. 콘솔에서 Server 상태를 확인해야 한다. 공인 IP·추가 디스크 등 부속 자원은 서버를 정지해도 별도 과금될 수 있다. [N5] 자동 서버 반납/디스크 삭제를 연구 실행기에 넣지 않는다. 마지막 checkpoint의 외부 검증과 로컬 사본 확보 후 사용자가 정지/반납 범위를 결정한다.

## 7. 속도·비용의 해석

총 44624.6초에서 64를 나누는 예측은 하지 않는다. 기존 reference dynamics만 20033.3초였다. 이를 순차 재실행하면 candidate를 아무리 병렬화해도 큰 serial floor가 남는다. 이번 설계는 그 baseline 자체를 재사용한다.

새 spatial 작업량의 모델은 다음과 같다.

T_ops >= max(sum_i t_i/W, max_i t_i)
T_run = T_input + T_ops + T_ordered_transport + T_checkpoint

여기에 각 VM의 per-worker 성능, memory bandwidth, steal, I/O, task 불균형, pool startup이 더해진다. 실제 completion ETA와 c64의 로컬 대비 speedup은 calibration 후 산출한다. 두 기존 method의 합성 모델 차수 시험은 cloud throughput 측정이 아니다.

공식 한국 요금표의 High CPU-g3 64/128 항목 검색에는 시간당 3192원이 표시된다. [N2] 4시간 서버항목은 단순곱 12768원, 8시간은 25536원이다. VAT, OS/리전/계약, 시간단위 정산, storage, IP, network, 객체 보관 비용은 실제 콘솔 견적으로 확인한다. 이 예시는 총액 보증이나 사용 승인 예산이 아니다.

## 8. Claim ceiling

capture_execution_allowed=false
production_admission=HOLD
all_bound=OPEN
b_grid=NO_GO
original_capture_gap_resolved=false
continuous_global_supremum_bound=false

Cache-only 결과, cloud engine parity, parallel throughput, new temporal convergence를 각각 다른 판정으로 남긴다. 마지막 세 단계는 실제 c64-g3에서 아직 실행하지 않았다.

## 참고

[N1] https://guide.ncloud-docs.com/docs/server-spec-vpc
[N2] https://m.ncloud.com/charge/price/ko
[N3] https://api.ncloud-docs.com/docs/en/get-product-spec
[N4] https://api.ncloud-docs.com/docs/storage-objectstorage
[N5] https://www.ncloud.com/support/faq/all/223
[T1] https://docs.scipy.org/doc/scipy/tutorial/parallel_execution.html
[T2] https://docs.python.org/3/library/multiprocessing.html
[T3] https://gcc.gnu.org/onlinedocs/gcc/x86-Options.html

현재 package source 확인: SOURCE_REVIEW.json. 이 문서의 수식·worker 정책·단계 배치는 이번 재설계이며 클라우드 제공자의 성능 보증이 아니다.
