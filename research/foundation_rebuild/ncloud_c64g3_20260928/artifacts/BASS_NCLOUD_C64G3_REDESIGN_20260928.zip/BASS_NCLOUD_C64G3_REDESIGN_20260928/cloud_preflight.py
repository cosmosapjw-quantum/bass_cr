#!/usr/bin/env python3
"""Read-only host/input inventory. Does not run science, rent, stop or delete a VM.

The worker recommendation is a screening bound, NOT a memory reservation or a
performance guarantee. A serial native pilot must supply measured peak RSS.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone

GIB = 1024**3
TP2D_ARCHIVE_SHA256 = '630a80208331b7b37c02a77eae7435f6317d07439a4ea34b11885455fe53fa35'
TP2E_PACKAGE_SHA256 = '0f7af63b234b8ae527ac1c1ba42c28a9cf89b39f79da329d2b73d8aa2896c7b0'


def worker_plan(logical_count, quota, total_bytes, available_bytes, worker_peak_bytes):
    for name, value in [('logical_count', logical_count), ('total_bytes', total_bytes),
                        ('available_bytes', available_bytes)]:
        if type(value) is not int or value < (1 if name != 'available_bytes' else 0):
            raise ValueError(name + ' must be a valid nonnegative integer (capacity must be positive)')
    if quota is not None and (not math.isfinite(quota) or quota < 0):
        raise ValueError('quota must be nonnegative and finite')
    if worker_peak_bytes is not None and (type(worker_peak_bytes) is not int or worker_peak_bytes <= 0):
        raise ValueError('worker peak RSS must be a positive measured byte count')
    capacity = min(logical_count, math.floor(quota)) if quota is not None else logical_count
    reserve = min(4, capacity//8)
    cpu_cap = max(0, min(60, capacity-reserve))
    budget = min(96*GIB, 3*total_bytes//4, max(0, available_bytes-8*GIB))
    payload_budget = max(0, budget-4*GIB)
    memory_cap = None if worker_peak_bytes is None else (2*payload_budget)//(3*worker_peak_bytes)
    safe_cap = None if memory_cap is None else min(cpu_cap, memory_cap)
    profiles = [] if safe_cap is None else [w for w in (16, 32, 48, 60) if w <= safe_cap]
    action = ('MEASURE_SERIAL_NATIVE_PEAK_RSS_FIRST' if safe_cap is None else
              'RESOURCE_BUDGET_BLOCKED' if safe_cap < 1 else 'CALIBRATE_ELIGIBLE_PROFILES_ONLY')
    return {'effective_logical_capacity': capacity, 'control_cpu_reserve': reserve,
            'cpu_worker_ceiling': cpu_cap, 'memory_budget_bytes': budget,
            'parent_memory_reserve_bytes': 4*GIB, 'worker_rss_safety_factor': 1.5,
            'measured_worker_peak_bytes': worker_peak_bytes, 'memory_worker_ceiling': memory_cap,
            'safe_worker_ceiling': safe_cap, 'eligible_scaling_profiles': profiles,
            'blas_threads_per_worker': 1, 'next_action': action,
            'automatic_science_launch': False, 'guest_core_count_is_not_host_physical_core_proof': True}


def verify_bytes(path, expected_sha256):
    path = Path(path).resolve()
    if len(expected_sha256) != 64 or any(c not in '0123456789abcdef' for c in expected_sha256):
        raise ValueError('expected SHA-256 must contain exactly 64 lowercase hex digits')
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    actual = h.hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'expected_sha256': expected_sha256,
            'actual_sha256': actual, 'sha256_matches': actual == expected_sha256,
            'verification_scope': 'FILE_BYTES_ONLY_NOT_SCIENTIFIC_ADMISSION'}


def read_text(path):
    return Path(path).read_text(encoding='utf-8').strip()


def command(argv):
    try:
        p = subprocess.run(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=10, check=False)
        return {'argv': argv, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {'argv': argv, 'error': type(exc).__name__ + ': ' + str(exc)}


def cgroup_v2_limits():
    """Inspect the visible unified hierarchy, including accessible ancestors.

    Invisible host/ancestor limits cannot be certified from inside a container.
    Legacy cgroup-v1 is deliberately not silently treated as unlimited.
    """
    mount = Path('/sys/fs/cgroup')
    result = {'mode': 'UNKNOWN', 'checked_directories': [], 'quota_values': [],
              'memory_limits': [], 'memory_remaining': [], 'warnings': []}
    if not (mount/'cgroup.controllers').exists():
        result['warnings'].append('cgroup-v2 unavailable; manually inspect v1/host quotas before native scaling')
        return result
    result['mode'] = 'V2_VISIBLE_HIERARCHY'
    current = mount
    try:
        line = next(x for x in read_text('/proc/self/cgroup').splitlines() if x.startswith('0::'))
        relative = line[3:].lstrip('/')
        candidate = (mount/relative).resolve()
        if candidate.is_relative_to(mount.resolve()) and candidate.is_dir():
            current = candidate
        elif relative:
            result['warnings'].append('process cgroup path not directly mounted; inspecting visible namespace root')
    except (OSError, StopIteration, ValueError) as exc:
        result['warnings'].append('cgroup process mapping: ' + str(exc))
    while True:
        result['checked_directories'].append(str(current))
        try:
            amount, period = read_text(current/'cpu.max').split()
            if amount != 'max':
                result['quota_values'].append(int(amount)/int(period))
        except (OSError, ValueError, ZeroDivisionError):
            result['warnings'].append('cpu.max unavailable at ' + str(current))
        try:
            lim = read_text(current/'memory.max')
            if lim != 'max':
                value = int(lim)
                result['memory_limits'].append(value)
                result['memory_remaining'].append(max(0, value-int(read_text(current/'memory.current'))))
        except (OSError, ValueError):
            result['warnings'].append('memory limit/current unavailable at ' + str(current))
        if current == mount or current.parent == current:
            break
        current = current.parent
    return result


def inventory(worker_peak_bytes=None):
    warnings = []
    affinity = sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else list(range(os.cpu_count() or 1))
    info = {}
    try:
        for line in read_text('/proc/meminfo').splitlines():
            key, value = line.split(':', 1)
            if key in ('MemTotal', 'MemAvailable'):
                info[key] = int(value.split()[0])*1024
    except (OSError, ValueError) as exc:
        warnings.append('meminfo unavailable: ' + str(exc))
    cg = cgroup_v2_limits()
    warnings.extend(cg['warnings'])
    total, available = info.get('MemTotal'), info.get('MemAvailable')
    quota = min(cg['quota_values']) if cg['quota_values'] else None
    if total is not None and cg['memory_limits']:
        total = min(total, *cg['memory_limits'])
    if available is not None and cg['memory_remaining']:
        available = min(available, *cg['memory_remaining'])
    plan = None
    if total and available is not None:
        plan = worker_plan(len(affinity), quota, total, available, worker_peak_bytes)
    if cg['mode'] == 'UNKNOWN' or warnings:
        if plan is not None:
            plan['requires_resource_limit_review'] = True
            plan['eligible_scaling_profiles'] = []
    versions = {}
    for name in ('numpy', 'scipy', 'pytest', 'threadpoolctl'):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return {'utc': datetime.now(timezone.utc).isoformat(), 'python': sys.version,
            'platform': platform.platform(), 'machine': platform.machine(),
            'libc': platform.libc_ver(), 'affinity_cpu_ids': affinity,
            'logical_affinity_count': len(affinity), 'cgroup': cg,
            'effective_memory_total_bytes': total, 'effective_memory_available_bytes': available,
            'package_versions': versions, 'worker_plan': plan,
            'lscpu': command(['lscpu', '-J']), 'numa': command(['numactl', '--hardware']),
            'filesystem': command(['df', '-PT', '.']),
            'warnings': warnings, 'is_cloud_performance_measurement': False}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', required=True, help='fresh JSON receipt path')
    p.add_argument('--tp2d-archive')
    p.add_argument('--tp2e-package')
    p.add_argument('--worker-peak-mib', type=float)
    a = p.parse_args(argv)
    out = Path(a.out).resolve()
    if out.exists():
        p.error('output already exists; no overwrite')
    if a.worker_peak_mib is not None and (not math.isfinite(a.worker_peak_mib) or a.worker_peak_mib <= 0):
        p.error('positive finite --worker-peak-mib required')
    peak = None if a.worker_peak_mib is None else int(a.worker_peak_mib*1024**2)
    report = {'schema': 'BASS_NCLOUD_C64G3_PREFLIGHT_V1', 'status': 'IN_PROGRESS',
              'capture_execution_allowed': False, 'production_admission': 'HOLD',
              'cloud_resources_created': False, 'new_operator_evaluations': 0, 'input_checks': []}
    rc = 0
    try:
        report['host'] = inventory(peak)
        for path, sha in [(a.tp2d_archive, TP2D_ARCHIVE_SHA256), (a.tp2e_package, TP2E_PACKAGE_SHA256)]:
            if path is not None:
                report['input_checks'].append(verify_bytes(path, sha))
        if any(not x['sha256_matches'] for x in report['input_checks']):
            report['status'] = 'INPUT_IDENTITY_BLOCKED'; rc = 3
        else:
            report['status'] = 'INVENTORY_COMPLETE_NOT_NATIVE_ADMISSION'
    except Exception as exc:
        report['status'] = 'PREFLIGHT_BLOCKED'; rc = 3
        report['first_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('x', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    print(json.dumps({'status': report['status'], 'receipt': str(out), 'new_operator_evaluations': 0}))
    return rc

if __name__ == '__main__':
    raise SystemExit(main())
