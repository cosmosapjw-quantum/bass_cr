#!/usr/bin/env bash
# Compatibility wrapper for the unchanged TP2E cache-only entrypoint.
# This is not the redesigned native parallel scheduler.
set -euo pipefail
if [[ $# != 3 ]]; then
  echo 'usage: run_cache.sh TP2E_PACKAGE_DIRECTORY TP2D_RETURN_ZIP FRESH_OUTPUT_DIRECTORY' >&2
  exit 2
fi
PKG=$1
SOURCE=$2
OUT=$3
PY=${PYTHON_BIN:-python3}
[[ -f "$PKG/run_cached_m4.py" && -f "$SOURCE" ]] || { echo 'INPUT_NOT_FOUND' >&2; exit 3; }
[[ ! -e "$OUT" && ! -e "${OUT}_RETURN.zip" ]] || { echo 'OUTPUT_EXISTS' >&2; exit 3; }
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export OMP_DYNAMIC=FALSE MKL_DYNAMIC=FALSE PYTHONDONTWRITEBYTECODE=1
exec "$PY" "$PKG/run_cached_m4.py" --source-archive "$SOURCE" --out "$OUT"
