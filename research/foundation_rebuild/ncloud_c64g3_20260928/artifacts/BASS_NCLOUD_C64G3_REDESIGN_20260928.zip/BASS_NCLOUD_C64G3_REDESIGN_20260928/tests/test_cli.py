from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]

class CLITests(unittest.TestCase):
    def test_inventory_in_clean_subprocess(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'host.json'
            p=subprocess.run([sys.executable,str(ROOT/'cloud_preflight.py'),'--out',str(out)],cwd=d,capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
            r=json.loads(out.read_text())
            self.assertEqual(r['status'],'INVENTORY_COMPLETE_NOT_NATIVE_ADMISSION')
            self.assertFalse(r['cloud_resources_created'])
            self.assertEqual(r['new_operator_evaluations'],0)
            self.assertIsNone(r['host']['worker_plan']['safe_worker_ceiling'])

    def test_changed_archive_fails_without_claiming_admission(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'host.json'; z=Path(d)/'incorrect.zip';z.write_bytes(b'not-the-original')
            p=subprocess.run([sys.executable,str(ROOT/'cloud_preflight.py'),'--out',str(out),'--tp2d-archive',str(z)],capture_output=True,text=True)
            self.assertEqual(p.returncode,3)
            r=json.loads(out.read_text());self.assertEqual(r['status'],'INPUT_IDENTITY_BLOCKED')

    def test_existing_receipt_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'host.json';out.write_text('original')
            p=subprocess.run([sys.executable,str(ROOT/'cloud_preflight.py'),'--out',str(out)],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
            self.assertEqual(out.read_text(),'original')

    def test_cache_wrapper_passes_exact_paths_and_thread_limit(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);pkg=root/'package with spaces';pkg.mkdir()
            (pkg/'run_cached_m4.py').write_text('import os,sys,json\nprint(json.dumps({"argv":sys.argv[1:],"blas":os.environ.get("OPENBLAS_NUM_THREADS")}))\n')
            source=root/'source file.zip';source.write_bytes(b'x');out=root/'new output'
            env=dict(os.environ,PYTHON_BIN=sys.executable,OPENBLAS_NUM_THREADS='64')
            p=subprocess.run(['bash',str(ROOT/'run_cache.sh'),str(pkg),str(source),str(out)],env=env,capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
            r=json.loads(p.stdout);self.assertEqual(r['blas'],'1')
            self.assertEqual(r['argv'],['--source-archive',str(source),'--out',str(out)])

    def test_cache_wrapper_never_overwrites_run(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);pkg=root/'pkg';pkg.mkdir();(pkg/'run_cached_m4.py').write_text('raise AssertionError("must not launch")')
            source=root/'s.zip';source.write_bytes(b'x');out=root/'run';out.mkdir()
            p=subprocess.run(['bash',str(ROOT/'run_cache.sh'),str(pkg),str(source),str(out)],capture_output=True,text=True)
            self.assertEqual(p.returncode,3)
            self.assertIn('OUTPUT_EXISTS',p.stderr)
if __name__=='__main__':unittest.main()
