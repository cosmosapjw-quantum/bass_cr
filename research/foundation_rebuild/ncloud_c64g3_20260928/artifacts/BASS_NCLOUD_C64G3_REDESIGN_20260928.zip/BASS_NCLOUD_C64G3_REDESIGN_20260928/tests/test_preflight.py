from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from cloud_preflight import worker_plan, verify_bytes

G = 1024**3

class PolicyTests(unittest.TestCase):
    def test_64_vcpu_does_not_default_to_64_workers(self):
        p = worker_plan(64, None, 128*G, 120*G, G)
        self.assertIsInstance(p, dict)
        self.assertEqual(p['cpu_worker_ceiling'], 60)
        self.assertEqual(p['safe_worker_ceiling'], 60)
        self.assertEqual(p['eligible_scaling_profiles'], [16, 32, 48, 60])

    def test_rss_constrains_cpu_rich_instance(self):
        p = worker_plan(64, None, 128*G, 120*G, 2*G)
        self.assertIsInstance(p, dict)
        self.assertEqual(p['safe_worker_ceiling'], 30)
        self.assertEqual(p['eligible_scaling_profiles'], [16])

    def test_unknown_rss_cannot_admit_many_workers(self):
        p = worker_plan(64, None, 128*G, 120*G, None)
        self.assertIsInstance(p, dict)
        self.assertIsNone(p['safe_worker_ceiling'])
        self.assertEqual(p['eligible_scaling_profiles'], [])
        self.assertEqual(p['next_action'], 'MEASURE_SERIAL_NATIVE_PEAK_RSS_FIRST')

    def test_cpu_quota_is_respected(self):
        p = worker_plan(64, 20.5, 128*G, 120*G, G)
        self.assertIsInstance(p, dict)
        self.assertEqual(p['effective_logical_capacity'], 20)
        self.assertLessEqual(p['safe_worker_ceiling'], 20)

    def test_available_memory_is_not_confused_with_total_memory(self):
        p = worker_plan(64, None, 128*G, 20*G, 2*G)
        self.assertIsInstance(p, dict)
        self.assertEqual(p['memory_budget_bytes'], 12*G)
        self.assertEqual(p['safe_worker_ceiling'], 2)

    def test_subcore_quota_does_not_round_up(self):
        p = worker_plan(64, 0.5, 128*G, 120*G, G)
        self.assertIsInstance(p, dict)
        self.assertEqual(p['safe_worker_ceiling'], 0)

    def test_nonfinite_quota_is_rejected(self):
        with self.assertRaises(ValueError):
            worker_plan(64, float('nan'), 128*G, 120*G, G)

    def test_nonpositive_rss_is_rejected(self):
        with self.assertRaises(ValueError):
            worker_plan(64, None, 128*G, 120*G, 0)

    def test_checksum_mismatch_is_not_admitted(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'source.zip'; p.write_bytes(b'canonical')
            result = verify_bytes(p, '0'*64)
            self.assertIsInstance(result, dict)
            self.assertFalse(result['sha256_matches'])
            self.assertTrue(verify_bytes(p, hashlib.sha256(b'canonical').hexdigest())['sha256_matches'])

    def test_absent_file_is_not_verified(self):
        with self.assertRaises(FileNotFoundError):
            verify_bytes('/not/a/real/input/archive', '0'*64)

if __name__ == '__main__':
    unittest.main()
