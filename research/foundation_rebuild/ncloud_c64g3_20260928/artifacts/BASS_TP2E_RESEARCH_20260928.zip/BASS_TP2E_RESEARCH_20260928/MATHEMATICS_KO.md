# TP2E: 저장된 midpoint 표본으로 만드는 4차 Magnus 비교

## 1. 주장 범위와 컨벤션

이 문서는 새 시간적분 후보의 직접 유도다. 원래 TP2D의 물리 모형, FEM 기저, S/H/D 정의, 공간적분 threshold를 변경하지 않는다. M4-QMQ라는 이름은 이 패키지의 식별자이며 새로운 알고리즘의 우선권을 주장하는 명칭이 아니다. 4차 commutator-free 방법의 비교 구현은 Thalhammer (2006), DOI 10.1137/05063042의 두 Gauss-node 구성에 해당한다. 아래 quarter/midpoint/three-quarter 조합은 그 CF4 식 자체가 아니라 Magnus 전개로 별도 유도한 구성이다.

물리적 시간과 단위를 유지하면

\[
S_{ab}=\langle\chi_a|\chi_b\rangle,\quad
H_{ab}=\langle\chi_a|\hat H|\chi_b\rangle,\quad
D_{ab}=\langle\chi_a|\dot\chi_b\rangle,
\qquad i\hbar S\dot c=(H-i\hbar D)c.
\]

S가 양의 정부호이고 S=R†R인 upper Cholesky 인수를 사용하면 y=Rc에 대해

\[
\dot y=Gy,\qquad
G=\dot R R^{-1}-R^{-\dagger}DR^{-1}
-\frac{i}{\hbar}R^{-\dagger}HR^{-1}.
\]

원 코드의 atomic-unit 컨벤션은 시간 t_a=ħ/E_h, 에너지 E_h, 길이 a_0이며, 무차원 구현에서 ħ가 나타나지 않는 것은 이 계약 때문이다. 이 패키지는 원래 TP1의 metric_frame_generator를 정확한 source SHA로 동봉하여 재사용한다. 새 기저 회전이나 D의 재구성은 도입하지 않는다. 원 구현의 Cholesky 처리도 그대로이며 새로운 사후 skew projection이나 매 step state renormalization을 넣지 않는다.

H=H† 및 Sdot=D+D†가 정확할 때 G†=-G다. 원 generator의 skewness를 확인하는 것만으로 직접 D 또는 Sdot 일관성이 독립적으로 입증되지는 않는다. 기존 직접-D와 finite-difference sentinel 및 DOP853 비교의 역할은 계속 남는다.

## 2. 세 실제 표본을 이용한 식

한 step 폭을 Δt, 중앙을 t_m, 실제 표본을

\[
G_1=G(t_m-\Delta t/4),\quad G_m=G(t_m),\quad
G_3=G(t_m+\Delta t/4)
\]

로 정의한다. 채택한 식은

\[
\boxed{\Omega_{\rm QMQ}=
\frac{\Delta t}{3}(2G_1-G_m+2G_3)
-\frac{\Delta t^2}{6}[G_1,G_3]},\qquad
 y_{n+1}=\exp(\Omega_{\rm QMQ})y_n.
\]

나중 시간의 propagator가 왼쪽에서 곱해지는 컨벤션이다. 반대 commutator 부호를 쓰면 일반적으로 4차가 아니다.

중앙 Taylor 전개를 G(s)=A+sB+s²C/2+s³E/6+…로 쓰자. 첫 Magnus 항은

\[
\Omega_1=\int_{-\Delta t/2}^{\Delta t/2}G(s)\,ds
=\Delta t A+\frac{\Delta t^3}{24}C+O(\Delta t^5).
\]

세 표본의 가중 합도

\[
\frac{\Delta t}{3}(2G_1-G_m+2G_3)
=\Delta t A+\frac{\Delta t^3}{24}C+O(\Delta t^5)
\]

를 준다. 이 열린 세 점 규칙은 cubic polynomial까지 정확하다. 두 번째 Magnus 항은 시간순서 t_1>t_2에서

\[
\Omega_2=\frac12\int ds_1\int^{s_1}ds_2\,[G(s_1),G(s_2)]
=-\frac{\Delta t^3}{12}[A,B]+O(\Delta t^5).
\]

한편 [G_1,G_3]=(Δt/2)[A,B]+O(Δt³)이므로 위 commutator 항과 일치한다. 중앙 반전에 대한 대칭으로 log propagator의 짝수차 항은 사라지고, 나머지 Magnus 항은 이 차수에서 O(Δt⁵)에 기여한다. 충분히 매끄럽고 유계인 유한차원 G에 대해 local error O(Δt⁵), global error O(Δt⁴)다. 이 주장은 실제 FEM/qualification-switching으로 만든 G의 매끄러움을 추가로 증명한 것이 아니다.

## 3. 구조와 극한 점검

G의 차원은 시간⁻¹이므로 Δt G 및 Δt²[G,G]는 모두 무차원이다. G가 상수이면 Ω=ΔtG여서 정확한 exponential로 환원된다. 서로 commute하는 cubic-in-time G에서는 첫 항의 적분이 정확하고 commutator가 0이다.

skew-Hermitian G들의 실수 선형결합과 commutator는 역시 skew-Hermitian이다. 따라서 exact arithmetic에서 exp Ω는 unitary하다. 중앙 가중치가 음수인 것은 이 유한차원 unitary 문제에서 dissipative growth를 만들지 않지만, 일반적인 비가역·수축 semigroup 문제에 같은 논증을 옮길 수는 없다.

표본을 뒤집고 Δt→-Δt로 하면 Ω→-Ω이므로 time reversal도 맞는다. 테스트에는 상수, commuting cubic, 시간역전, noncommuting exact rotating model, 비자명한 time-dependent metric, 잘못된 commutator 부호 및 생략 대조가 포함된다. 잘못된 부호와 commutator 생략도 norm을 거의 정확히 보존하지만 관측 수렴차수는 2다.

## 4. 기존 cache와의 정확한 연결

N개의 macrostep 각각의 중앙은 원 N-step midpoint run의 표본이다. quarter와 three-quarter는 원 2N-step midpoint run의 인접한 두 표본이다. 따라서 기존 N=24,48,96,192,384 기록으로 새 M4의 N=24,48,96,192를 비교할 수 있다. 전체 사용 가능한 midpoint time의 합집합은 744개다. 서로 다른 N과 2N의 midpoint 격자는 중첩되지 않으므로 기존 2차 ladder가 새 표본을 계속 요구했던 것과 모순되지 않는다.

코드는 수학적으로 동치인 t0+(j+1/2)dt로 시간을 재작성하지 않는다. 원 코드의 ta=t0+j*dt, tb=ta+dt, tm=(ta+tb)/2 연산 순서를 복제한다. binary64 time_hex가 없는 경우 CACHE_MISS_EXACT_TIME으로 중단한다. 가장 가까운 표본 선택, interpolation, 임의 epsilon 병합, 새 operator 계산 fallback은 없다. 실수 연산식과의 ulp 차이는 재현성 문제이지 새 interpolation 근거가 아니다.

## 5. 승인 조건과 남은 불확실성

먼저 저장된 N384 endpoint를 원 midpoint 코드로 재생하여 importer와 time arithmetic을 검사한다. 허용 metric distance는 1e-10이다. 이 검사는 18-channel 공간적분을 다시 하지 않는다.

새 M4는 N=24,48,96,192의 고정 ladder에서 인접 두 결과를 비교한다. 높은 쪽과 기존 DOP853 reference의 phase-aligned metric distance 및 인접 두 M4 결과 차이가 각각 1e-6 이하이고 두 norm drift가 1e-8 이하일 때만 비교를 승인한다. Generator 및 Ω skewness의 1e-11 gate도 있다. 기준을 통과시키려고 2차 Richardson의 /3 또는 4차 /15로 원래 refinement threshold를 재해석하지 않는다.

기존 reference는 재사용된 한 개의 DOP853 run이다. 새 독립 reference 실행도 아니며 absolute error bound도 아니다. 같은 공간 operator 오차는 공유된다. 따라서 성공 상태는 TP2E_CACHE_ONLY_M4_COMPARISON_PASS이며 continuous bound, basis completeness, capture, all-bound, b-grid 또는 production 승인이 아니다.
