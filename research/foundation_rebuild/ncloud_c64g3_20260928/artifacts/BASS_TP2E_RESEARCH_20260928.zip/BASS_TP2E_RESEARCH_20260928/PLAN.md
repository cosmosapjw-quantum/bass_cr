# TP2E bounded research implementation record

Scope: analyze the reported TP2D failure; derive and test a cache-only fourth-order method; prepare a separate native multicore work/precision probe. Original source and source evidence remain immutable.

Completed: exact user scalar/progress cost and convergence analysis; source inspection; M4-QMQ derivation; CF4 comparator; constant/noncommuting/time-dependent-metric controls; read-only archive importer; cold synthetic CLI execution; same-center memo tests; spawn plumbing tests; native probe implementation.

Not completed here: full original TP2D ZIP restoration, actual BASS M4 comparison, native same-center parity, 5900X worker/RSS/throughput measurements. Exact source ZIP lookup returned NOT_FOUND in Dropbox; Library search returned no match. Missing bytes were not reconstructed from scalar summaries.

No remaining product decisions are needed for the shipped offline command. Frozen gates are in GRANT.json and EXPERIMENT_CONTRACT.json. The local archive comparison decides the next scientific branch, without auto-relaxing thresholds. The native probe is separately invoked and does launch new spatial integrals.

Tests: core/archive/memo have recorded red-to-green evidence. Subsequent integration tests were written after their implementations and are not relabelled as TDD. A development test-import error was corrected and its initial output is retained. No external independent code review or remote CI is claimed.

Exit statuses: 0 means the scoped method comparison passes; 2 means the numerical/temporal gates do not; 3 means identity/input/test/runtime blocker; 130 means interruption. Outputs are create-only.
