# BASS TP2E 연구 패키지: 새 공간적분 없이 고차 적분 비교

첫 실행은 `run_cached_m4.py`다. 원 TP2D archive를 읽기만 한다. 기존 Git checkout, 실패 기록, native binary를 변경하지 않는다. 필요한 패키지는 기존 Python의 NumPy, SciPy, pytest다. 설치나 업그레이드는 자동 실행하지 않는다.

## 현재 검증 상태

이 배포본은 합성 exact-solution 및 archive fixture로 테스트한 연구용 코드다. 실제 BASS full ZIP은 작성 환경에서 조회되지 않았으므로 실제 TP2E 물리 PASS, native 성능 향상, Ryzen speedup은 아직 측정되지 않았다. 첨부된 TP2D scalar/progress 분석과 4차식 직접 유도는 완료했다. `results/`는 실제 실행한 검사 기록이며 `VALIDATION.json`이 범위를 구분한다.

원 run의 TEMPORAL_REFINEMENT_UNRESOLVED는 그대로 보존한다. source archive의 SHA는 GRANT.json에 고정되어 있다. 다른 archive를 실행 중 자동 수용하거나 report hash를 덮어쓰지 않는다.

## 1. Cache-only M4 실행

ZIP을 Downloads에 풀었다면 아래와 같이 실행한다. 새 output 경로만 생성한다. 과거 TP2D run을 resume하거나 TP2D를 처음부터 다시 실행하지 않는다.

```bash
PKG="$HOME/Downloads/BASS_TP2E_RESEARCH_20260928"
SOURCE="$HOME/Dropbox/bianchi/BASS_CR_R3M10_LOCAL_REPRODUCTION_PACKAGE_20260921_v1/runs/tp2d_runtime_self_qualified_20260927T074944Z_RETURN.zip"
OUT="$HOME/Downloads/tp2e_cached_m4_$(date -u +%Y%m%dT%H%M%SZ)"

python3 "$PKG/run_cached_m4.py" --source-archive "$SOURCE" --out "$OUT"
echo "EXIT=$?"
```

runner가 TP2E 신규 tests를 실행한다. 별도 사전 pytest는 필요 없다. 원 TP1/TP2B/TP2C/TP2D suite를 실행하지 않는다. archive 모든 member의 manifest/hash/size, query time identity, raw cross convergence, selected full S/H/D의 Hermiticity/positive metric을 확인한다. Lower-resolution full matrices는 원 cache에 없으므로 그 full-operator diagnostics는 archive-bound evidence로 구분한다.

그다음 원 N384 endpoint를 작은 행렬만으로 replay하고, 실제 저장된 N·2N midpoint들로 새로운 M4 N=24,48,96,192를 계산한다. 두 M4 결과 차이와 reference 차이가 각각 1e-6 이하이고 norm drift가 1e-8 이하인 최초 쌍에서 종료한다. Temporal mismatch는 2, identity/input/test failure는 3, interrupt는 130, 비교 gate 통과는 0이다.

### 반환

```bash
jq '{status, original_tp2d_status, new_tests, source_audit,
     new_method_temporal_comparison_qualified,
     comparison: {selected_nstep: .comparison.selected_nstep,
                  historical_replay: .comparison.historical_replay,
                  candidates: .comparison.candidates, pairs: .comparison.pairs,
                  new_operator_evaluations: .comparison.new_operator_evaluations,
                  reference_reintegrated: .comparison.reference_reintegrated},
     capture_execution_allowed, production_admission, all_bound, b_grid,
     continuous_trajectory_error_bound, first_failure, wall_seconds}' "$OUT/RETURN_REPORT.json"
sha256sum "$OUT/RETURN_REPORT.json" "${OUT}_RETURN.zip"
```

`${OUT}_RETURN.zip` 하나에 새 audit, replay, candidate/pair JSON·NPZ, tests, progress, report, manifest가 들어 있다. 원 대형 ZIP을 재포함하지 않는다. 실패해도 이미 작성한 audit와 candidate 파일은 보존한다. SOURCE_AUDIT에서 원래 실패를 PASS로 재표기하지 않는다.

## 2. 선택적 실제 5900X 성능 probe

**이 명령은 공간 operator를 새로 계산한다. 첫 cache-only 비교에 필요한 명령이 아니다.** 실제 multicore speedup과 same-center memo 효과가 필요할 때만 별도 수행한다. 전파·capture를 실행하지 않고 25개 고정 시간의 spatial query를 비교한다. q/h ladder 및 screens는 원 계약 그대로다.

```bash
REPO="$HOME/Dropbox/bianchi/BASS_CR_R3M10_LOCAL_REPRODUCTION_PACKAGE_20260921_v1"
PROBE="$HOME/Downloads/tp2e_native_probe_$(date -u +%Y%m%dT%H%M%SZ)"
python3 "$PKG/probe_native.py" \
  --repo "$REPO" \
  --source-archive "$SOURCE" \
  --analytic-build "$REPO/runs/tp2b_analytic_build_20260926T233647Z" \
  --workers 1 8 10 12 --repeats 2 --out "$PROBE"
```

기존 repo HEAD가 c954d68fdc86527453765a563b3a025351163ed9와 다르거나 source pins가 달라지면 중단한다. 자동 checkout/reset/install/build는 없다. worker는 spawn으로 분리하고 BLAS/OpenMP thread 환경을 NumPy import 전에 1로 고정한다. same-center memo는 worker의 메모리 내 함수 binding만 바꾸며 파일을 수정하지 않는다.

baseline original/1 worker, same_center_memo/1 worker, 요청한 여러 worker 수를 동일 25시간 표본과 exact basis/binary로 비교한다. parent가 직전 archive selected S/H/D와 배열 일치 여부 및 rtol=1e-11, atol=1e-12 parity를 검사한다. 이것은 새 scientific threshold가 아니라 implementation-parity probe다. 실제 source qualification은 여전히 1e-9 등 원 gate를 쓴다.

output에는 cold-spawn 포함 wall time, raw evaluation 수, worker peak RSS, bytes 일치 여부, absolute difference, selected q/h가 들어 있다. 처음 serial run 기준 speedup은 개별 관측값이다. 여러 반복의 median/spread와 peak memory를 함께 보고 최종 worker 수를 고른다. OS scheduling, 동시 연구작업, clocks, 메모리 대역폭 때문에 12 workers가 8보다 항상 빠르다고 가정하지 않는다.

현재 probe는 CPU affinity/physical-core 수 및 cgroup v2 quota/memory를 읽는다. 24 SMT workers는 기본 탐색 범위에서 제외한다. CPU topology 확인이 불가능한 플랫폼에서는 결과를 보수적으로 해석한다. 96GB는 사용자가 제공한 host 사양이며 작성 컨테이너의 RAM과 혼동하지 않는다.

## 3. 재현과 파일 역할

- `tp2e_core.py`: M4-QMQ, standard Gauss CF4, exact old time arithmetic.
- `tp2e_archive.py`: read-only archive grant, full manifest와 cached matrix 검증.
- `run_cached_m4.py`: 신규 test → import → historical replay → M4 비교.
- `same_center_memo.py`: 같은 시간의 TT/PP 중복 조립 제거.
- `probe_native.py`: 실제 기존 native backend의 직렬/병렬 성능·동일성 probe.
- `research_metrics.py`: 첨부 scalar log 분석과 exact rotating toy benchmark.
- `vendor/`: 수정하지 않은 TP1 metric/reference helper 두 개.
- `MATHEMATICS_KO.md`: 가정, 유도, 단위·부호·극한·유효범위.
- `REPORT_KO.md`: 이번 연구 판정, 비용 분해, 우선순위.
- `results/`: 실행된 test와 합성·실측 scalar 결과. actual BASS M4 결과가 아니다.

raw cost analysis를 다시 만들 때:

```bash
python3 "$PKG/research_metrics.py" --inputs "$PKG/inputs" --out "$HOME/Downloads/tp2e_metrics_$(date -u +%Y%m%dT%H%M%SZ)"
```

## 미승인 범위

M4의 formal order는 충분한 G(t)의 매끄러움을 가정한다. 원 FEM knot/qualification-level switching에서 실제 order가 감소할 수 있다. `TP2E_CACHE_ONLY_M4_COMPARISON_PASS`는 같은 finite basis/operator evidence와 기존 DOP853 reference에 대한 새 시간적분 비교의 성공일 뿐이다. 독립적인 연속시간 supremum certificate, 같은-center quadrature order20의 새 수렴증명, basis completeness, capture gap 해결, production admission은 아니다.
