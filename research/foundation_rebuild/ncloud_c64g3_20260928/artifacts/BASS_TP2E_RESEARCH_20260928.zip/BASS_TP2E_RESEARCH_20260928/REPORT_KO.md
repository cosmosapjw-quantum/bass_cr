# TP2E 코드 연구 결과

## 결론

기존 TP2D 실패는 midpoint 시간적분의 2차 truncation error와 너무 짧은 finite ladder에 부합한다. Source scalar evidence는 실제 run이며, 새 M4/CF4 비교는 합성 exact-solution 모델에서 검증했다. 실제 BASS 고차 결과와 5900X native speedup은 이 패키지 작성 환경에서 실행하지 않았다. 가장 먼저 새 공간적분 없이 저장된 N·2N midpoint를 재사용하는 M4 비교를 수행한다.

## 실제 비용과 수렴

| N | 단계 seconds | 새 query | raw evals | reference distance | coarse/fine difference | p |
|---:|---:|---:|---:|---:|---:|---:|
| 24 | 818.455 | 24 | 80 | 미기록 | 미기록 | |
| 48 | 1650.007 | 48 | 160 | 0.00016898326 | 0.00051197955 |  |
| 96 | 3161.059 | 96 | 316 | 4.2174806e-05 | 0.00012680879 | 2.002427022889648 |
| 192 | 6138.478 | 192 | 630 | 1.053933e-05 | 3.1635481e-05 | 2.000598240800984 |
| 384 | 12231.601 | 384 | 1260 | 2.6345609e-06 | 7.9047694e-06 | 2.0001487654709194 |

N24의 reference distance와 pair는 원 scalar 자료에 없어서 미기록으로 둔다.

Reference dynamics: 20033.255636 s. Candidate 합계: 23999.600219 s. Total report wall: 44624.633493182 s. Metric/preflight가 reference dynamics와 별도로 약 591.7 s다.

Norm drift는 8.55e-15 이하이지만 N384의 endpoint/reference 오차는 2.634560877280569e-6, 인접차는 7.904769432369909e-6이다. Norm으로 temporal accuracy를 추정했던 이전 낙관론은 정정한다. 관측 p=2.002427, 2.000598, 2.000149다.

## 단순 step 확장을 우선하지 않는 이유

2차 scaling이 계속되면 N768의 reference 오차는 약 6.5864e-7로 낮아지지만 인접차는 약 1.9762e-6으로 여전히 기준을 넘는다. N1536 부근이 두 1e-6 gate를 함께 만족할 후보이나 실행한 결과는 아니다. 현재 query 1279개에서 N768을 추가하면 2047개다. 그 뒤 N1536에서는 두 번째 새 query에서 기존 cap=2048에 막힌다. ladder만 길게 바꾸면 안 된다.

## 코드에서 확인한 재사용 기회

run_tp2d.py는 temporal ladder 실패를 raise한 뒤에야 provider_audit와 최종 science block을 구성하도록 되어 있다. 따라서 false/null은 부분 성공을 report에 보존하지 못한 control-flow 결과다. 원 report는 불변으로 두고 별도 SOURCE_AUDIT에서만 복원한다.

full_operator.assemble_full은 매 cross-resolution마다 TT와 PP를 모두 다시 계산한다. 같은 exact time, basis, trajectory, same_order에서는 이 값이 cross q/h와 무관하다. 4442 raw assemblies에 2배인 8884회 호출이 존재하고, 1279개의 exact time에 두 번이면 2558회로 충분한 구조다. 호출 수의 71.21%를 제거하는 memo를 구현했다. 이는 전체 wall time의 71.21% 감소가 아니다. 실제 비중과 speedup은 native probe에서 측정해야 한다.

## 새 시간적분 후보

M4-QMQ: Ω=Δt(2G1-Gm+2G3)/3 - Δt²[G1,G3]/6. 기존 N과 2N의 midpoint cache에서 세 실제 표본을 읽는다. M4 N=24,48,96,192를 새 operator 없이 비교할 수 있는 구조다. archive에 필요한 정확한 시간 키가 모두 있어야 한다. 상세 가정·유도·단위·부호는 MATHEMATICS_KO.md.

Standard CF4도 비교 구현했다. Gauss node는 기존 midpoint와 일반적으로 다르므로 CF4의 BASS 실험은 새 공간적분을 요구한다. 따라서 이번 우선순위는 cache-only M4다.

## 실제 실행한 exact-solution 대조

Rotating noncommuting 2x2 Hamiltonian exact solution에 대한 N64 오차: midpoint 6.558394e-4, M4-QMQ 4.282545e-7, CF4 8.246246e-8. N64→128에서 M4 p=3.999388, CF4 p=4.000152. commutator 부호 반전/생략은 norm을 보존해도 p≈2로 저하된다. 이 결과는 BASS 물리계의 오차나 호스트 speedup이 아니다.

## 5900X/96GB 권고

새 fixed-node 적분을 할 때는 시간별 full qualification을 spawn worker에 분배한다. 시점은 상태벡터와 독립이고 마지막 행렬 곱은 원래 시간순으로 수행하면 된다. 8,10,12 workers를 실제 wall/RSS/parity로 비교한다. BLAS/OpenMP는 worker당 1 thread로 제한한다. DOP853 adaptive stage를 단순히 workers=12로 병렬화하는 제안은 하지 않는다. 기존 reference는 exact archive grant로 재사용한다.

선택된 S/H/D 1279세트의 배열 자체는 19891008 bytes =18.9695 MiB다. 96GB를 쓰기 위해 억지로 전역 quadrature 배열을 펼칠 필요가 없다. Raw evidence와 worker scratch는 별도이며 peak RSS와 cgroup/affinity 한도를 확인한다. 24 SMT workers가 12 physical workers보다 빠르다고 가정하지 않는다.

고급 JIT, C++ 전체 재작성, GPU, fp32, fast-math, loose tolerance, z 대칭의 무검증 대체, 인접 time 병합은 이번 구현에 없다. Kernel 내부 합산순서를 바꾸지 않는 시간 task 병렬화와 동일한 same-center 반환값 재사용이 먼저다.

## 배포와 제한

이 패키지는 standalone 연구 sidecar다. 기존 GitHub branch, 원본 실패 report, source files, native build를 수정하거나 push하지 않았다. 기존 테스트 전체 재실행 대신 새 단위·합성 integration·spawn tests를 실행했다. 원 BASS full ZIP은 Dropbox/Library에서 조회되지 않았으므로 actual cache admission과 새 M4 비교는 사용자 local run을 필요로 한다. 원자물리·capture model의 승인을 뜻하지 않는다.
