#!/usr/bin/env python3
"""Optional, explicit native work/precision probe on the user's actual host.

Unlike run_cached_m4.py this command DOES recompute spatial operators. It is
not automatically invoked. It benchmarks fixed-time queries, not adaptive ODE
stages, on the exact old basis/build/source. No source files are patched.
"""
from __future__ import annotations
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import argparse,concurrent.futures as cf,json,multiprocessing as mp,resource,subprocess,sys,time
from pathlib import Path
import numpy as np
from tp2e_archive import SourceArchive,EvidenceError,require
from tp2e_core import midpoint_times
from same_center_memo import SameCenterMemo
from run_cached_m4 import verify_own_sources,json_new,npz_new,finish

_STATE={}

def host_resources():
    affinity=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else list(range(os.cpu_count() or 1))
    physical={}
    for cpu in affinity:
        top=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
        try:key=((top/'physical_package_id').read_text().strip(),(top/'core_id').read_text().strip())
        except OSError:key=('unknown',str(cpu))
        physical.setdefault(key,[]).append(cpu)
    quota=None
    try:
        amount,period=Path('/sys/fs/cgroup/cpu.max').read_text().split()
        if amount!='max':quota=float(amount)/float(period)
    except (OSError,ValueError):pass
    available=None
    try:
        available=next(int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
        lim=Path('/sys/fs/cgroup/memory.max').read_text().strip()
        if lim!='max':available=min(available,max(0,int(lim)-int(Path('/sys/fs/cgroup/memory.current').read_text())))
    except (OSError,ValueError,StopIteration):pass
    return {'logical_affinity':affinity,'physical_cores_in_affinity':len(physical),'cpu_quota':quota,
            'one_logical_cpu_per_core':[v[0] for v in physical.values()],
            'available_memory_bytes':available,'blas_threads_per_worker':1}


def _init(repo,build,basis_dir,variant,contract):
    repo=Path(repo);fnd=repo/'research/foundation_rebuild';tp=fnd/'tp2d_runtime_self_qualified_transport_20260927'
    os.environ['BASS_ANALYTIC_SOURCE_ROOT']=str(repo)
    for p in (repo,fnd/'src',fnd/'reaudit_20260925/repair',fnd/'full_operator_20260926',
              fnd/'tp1_short_transport_20260926',fnd/'tp2a_perf_20260926',
              fnd/'tp2a_derivative_aware_20260926',fnd/'tp2a_analytic_pruning_20260926/code',tp):
        sys.path.insert(0,str(p))
    # Pins were verified once by the parent. The existing native loader rechecks
    # its actual source/library hash and platform in every worker.
    from runtime import load_bank
    from bass_foundations.two_center import symmetric_channels,Trajectory
    from cr_repro.observables import projectile_speed_au
    from exact_cross import MomentKernel
    from assemble import assemble
    from qualified_provider import ResolutionQualifiedProvider
    from analytic_adapter import AnalyticEvaluator
    import full_operator
    bank,_=load_bank(basis_dir);channels=symmetric_channels(bank)
    v=projectile_speed_au(contract['energy_keV_per_u'])
    tr=Trajectory(((0.,0.,0.),(contract['b_a0'],0.,0.)),((0.,0.,0.),(0.,0.,v)))
    kernel=MomentKernel(build);memo=None
    if variant=='same_center_memo':
        memo=SameCenterMemo(full_operator.same_center_blocks,tr,channels)
        # Only this isolated worker's Python module binding changes.
        full_operator.same_center_blocks=memo
    evaluator=AnalyticEvaluator(assemble,trajectory=tr,channels=channels,kernel=kernel)
    provider=ResolutionQualifiedProvider(evaluate=evaluator,resolutions=contract['runtime_reference_resolutions'],
        screens=contract['screens'],context_id='EXPLICIT_NATIVE_BENCHMARK_ONLY',out_dir=None,max_unique_queries=1000)
    _STATE.update(provider=provider,memo=memo)


def _query(t):
    provider=_STATE['provider'];memo=_STATE['memo'];before=provider.raw_operator_evaluation_count
    start=time.perf_counter();snap=provider.at(float(t));wall=time.perf_counter()-start
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
    return {'time_hex':float(t).hex(),'wall_seconds':wall,'worker_pid':os.getpid(),'peak_rss_bytes':int(rss),
            'raw_evaluations':provider.raw_operator_evaluation_count-before,'qualification':snap.qualification,
            'same_center_memo_hits_cumulative':None if memo is None else memo.hits,
            'same_center_computations_cumulative':None if memo is None else memo.misses,
            'same_center_seconds_cumulative':None if memo is None else memo.compute_seconds,
            'arrays':{k:getattr(snap,k) for k in ('S','H','D')}}


def _toy_query(x):
    # Spawn-test seam, not a native BASS benchmark.
    return x,float(x*x)


def parallel_toy(values,workers):
    with cf.ProcessPoolExecutor(max_workers=workers,mp_context=mp.get_context('spawn')) as pool:
        return list(pool.map(_toy_query,values))


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-archive',required=True);p.add_argument('--repo',required=True)
    p.add_argument('--analytic-build',required=True);p.add_argument('--out',required=True)
    p.add_argument('--workers',type=int,nargs='+',default=[1,8,10,12])
    p.add_argument('--repeats',type=int,default=2)
    a=p.parse_args(argv);out=Path(a.out).resolve();repo=Path(a.repo).resolve();build=Path(a.analytic_build).resolve()
    if out.exists() or out.with_name(out.name+'_RETURN.zip').exists():p.error('output exists')
    if a.repeats<1 or min(a.workers)<1:p.error('positive workers/repeats required')
    out.mkdir(parents=True);start=time.monotonic();runs=[];rc=0
    report={'schema':'TP2E_NATIVE_BENCHMARK_V1','status':'IN_PROGRESS','capture_execution_allowed':False,
        'production_admission':'HOLD','all_bound':'OPEN','b_grid':'NO_GO','new_reference_run':False,
        'runs':runs,'benchmark_is_not_full_transport_qualification':True}
    try:
        report['source_manifest_sha256']=verify_own_sources();grant=json.loads((Path(__file__).parent/'GRANT.json').read_text())
        source=SourceArchive(a.source_archive,grant);report['source_audit']=source.audit
        head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
        require(head==grant['execution_head'],'benchmark requires exact old source commit; do not auto-switch dirty checkout')
        tp=repo/'research/foundation_rebuild/tp2d_runtime_self_qualified_transport_20260927'
        # Check the complete original scientific source closure in a clean child.
        check="import sys;sys.path.insert(0,sys.argv[1]);import run_tp2d;run_tp2d.verify_sources()"
        subprocess.run([sys.executable,'-c',check,str(tp)],check=True,env=dict(os.environ,BASS_ANALYTIC_SOURCE_ROOT=str(repo)))
        b=json.loads((build/'BUILD.json').read_text())
        require(b['source_sha256']==grant['analytic_source_sha256'] and b['library_sha256']==grant['analytic_library_sha256'],
                'benchmark build receipt differs from canonical source run')
        host=host_resources();report['host']=host
        limit=host['physical_cores_in_affinity']
        if host['cpu_quota'] is not None:limit=min(limit,max(1,int(host['cpu_quota'])))
        require(max(a.workers)<=limit,'worker request exceeds physical-core/CPU-quota budget')
        basis=out/'basis';basis.mkdir()
        for name in ('BASIS.json','BASIS.npz'):(basis/name).write_bytes(source.files[name])
        ref=source.reference();ts=ref['arrays']['times'];times=midpoint_times(float(ts[0]),float(ts[-1]),24).tolist()+[0.]
        for t in times:source.at(t)
        report['planned_tasks_per_run']=len(times)
        profiles=[('original',1)]+[('same_center_memo',w) for w in sorted(set([1]+a.workers))]
        baseline=None;max_rss=0
        for variant,w in profiles:
            for rep in range(a.repeats):
                if max_rss and host['available_memory_bytes'] is not None:
                    require(1.5*w*max_rss < .7*host['available_memory_bytes'],'worker memory headroom gate failed')
                tag=f'{variant}_w{w}_r{rep+1}';rows=[];tic=time.perf_counter();arrayset={};bitwise=True;max_abs=0.
                with cf.ProcessPoolExecutor(max_workers=w,mp_context=mp.get_context('spawn'),initializer=_init,
                        initargs=(str(repo),str(build),str(basis),variant,source.contract)) as pool:
                    futures={pool.submit(_query,t):t for t in times}
                    for future in cf.as_completed(futures):
                        r=future.result();snap=source.at(float.fromhex(r['time_hex']));arrays=r.pop('arrays')
                        for k,v in arrays.items():
                            old=getattr(snap,k);diff=float(np.max(np.abs(v-old)));max_abs=max(max_abs,diff)
                            bitwise=bitwise and np.array_equal(v,old)
                            require(np.allclose(v,old,rtol=1e-11,atol=1e-12),'native implementation parity failed: '+tag)
                            arrayset[r['time_hex']+'__'+k]=v
                        require(r['qualification']['selected_resolution']==snap.qualification['selected_resolution'],
                                'native qualification selected resolution changed')
                        rows.append(r);max_rss=max(max_rss,r['peak_rss_bytes'])
                wall=time.perf_counter()-tic
                if variant=='original' and baseline is None:baseline=wall
                row={'profile':tag,'variant':variant,'workers':w,'repeat':rep+1,'wall_seconds_including_spawn':wall,
                     'new_queries':len(rows),'raw_evaluations':sum(r['raw_evaluations'] for r in rows),
                     'max_worker_peak_rss_bytes':max(r['peak_rss_bytes'] for r in rows),'all_array_bytes_match':bitwise,
                     'max_array_absolute_difference':max_abs,'tolerance_parity_passed':True,
                     'speedup_against_first_cold_serial_run':baseline/wall,'tasks':sorted(rows,key=lambda x:float.fromhex(x['time_hex']))}
                json_new(out/(tag+'.json'),row);npz_new(out/(tag+'.npz'),**arrayset);runs.append(row)
                print(json.dumps({k:v for k,v in row.items() if k!='tasks'}),flush=True)
        report['status']='TP2E_NATIVE_BENCHMARK_COMPLETE_NOT_PRODUCTION_ADMISSION'
    except KeyboardInterrupt:report['status']='INTERRUPTED';rc=130
    except Exception as e:
        import traceback
        report['status']='BENCHMARK_BLOCKED_OR_PARITY_FAILED';rc=3
        report['first_failure']={'type':type(e).__name__,'message':str(e)}
        (out/'failure.traceback.txt').write_text(traceback.format_exc())
    report['wall_seconds']=time.monotonic()-start;finish(out,report);return rc

if __name__=='__main__':raise SystemExit(main())
