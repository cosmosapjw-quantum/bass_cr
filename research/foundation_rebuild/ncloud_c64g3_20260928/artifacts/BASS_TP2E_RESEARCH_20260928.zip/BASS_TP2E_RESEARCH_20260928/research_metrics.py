#!/usr/bin/env python3
"""Reproduce scalar analysis and exact-solution temporal-method controls."""
from __future__ import annotations
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json,platform,sys,time
from pathlib import Path
import numpy as np
import scipy
from scipy.linalg import expm
from tp2e_core import m4_qmq_omega,cf4_step


def analyze(directory):
    directory=Path(directory)
    progress=[json.loads(line) for line in (directory/'PROGRESS.jsonl').read_text().splitlines() if line.strip()]
    ref=next(r for r in progress if r['phase']=='reference_transport' and r['event']=='complete')
    refstart=next(r for r in progress if r['phase']=='reference_transport' and r['event']=='start')
    prior_t=next(r['elapsed_seconds'] for r in progress if r['phase']=='candidate_transport' and r['event']=='start')
    prior_query=ref['unique_runtime_queries_after'];prior_raw=ref['raw_operator_evaluations_after'];rows=[]
    previous_error=None
    for r in progress:
        if r.get('event')!='candidate_complete':continue
        n=r['nstep'];p=directory/f'TEMPORAL_PAIR_N{n//2}_N{n}.json'
        pair=json.loads(p.read_text()) if p.exists() else None
        row={'nstep':n,'stage_seconds':r['elapsed_seconds']-prior_t,
             'new_unique_queries':r['unique_runtime_queries_after']-prior_query,
             'new_raw_operator_evaluations':r['raw_operator_evaluations_after']-prior_raw,
             'seconds_per_new_query':(r['elapsed_seconds']-prior_t)/(r['unique_runtime_queries_after']-prior_query),
             'norm_drift':r['max_norm_drift']}
        if pair:
            e=pair['candidate_reference_metric_distance'];d=pair['candidate_refinement_metric_distance']
            row.update(reference_distance=e,refinement_distance=d,delta_to_reference_ratio=d/e,
                       observed_order=None if previous_error is None else float(np.log2(previous_error/e)))
            previous_error=e
        prior_t=r['elapsed_seconds'];prior_query=r['unique_runtime_queries_after'];prior_raw=r['raw_operator_evaluations_after'];rows.append(row)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.iterdir())
            if p.name.startswith(('CANDIDATE_N','TEMPORAL_PAIR_','METRIC_CONNECTION','RETURN_REPORT','PROGRESS')) and p.is_file()}
    report={
        'source':'USER_UPLOADED_ACTUAL_TP2D_SCALAR_EVIDENCE',
        'input_sha256':hashes,'reference_stage_seconds':ref['elapsed_seconds']-refstart['elapsed_seconds'],
        'reference':ref,'candidate_stages':rows,'candidate_total_seconds':sum(r['stage_seconds'] for r in rows),
        'final_unique_queries':prior_query,'final_raw_evaluations':prior_raw,
        'same_center_call_count_if_two_per_assembly':2*prior_raw,
        'same_center_call_count_with_exact_query_memo':2*prior_query,
        'same_center_call_elimination_fraction':1-prior_query/prior_raw,
        'selected_matrix_payload_bytes':prior_query*3*18*18*16,
        'linear_extension_query_counts':{'after_N768':prior_query+768,'after_N1536':prior_query+768+1536},
        'old_query_cap':2048,
        'second_order_extrapolations':[{'nstep':n,'reference_distance':rows[-1]['reference_distance']*(384/n)**2,
             'adjacent_refinement_distance':rows[-1]['refinement_distance']*(384/n)**2,
             'classification':'CONDITIONAL_EXTRAPOLATION_NOT_EXECUTED'} for n in (768,1536)]}
    return report


def toy_benchmark():
    X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1]).astype(complex)
    y0=np.array([1,0],complex);tmax=4.;omega=1.3;a=.7;b=-.2
    def G(t):return -1j*(a*np.cos(omega*t)*X+a*np.sin(omega*t)*Y+b*Z)
    exact=expm(-.5j*omega*tmax*Z)@expm(-1j*(a*X+(b-.5*omega)*Z)*tmax)@y0
    allrows=[]
    for method in ('midpoint','m4_qmq','cf4','m4_wrong_commutator_sign','m4_no_commutator'):
        previous=None
        for n in (8,16,32,64,128):
            tic=time.perf_counter();h=tmax/n;y=y0.copy()
            for j in range(n):
                t=j*h
                if method=='midpoint':y=expm(h*G(t+h/2))@y
                elif method=='cf4':y=cf4_step(G(t+h*(.5-np.sqrt(3)/6)),G(t+h*(.5+np.sqrt(3)/6)),h,y)
                else:
                    g1,gm,g3=G(t+h/4),G(t+h/2),G(t+3*h/4)
                    om=m4_qmq_omega(g1,gm,g3,h)
                    if method=='m4_wrong_commutator_sign':om+=h*h/3*(g1@g3-g3@g1)
                    if method=='m4_no_commutator':om+=h*h/6*(g1@g3-g3@g1)
                    y=expm(om)@y
            err=float(np.linalg.norm(y-exact))
            allrows.append({'method':method,'nstep':n,'absolute_state_error':err,
                'norm_drift':float(abs(np.vdot(y,y).real-1)),
                'observed_order':None if previous is None else float(np.log2(previous/err)),
                'matrix_only_seconds':time.perf_counter()-tic})
            previous=err
    return {'scope':'SYNTHETIC_EXACT_NONCOMMUTING_2X2_NOT_BASS_NOT_RYZEN_BENCHMARK',
            'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),
            'rows':allrows}


def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    for name,obj in [('ACTUAL_TP2D_ANALYSIS.json',analyze(a.inputs)),('EXACT_SOLUTION_BENCHMARK.json',toy_benchmark())]:
        (out/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')

if __name__=='__main__':main()
