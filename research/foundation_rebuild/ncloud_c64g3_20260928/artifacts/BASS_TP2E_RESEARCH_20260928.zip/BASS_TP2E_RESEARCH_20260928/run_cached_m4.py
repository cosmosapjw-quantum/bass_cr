#!/usr/bin/env python3
"""TP2E offline temporal-method comparison; canonical TP2D remains unchanged."""
from __future__ import annotations
# Configure BLAS before importing NumPy/SciPy, not merely in a pytest child.
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import argparse,hashlib,json,platform,subprocess,sys,time,traceback,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
import numpy as np
from metric_transport import metric_frame_generator,run_candidate,phase_aligned_metric_distance
from tp2e_archive import SourceArchive,EvidenceError,require
from tp2e_core import run_cached_m4,midpoint_times


def json_new(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())


def npz_new(path,**arrays):
    with Path(path).open('xb') as f:
        np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())


def verify_own_sources():
    manifest=json.loads((HERE/'SOURCE_MANIFEST.json').read_text())
    for rel,expected in manifest['files'].items():
        p=HERE/rel
        require(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected,'package source mismatch: '+rel)
    return hashlib.sha256((HERE/'SOURCE_MANIFEST.json').read_bytes()).hexdigest()


def new_tests(out):
    env=dict(os.environ,PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    cmd=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider',str(HERE/'tests'),'--junitxml='+str(out/'tests.xml')]
    with (out/'tests.stdout').open('x') as so,(out/'tests.stderr').open('x') as se:
        p=subprocess.run(cmd,cwd=HERE,env=env,stdout=so,stderr=se,timeout=180)
    counts={k:0 for k in ('tests','failures','errors','skipped')}
    if (out/'tests.xml').exists():
        for suite in ET.parse(out/'tests.xml').getroot().iter('testsuite'):
            for k in counts:counts[k]+=int(suite.attrib.get(k,0))
    return {**counts,'returncode':p.returncode,'command':cmd}


def compare_source(source,out,emit, *, ladder=(24,48,96,192)):
    """No assembler dependency: source is a validated, read-only exact-time map."""
    json_new(out/'SOURCE_AUDIT.json',source.audit)
    ref=source.reference();a=ref['arrays'];t0=float(a['times'][0]);tf=float(a['times'][-1]);sf=source.at(tf).S
    c0=a['initial_state'];cref=a['final_state'];screens=source.grant['screens']
    reference={'receipt':ref['receipt'],'metric_norm_drift_recomputed':ref['metric_norm_drift_recomputed'],
               'evidence_relation':ref['evidence_relation']}
    json_new(out/'REFERENCE_REUSE.json',reference)
    # First test the newly imported cache and arithmetic against a historical
    # endpoint. This replays small matrices, not 18-channel spatial integrals.
    n_old=source.grant['historical_step_counts'][-1]
    old=source.arrays(f'CANDIDATE_N{n_old}.npz')
    replay=run_candidate(source,c0,t0,tf,n_old)
    distance=phase_aligned_metric_distance(old['final_state'],replay.final_state,sf)
    ref_distance=phase_aligned_metric_distance(cref,replay.final_state,sf)
    control={'nstep':n_old,'stored_vs_replayed_metric_distance':distance,
             'replayed_reference_distance':ref_distance,'new_operator_evaluations':0,
             'replay_gate':1e-10,'passed':bool(distance<=1e-10)}
    json_new(out/'MIDPOINT_REPLAY.json',control);emit('midpoint_replay_complete',**control)
    require(control['passed'],'historical midpoint endpoint replay mismatch')
    # Resolve ALL requested exact node identities before executing the new
    # method. No nearest-time substitution or partial-node extrapolation.
    required={float(t).hex() for n in ladder for count in (n,2*n) for t in midpoint_times(t0,tf,count)}
    missing=sorted(required-set(source.snapshots))
    require(not missing,'CACHE_MISS_EXACT_TIME preflight: '+str(missing[:3]))
    results=[];pairs=[];previous=None;selected=None
    for n in ladder:
        start=time.perf_counter()
        r=run_cached_m4(source,c0,t0,tf,n,metric_frame_generator)
        dref=phase_aligned_metric_distance(cref,r.final_state,sf)
        row={'nstep':n,'dt':r.dt,'reference_metric_distance':dref,'max_norm_drift':r.max_norm_drift,
             'max_generator_defect':r.max_generator_defect,'max_omega_defect':r.max_omega_defect,
             'matrix_only_wall_seconds':time.perf_counter()-start,'new_operator_evaluations':0}
        npz_new(out/f'M4_N{n}.npz',initial_state=r.initial_state,final_state=r.final_state,norm_history=r.norm_history)
        json_new(out/f'M4_N{n}.json',row);results.append(row);emit('m4_candidate_complete',**row)
        if previous is not None:
            prev,prevrow=previous
            delta=phase_aligned_metric_distance(prev.final_state,r.final_state,sf)
            good=bool(dref<=screens['candidate_reference_metric_distance_max'] and
                      delta<=screens['candidate_refinement_metric_distance_max'] and
                      max(prev.max_norm_drift,r.max_norm_drift)<=screens['candidate_norm_drift_max'])
            pair={'previous_nstep':prev.nstep,'selected_nstep':n,'candidate_reference_metric_distance':dref,
                  'candidate_refinement_metric_distance':delta,'qualified':good,
                  'reference_gate':screens['candidate_reference_metric_distance_max'],
                  'refinement_gate':screens['candidate_refinement_metric_distance_max'],
                  'norm_gate':screens['candidate_norm_drift_max'],
                  'evidence_relation':'NEW_TEMPORAL_METHOD_SAME_PINNED_OPERATOR_CACHE_AND_REFERENCE'}
            json_new(out/f'M4_PAIR_N{prev.nstep}_N{n}.json',pair);pairs.append(pair);emit('m4_pair_assessed',**pair)
            if good:selected=n;break
        previous=(r,row)
    return {'status':('TP2E_CACHE_ONLY_M4_COMPARISON_PASS' if selected else 'TP2E_M4_TEMPORAL_REFINEMENT_UNRESOLVED'),
            'new_method_temporal_comparison_qualified':selected is not None,'selected_nstep':selected,
            'reference_reuse':reference,'historical_replay':control,'candidates':results,'pairs':pairs,
            'exact_cached_nodes_required':len(required),'cache_lookup_count':source.lookup_count,
            'new_operator_evaluations':0,'reference_reintegrated':False}


def finish(out,report):
    json_new(out/'RETURN_REPORT.json',report)
    manifest={str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
              for p in sorted(out.rglob('*')) if p.is_file()}
    json_new(out/'MANIFEST.json',manifest)
    archive=out.with_name(out.name+'_RETURN.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(out)))
    print(json.dumps({'status':report['status'],'report':str(out/'RETURN_REPORT.json'),'archive':str(archive),
                      'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2),flush=True)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-archive',required=True)
    parser.add_argument('--out',required=True)
    a=parser.parse_args(argv);out=Path(a.out).resolve()
    if out.exists() or out.with_name(out.name+'_RETURN.zip').exists():
        parser.error('output exists; no overwrite is permitted')
    out.mkdir(parents=True);start=time.monotonic();phase='source_preflight';code=0
    report={'schema':'TP2E_OFFLINE_RESEARCH_RETURN_V1','status':'IN_PROGRESS','original_tp2d_status':'TEMPORAL_REFINEMENT_UNRESOLVED',
        'capture_execution_allowed':False,'production_admission':'HOLD','all_bound':'OPEN','b_grid':'NO_GO',
        'original_capture_gap_resolved':False,'continuous_trajectory_error_bound':False,'continuous_global_supremum_bound':False,
        'operator_interpolation_used':False,'new_operator_evaluations':0,'reference_reintegrated':False,
        'new_method_temporal_comparison_qualified':False,'python':sys.version,'platform':platform.platform()}
    def emit(event,**kw):
        row={'elapsed_seconds':time.monotonic()-start,'event':event,**kw}
        with (out/'PROGRESS.jsonl').open('a') as f:
            f.write(json.dumps(row,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
        print(json.dumps(row),flush=True)
    emit('run_start',out=str(out))
    try:
        report['source_manifest_sha256']=verify_own_sources()
        grant=json.loads((HERE/'GRANT.json').read_text())
        report['experiment_contract']=json.loads((HERE/'EXPERIMENT_CONTRACT.json').read_text())
        phase='new_tests';report['new_tests']=new_tests(out);emit('new_tests_complete',**report['new_tests'])
        require(report['new_tests']['returncode']==0 and report['new_tests']['tests']>0 and
                not any(report['new_tests'][k] for k in ('failures','errors','skipped')),'new test suite failed')
        phase='archive_admission';source=SourceArchive(a.source_archive,grant)
        report['source_audit']=source.audit;emit('archive_admitted',**source.audit)
        phase='temporal_comparison'
        science=compare_source(source,out,emit,ladder=tuple(report['experiment_contract']['step_counts']));report['comparison']=science;report['status']=science['status']
        report['new_method_temporal_comparison_qualified']=science['new_method_temporal_comparison_qualified']
        code=0 if science['new_method_temporal_comparison_qualified'] else 2
    except KeyboardInterrupt:
        report['status']='INTERRUPTED';code=130
        report['first_failure']={'phase':phase,'type':'KeyboardInterrupt'}
    except EvidenceError as e:
        report['status']='NEW_TESTS_FAILED' if phase=='new_tests' else 'EVIDENCE_OR_IDENTITY_BLOCKED';code=3
        report['first_failure']={'phase':phase,'type':type(e).__name__,'message':str(e)}
        (out/'failure.traceback.txt').write_text(traceback.format_exc())
    except ArithmeticError as e:
        report['status']='NEW_METHOD_NUMERICAL_SCREEN_FAILED';code=2
        report['first_failure']={'phase':phase,'type':type(e).__name__,'message':str(e)}
        (out/'failure.traceback.txt').write_text(traceback.format_exc())
    except Exception as e:
        report['status']='EXECUTION_OR_ENVIRONMENT_BLOCKED';code=3
        report['first_failure']={'phase':phase,'type':type(e).__name__,'message':str(e)}
        (out/'failure.traceback.txt').write_text(traceback.format_exc())
    report['wall_seconds']=time.monotonic()-start;finish(out,report);return code

if __name__=='__main__':raise SystemExit(main())
