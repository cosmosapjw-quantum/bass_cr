"""Worker-local, fixed-asset memo. Does not change the quadrature or summation.

Only the two own-center blocks at the current exact time are retained. Other
trajectory/channel objects fall through to the original implementation.
"""
from __future__ import annotations
import time


class SameCenterMemo:
    def __init__(self,original,trajectory,channels):
        if not callable(original):raise ValueError('callable original required')
        self.original=original;self.trajectory=trajectory;self.channels=tuple(channels)
        self.cache={};self.time_hex=None;self.hits=0;self.misses=0;self.compute_seconds=0.

    @property
    def entries(self):return len(self.cache)

    def __call__(self,trajectory,channels,t,center,*,order=20):
        channels=tuple(channels)
        fixed=(trajectory is self.trajectory and len(channels)==len(self.channels)
               and all(a is b for a,b in zip(channels,self.channels)))
        if not fixed:return self.original(trajectory,channels,t,center,order=order)
        hx=float(t).hex()
        if hx!=self.time_hex:self.cache.clear();self.time_hex=hx
        key=(center,order)
        if key in self.cache:self.hits+=1;return self.cache[key]
        tic=time.perf_counter();value=self.original(trajectory,channels,t,center,order=order)
        self.compute_seconds+=time.perf_counter()-tic;self.misses+=1
        # A changed same-center order is not allowed to grow an unbounded cache.
        for old in list(self.cache):
            if old[0]==center:del self.cache[old]
        self.cache[key]=value;return value
