"""Synthetic integration fixture. Never passed as the canonical BASS grant."""
import hashlib,io,json,zipfile
from pathlib import Path
import numpy as np
from tp2e_core import midpoint_times


def digest(data): return hashlib.sha256(data).hexdigest()
def js(obj): return (json.dumps(obj,sort_keys=True,allow_nan=False)+'\n').encode()
def objdigest(obj): return digest(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def npz(**arrays):
    f=io.BytesIO();np.savez_compressed(f,**arrays);return f.getvalue()


def make_archive(directory, *, mutate=None, step_counts=None):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    grant=json.loads((Path(__file__).parents[1]/'GRANT.json').read_text())
    steps=[2,4,8,16] if step_counts is None else list(step_counts)
    grant.update(execution_head='fixture-head',execution_tree='fixture-tree',channel_count=2,
                 test_count=1,reference_nfev=17,historical_step_counts=steps)
    contract={k:grant[k] for k in ('energy_keV_per_u','b_a0','z_initial_a0','z_final_a0',
                                'same_center_order','screens','runtime_reference_resolutions')}
    contract.update(reference_solver={'method':'DOP853','rtol':1e-10,'atol':1e-12},
                    candidate_step_counts=steps,qualification_sector='full',runtime_phase_budget=None,
                    operator_interpolation_used=False)
    bdata=npz(edges=np.array([0.,1.]),coefficients=np.array([[[1.]]]))
    brec={'schema':'BASS_TP2A_BASIS_V1','matrix_sha256':digest(bdata),'modes':[]}
    brec['identity']=objdigest(brec)
    physics={'basis_identity':brec['identity'],'same_center_order':20,'qualification_sector':'full',
             'analytic_source_sha256':grant['analytic_source_sha256'],
             'analytic_library_sha256':grant['analytic_library_sha256']}
    context={'contract':contract,'physics_identity':physics};cid=objdigest(context)
    files={'SCIENCE_CONTEXT.json':js({'context':context,'context_id':cid}),
           'BASIS.json':js(brec),'BASIS.npz':bdata}
    t0,tf=-1.,1.
    times={float(t).hex():float(t) for n in steps for t in midpoint_times(t0,tf,n)}
    times.update({float(t).hex():float(t) for t in (t0,0.,tf)})
    S=np.eye(2,dtype=complex);H=np.diag([.3,-.2]).astype(complex);D=np.zeros((2,2),complex)
    raw={k:np.zeros((1,1),complex) for k in ('S_tp','S_pt','H_tp','H_pt','D_tp','D_pt')}
    rule0,rule1=grant['runtime_reference_resolutions'][:2]
    diag={'S_hermiticity_relative':0.,'H_hermiticity_relative':0.,'hermiticity_relative_max':0.,
          'hermiticity_pass':True,'metric_min':1.,'metric_max':1.,'metric_ratio':1.,'metric_pass':True}
    for hx,t in times.items():
        qid=objdigest({'schema':'BASS_TP2D_RUNTIME_QUERY_V1','context_id':cid,'time_hex':hx})
        arrays={'selected__S':S,'selected__H':H,'selected__D':D}
        attempts=[]
        for j,rule in enumerate((rule0,rule1)):
            tag=f"q{rule['order']}_h{rule['subdivisions']}"
            arrays.update({tag+'__'+k:a for k,a in raw.items()})
            attempts.append({'resolution':rule,'diagnostics':diag,
                             'previous_raw_cross_relative_max':0. if j else None,
                             'previous_raw_cross_relative_differences':{k:0. for k in raw} if j else None,
                             'raw_cross_convergence_pass':True if j else None})
        data=npz(**arrays)
        rec={'schema':'BASS_TP2D_QUALIFIED_RUNTIME_QUERY_V1','query_id':qid,'context_id':cid,'time_hex':hx,
             'payload_sha256':digest(data),'selected_diagnostics':diag,'attempts':attempts,
             'qualification':{'status':'RUNTIME_QUERY_QUALIFIED','lower_resolution':rule0,'selected_resolution':rule1,
                 'max_raw_cross_relative_difference':0.,'raw_cross_relative_differences':{k:0. for k in raw},
                 'evidence_relation':'INDEPENDENT_NUMERICAL_RESOLUTION_COMPARISON'},
             'capture_execution_allowed':False,'continuous_global_supremum_bound':False}
        files[f'runtime_queries/{qid}.json']=js(rec);files[f'runtime_queries/{qid}.npz']=data
    ts=np.array([t0,0.,tf]);c0=np.array([1.,1j],complex)/np.sqrt(2)
    states=np.array([np.exp(-1j*np.diag(H)*(t-t0))*c0 for t in ts])
    files['REFERENCE_STATES.npz']=npz(times=ts,states=states,initial_state=c0,final_state=states[-1],norm_history=np.ones(3))
    files['REFERENCE_RECEIPT.json']=js({'method':'DOP853','rtol':1e-10,'atol':1e-12,'nfev':17,'max_norm_drift':2e-16})
    files['METRIC_CONNECTION.json']=js([{'z_a0':z,'relative_residual':0.} for z in (-12.,-6.,0.,6.,12.)])
    for n in steps:
        files[f'CANDIDATE_N{n}.npz']=npz(initial_state=c0,final_state=states[-1],norm_history=np.ones(n+1))
        files[f'CANDIDATE_N{n}.json']=js({'nstep':n,'max_norm_drift':2e-16,
            'raw_operator_evaluations_after':2*len(times),'unique_runtime_queries_after':len(times)})
    grant['query_count']=len(times);grant['raw_evaluation_count']=2*len(times)
    report={'status':grant['status'],'execution_head':grant['execution_head'],'execution_tree':grant['execution_tree'],
        'new_tests':{'tests':1,'failures':0,'errors':0,'skipped':0,'returncode':0},
        'first_failure':{'phase':'candidate_transport','message':'finite candidate temporal ladder exhausted without qualification'},
        'capture_execution_allowed':False,'production_admission':'HOLD','all_bound':'OPEN','b_grid':'NO_GO',
        'original_capture_gap_resolved':False,'continuous_trajectory_error_bound':False,'continuous_global_supremum_bound':False}
    files['RETURN_REPORT.json']=js(report)
    if mutate:mutate(files)
    files['MANIFEST.json']=js({k:{'sha256':digest(v),'bytes':len(v)} for k,v in files.items()})
    path=directory/'fixture.zip'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for k,v in files.items():z.writestr(k,v)
    grant['archive_sha256']=digest(path.read_bytes());grant['report_sha256']=digest(files['RETURN_REPORT.json'])
    return path,grant
