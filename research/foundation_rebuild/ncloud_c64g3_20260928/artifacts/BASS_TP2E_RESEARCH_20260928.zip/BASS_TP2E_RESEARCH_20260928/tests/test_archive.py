import json,hashlib,zipfile
import numpy as np
import pytest
from tp2e_archive import SourceArchive,EvidenceError
from fixture_archive import make_archive,js


def test_admit_replay_preserves_original_failure_and_exact_cache(tmp_path):
    path,g=make_archive(tmp_path)
    source=SourceArchive(path,g)
    assert source.audit['original_status']=='TEMPORAL_REFINEMENT_UNRESOLVED'
    assert source.audit['selected_operator_payloads_revalidated']==g['query_count']
    assert source.audit['new_operator_evaluations']==0
    assert source.at(-1.).S.shape==(2,2)
    assert not source.at(-1.).S.flags.writeable
    with pytest.raises(EvidenceError,match='CACHE_MISS_EXACT_TIME'):
        source.at(np.nextafter(-1.,0.))


def test_refuse_wrong_archive_hash(tmp_path):
    p,g=make_archive(tmp_path);g['archive_sha256']='0'*64
    with pytest.raises(EvidenceError,match='archive hash'):
        SourceArchive(p,g)


def test_refuse_duplicate_members_even_with_new_fixture_hash(tmp_path):
    p,g=make_archive(tmp_path)
    with zipfile.ZipFile(p,'a') as z:
        z.writestr('duplicate','a')
        with pytest.warns(UserWarning,match='Duplicate name'):
            z.writestr('duplicate','b')
    g['archive_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    with pytest.raises(EvidenceError,match='duplicate'):
        SourceArchive(p,g)


def test_refuse_noncanonical_time_identity(tmp_path):
    def mutate(f):
        name=next(k for k in f if k.startswith('runtime_queries/') and k.endswith('.json'))
        rec=json.loads(f[name]);rec['time_hex']='0x0.0p+0';f[name]=js(rec)
    p,g=make_archive(tmp_path,mutate=mutate)
    with pytest.raises(EvidenceError,match='query identity'):
        SourceArchive(p,g)


def test_refuse_claim_promotion(tmp_path):
    def mutate(f):
        r=json.loads(f['RETURN_REPORT.json']);r['capture_execution_allowed']=True;f['RETURN_REPORT.json']=js(r)
    p,g=make_archive(tmp_path,mutate=mutate)
    with pytest.raises(EvidenceError,match='claim ceiling'):
        SourceArchive(p,g)


def test_refuse_nonindependent_resolution_pair(tmp_path):
    def mutate(f):
        name=next(k for k in f if k.startswith('runtime_queries/') and k.endswith('.json'))
        r=json.loads(f[name]);r['qualification']['lower_resolution']=r['qualification']['selected_resolution'];f[name]=js(r)
    p,g=make_archive(tmp_path,mutate=mutate)
    with pytest.raises(EvidenceError,match='adjacent'):
        SourceArchive(p,g)


def test_reference_states_are_reused_not_reintegrated(tmp_path):
    p,g=make_archive(tmp_path);s=SourceArchive(p,g)
    ref=s.reference()
    assert ref['arrays']['states'].shape==(3,2)
    assert ref['metric_norm_drift_recomputed']<1e-14
    assert s.audit['new_operator_evaluations']==0
