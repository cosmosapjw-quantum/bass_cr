from types import SimpleNamespace
import numpy as np
import pytest
from metric_transport import metric_frame_generator
from fixture_archive import make_archive
from tp2e_archive import SourceArchive,EvidenceError
from tp2e_core import run_cached_m4
from test_core import generator as rotating_G,exact as exact_rotating
from run_cached_m4 import compare_source,json_new


def test_full_offline_path_on_synthetic_archive(tmp_path):
    path,g=make_archive(tmp_path/'source');source=SourceArchive(path,g)
    out=tmp_path/'out';out.mkdir();events=[]
    result=compare_source(source,out,lambda event,**kw:events.append(event),ladder=(2,4,8))
    assert result['status']=='TP2E_CACHE_ONLY_M4_COMPARISON_PASS'
    assert result['new_operator_evaluations']==0 and result['reference_reintegrated'] is False
    assert result['selected_nstep']==4
    assert result['historical_replay']['stored_vs_replayed_metric_distance']<1e-13
    assert source.report['status']=='TEMPORAL_REFINEMENT_UNRESOLVED'
    assert (out/'SOURCE_AUDIT.json').exists()


def test_new_method_has_fourth_order_with_nontrivial_time_dependent_metric():
    class P:
        def at(self,t):
            R=np.array([[np.exp(.08*t),.1*np.sin(.6*t)+.05j*np.cos(.4*t)],[0,np.exp(-.05*t)]])
            Rd=np.array([[.08*np.exp(.08*t),.06*np.cos(.6*t)-.02j*np.sin(.4*t)],[0,-.05*np.exp(-.05*t)]])
            G=rotating_G(t)
            return SimpleNamespace(S=R.conj().T@R,H=1j*R.conj().T@G@R,D=R.conj().T@Rd)
    p=P();R0=metric_frame_generator(p.at(0)).R;c0=np.linalg.solve(R0,np.array([1,0],complex));errors=[]
    for n in (16,32,64):
        r=run_cached_m4(p,c0,0,4,n,metric_frame_generator)
        yf=metric_frame_generator(p.at(4)).R@r.final_state
        errors.append(np.linalg.norm(yf-exact_rotating(4)))
        assert r.max_norm_drift<2e-13
    assert np.all((np.log2(np.array(errors[:-1])/errors[1:])>3.8))


def test_missing_exact_time_has_no_integration_fallback(tmp_path):
    path,g=make_archive(tmp_path/'source');source=SourceArchive(path,g)
    source.snapshots.pop(next(hx for hx in source.snapshots if float.fromhex(hx)==-.5))
    out=tmp_path/'out';out.mkdir()
    with pytest.raises(EvidenceError,match='CACHE_MISS_EXACT_TIME'):
        compare_source(source,out,lambda *a,**k:None,ladder=(2,4,8))
    assert source.audit['new_operator_evaluations']==0


def test_create_only_result_writer_preserves_existing_bytes(tmp_path):
    p=tmp_path/'report.json';json_new(p,{'old':1});original=p.read_bytes()
    with pytest.raises(FileExistsError):json_new(p,{'new':2})
    assert p.read_bytes()==original
