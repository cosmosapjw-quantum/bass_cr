from types import SimpleNamespace
import numpy as np
import pytest
from scipy.linalg import expm, solve_triangular
from tp2e_core import m4_qmq_omega, cf4_step, midpoint_times
from metric_transport import metric_frame_generator

X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1.,-1.]).astype(complex)

def generator(t):
    return -1j*(.7*np.cos(1.3*t)*X+.7*np.sin(1.3*t)*Y-.2*Z)

def exact(t):
    return expm(-.5j*1.3*t*Z) @ expm(-1j*(.7*X+(-.2-.65)*Z)*t) @ np.array([1.,0.],complex)

def propagate(n, method='m4', tmax=4.):
    y=np.array([1.,0.],complex);h=tmax/n
    for j in range(n):
        t=j*h
        if method=='m4':
            y=expm(m4_qmq_omega(generator(t+h/4),generator(t+h/2),generator(t+3*h/4),h))@y
        else:
            c=np.sqrt(3)/6
            y=cf4_step(generator(t+(0.5-c)*h),generator(t+(0.5+c)*h),h,y)
    return y

@pytest.mark.parametrize('method',['m4','cf4'])
def test_global_fourth_order_on_noncommuting_exact_rotating_hamiltonian(method):
    errors=[np.linalg.norm(propagate(n,method)-exact(4.)) for n in (16,32,64)]
    orders=np.log2(np.array(errors[:-1])/errors[1:])
    assert np.min(orders)>3.8, (errors,orders)
    assert np.max(orders)<4.2, (errors,orders)

@pytest.mark.parametrize('method',['m4','cf4'])
def test_constant_generator_exact(method):
    g=generator(.3);h=.7;y=np.array([.6,.8j])
    actual=expm(m4_qmq_omega(g,g,g,h))@y if method=='m4' else cf4_step(g,g,h,y)
    assert np.linalg.norm(actual-expm(h*g)@y)<2e-14

def test_m4_commuting_cubic_integral_is_exact():
    h=.4
    def f(t): return 1+2*t+3*t*t+4*t**3
    omega=m4_qmq_omega(-1j*f(h/4)*Z,-1j*f(h/2)*Z,-1j*f(3*h/4)*Z,h)
    assert np.linalg.norm(omega+1j*(h+h*h+h**3+h**4)*Z)<2e-14

def test_m4_time_reversal_and_skewness():
    h=.3;gs=[generator(t) for t in (h/4,h/2,3*h/4)]
    a=m4_qmq_omega(*gs,h);b=m4_qmq_omega(*gs[::-1],-h)
    assert np.linalg.norm(a+b)<2e-15
    assert np.linalg.norm(a+a.conj().T)<2e-15
    assert np.linalg.norm(expm(b)@expm(a)-np.eye(2))<3e-14

def test_cf4_time_reversal():
    h=.3;a=generator(.1);b=generator(.2);y=np.array([1.,0.],complex)
    assert np.linalg.norm(cf4_step(b,a,-h,cf4_step(a,b,h,y))-y)<3e-14

@pytest.mark.parametrize('method',['m4','cf4'])
def test_norm_preserved_without_projection_or_renormalization(method):
    y=propagate(64,method)
    assert abs(np.vdot(y,y).real-1)<3e-14

def test_exact_node_bits_match_tp1_computation():
    t0=-5.97615196683871;tf=-t0;n=384;dt=(tf-t0)/n
    expected=[]
    for j in range(n):
        ta=t0+j*dt;tb=ta+dt;expected.append(.5*(ta+tb))
    actual=midpoint_times(t0,tf,n)
    assert [float(t).hex() for t in actual]==[float(t).hex() for t in expected]
    # Mathematical equivalence is deliberately not a cache-identity rule.
    simplified=t0+(np.arange(n)+.5)*dt
    assert any(float(a).hex()!=float(b).hex() for a,b in zip(actual,simplified))

def test_moving_metric_adapter_matches_known_frame_generator():
    t=.37
    R=np.array([[np.exp(.08*t),.1*np.sin(.6*t)+.05j*np.cos(.4*t)],[0,np.exp(-.05*t)]])
    Rd=np.array([[.08*np.exp(.08*t),.06*np.cos(.6*t)-.02j*np.sin(.4*t)],[0,-.05*np.exp(-.05*t)]])
    g=generator(t);snap=SimpleNamespace(S=R.conj().T@R,H=1j*R.conj().T@g@R,D=R.conj().T@Rd)
    converted=metric_frame_generator(snap)
    assert np.linalg.norm(converted.R-R)<2e-14
    assert np.linalg.norm(converted.G-g)<2e-14

@pytest.mark.parametrize('h',[0.,float('nan'),float('inf')])
def test_invalid_step_rejected(h):
    with pytest.raises(ValueError):m4_qmq_omega(generator(0),generator(.1),generator(.2),h)

def test_mismatched_matrices_rejected():
    with pytest.raises(ValueError):m4_qmq_omega(np.eye(2),np.eye(3),np.eye(2),.1)
