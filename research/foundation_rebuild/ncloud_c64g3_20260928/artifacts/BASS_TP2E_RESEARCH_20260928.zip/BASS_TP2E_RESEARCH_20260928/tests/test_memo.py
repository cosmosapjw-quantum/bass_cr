import numpy as np
from same_center_memo import SameCenterMemo


def test_two_centers_computed_once_for_all_cross_resolutions():
    tr=object();ch=(object(),object());calls=[]
    def original(tr_,ch_,t,center,*,order=20):
        calls.append((t,center,order));return {'S':np.array([[t+center]])}
    memo=SameCenterMemo(original,tr,ch)
    results=[memo(tr,ch,.5,c,order=20) for q in range(8) for c in (0,1)]
    assert len(calls)==2
    assert all(results[2*j] is results[0] for j in range(8))
    assert memo.hits==14 and memo.misses==2
    memo(tr,ch,.75,0,order=20)
    assert memo.entries<=2 and memo.misses==3


def test_nearby_float_time_and_different_order_are_not_reused():
    tr=object();ch=(object(),);calls=[]
    def original(*args,**kwargs):calls.append((args,kwargs));return len(calls)
    memo=SameCenterMemo(original,tr,ch)
    assert memo(tr,ch,1.,0,order=20)==1
    assert memo(tr,ch,np.nextafter(1.,2.),0,order=20)==2
    assert memo(tr,ch,np.nextafter(1.,2.),0,order=21)==3


def test_other_trajectory_or_channel_objects_fall_through():
    tr=object();ch=(object(),);calls=[]
    def original(*args,**kwargs):calls.append(args);return len(calls)
    memo=SameCenterMemo(original,tr,ch)
    assert memo(tr,ch,1.,0)==1
    assert memo(object(),ch,1.,0)==2
    assert memo(tr,(object(),),1.,0)==3
    assert memo(tr,ch,1.,0)==1
