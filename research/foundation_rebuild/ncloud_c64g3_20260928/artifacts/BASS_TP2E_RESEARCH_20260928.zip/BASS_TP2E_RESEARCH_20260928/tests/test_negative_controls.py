import numpy as np
from research_metrics import toy_benchmark


def test_wrong_commutator_or_omission_is_second_not_fourth_order_even_with_good_norm():
    rows=toy_benchmark()['rows']
    for method in ('m4_wrong_commutator_sign','m4_no_commutator'):
        r=next(r for r in rows if r['method']==method and r['nstep']==128)
        assert 1.9<r['observed_order']<2.1
        assert r['norm_drift']<1e-12
        assert r['absolute_state_error']>1e-4
    for method in ('m4_qmq','cf4'):
        r=next(r for r in rows if r['method']==method and r['nstep']==128)
        assert 3.9<r['observed_order']<4.1
        assert r['absolute_state_error']<3e-8
