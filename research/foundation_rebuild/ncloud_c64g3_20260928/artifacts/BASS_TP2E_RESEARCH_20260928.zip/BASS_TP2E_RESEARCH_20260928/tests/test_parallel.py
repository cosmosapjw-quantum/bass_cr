from probe_native import parallel_toy,host_resources


def test_spawn_process_mapping_preserves_task_order():
    assert parallel_toy([3,1,4,2],2)==[(3,9.),(1,1.),(4,16.),(2,4.)]


def test_detected_hardware_limits_are_positive_and_not_fabricated_5900x():
    h=host_resources()
    assert h['physical_cores_in_affinity']>=1
    assert h['physical_cores_in_affinity']<=len(h['logical_affinity'])
    assert h['blas_threads_per_worker']==1
