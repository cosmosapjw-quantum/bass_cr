"""Read-only, exact-byte TP2D evidence admission and selected-matrix replay.

The old FAIL is never rewritten. No module in this file assembles an operator.
An archive/manifest authenticates lower-resolution full-operator diagnostics;
only the selected full S/H/D and every attempted cross block are in the cache.
This distinction is retained in the audit instead of claiming a fresh full
independent recomputation of the lower-resolution same-center blocks.
"""
from __future__ import annotations
import hashlib,io,json,stat,zipfile
from pathlib import Path,PurePosixPath
from types import SimpleNamespace
import numpy as np

CROSS_KEYS=('S_tp','S_pt','H_tp','H_pt','D_tp','D_pt')
CEILING={'capture_execution_allowed':False,'production_admission':'HOLD',
         'all_bound':'OPEN','b_grid':'NO_GO','original_capture_gap_resolved':False,
         'continuous_trajectory_error_bound':False,'continuous_global_supremum_bound':False}

class EvidenceError(ValueError):
    pass


def sha(data):return hashlib.sha256(data).hexdigest()
def digest(obj):return sha(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def require(condition,message):
    if not condition:raise EvidenceError(message)
def decode_json(data):
    def reject(x):raise EvidenceError('nonfinite JSON constant: '+x)
    return json.loads(data,parse_constant=reject)
def relative(a,b):
    return float(np.linalg.norm(a-b)/max(np.linalg.norm(a),np.linalg.norm(b),1e-300))
def tag(rule):return f"q{rule['order']}_h{rule['subdivisions']}"


def full_screen(arrays,screens,dimension):
    for name in ('S','H','D'):
        a=arrays[name]
        require(a.shape==(dimension,dimension) and a.dtype.kind=='c' and a.dtype.itemsize==16
                and np.isfinite(a).all(),'selected full matrix shape/dtype/finiteness')
    s,h=arrays['S'],arrays['H']
    sd,hd=relative(s,s.conj().T),relative(h,h.conj().T)
    ev=np.linalg.eigvalsh((s+s.conj().T)/2)
    ratio=float(ev[0]/ev[-1]) if ev[-1]>0 else -1.
    require(max(sd,hd)<=screens['operator_hermiticity_relative_max'],'selected Hermiticity gate')
    require(ev[0]>0 and ratio>=screens['metric_min_ratio'],'selected metric positivity/rank gate')
    return {'S_hermiticity_relative':sd,'H_hermiticity_relative':hd,
            'metric_min':float(ev[0]),'metric_max':float(ev[-1]),'metric_ratio':ratio}


class SourceArchive:
    def __init__(self,path,grant):
        self.path=Path(path).resolve();self.grant=dict(grant)
        require(self.path.is_file(),'source archive missing')
        require(self.path.stat().st_size<=grant['maximum_archive_bytes'],'archive size bound exceeded')
        data=self.path.read_bytes()
        require(sha(data)==grant['archive_sha256'],'archive hash mismatch')
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos=z.infolist();names=[x.filename for x in infos]
            require(len(names)==len(set(names)),'duplicate ZIP members')
            require(len(names)<=grant['maximum_members'],'archive member count bound')
            require(sum(x.file_size for x in infos)<=grant['maximum_uncompressed_bytes'],'uncompressed size bound')
            for x in infos:
                p=PurePosixPath(x.filename)
                require(not p.is_absolute() and '..' not in p.parts and '\\' not in x.filename
                        and not x.is_dir() and not stat.S_ISLNK(x.external_attr>>16),'unsafe ZIP path/type')
            # Reading each member also checks its CRC. Nothing is extracted.
            self.files={name:z.read(name) for name in names}
        require('MANIFEST.json' in self.files and 'RETURN_REPORT.json' in self.files,'manifest/report missing')
        manifest=self.json('MANIFEST.json')
        require(set(self.files)==set(manifest)|{'MANIFEST.json'},'manifest coverage mismatch')
        for name,row in manifest.items():
            payload=self.files[name]
            require(len(payload)==row['bytes'] and sha(payload)==row['sha256'],'manifest hash/size mismatch: '+name)
        require(sha(self.files['RETURN_REPORT.json'])==grant['report_sha256'],'report hash mismatch')
        self.report=self.json('RETURN_REPORT.json')
        for key in ('status','execution_head','execution_tree'):
            require(self.report.get(key)==grant[key],'source '+key+' mismatch')
        for key,value in CEILING.items():
            require(type(self.report.get(key)) is type(value) and self.report[key]==value,'source claim ceiling mismatch: '+key)
        tests=self.report['new_tests']
        require(tests.get('tests')==grant['test_count'] and tests.get('returncode')==0 and
                all(tests.get(k)==0 for k in ('failures','errors','skipped')),'source test evidence mismatch')
        require(self.report.get('first_failure',{}).get('phase')=='candidate_transport','unexpected source failure phase')
        sc=self.json('SCIENCE_CONTEXT.json');self.context=sc['context'];self.context_id=sc['context_id']
        require(digest(self.context)==self.context_id,'science context hash mismatch')
        self.contract=self.context['contract'];physics=self.context['physics_identity']
        for key in ('energy_keV_per_u','b_a0','z_initial_a0','z_final_a0','same_center_order','runtime_reference_resolutions'):
            require(self.contract.get(key)==grant[key],'source contract mismatch: '+key)
        for key,value in grant['screens'].items():
            require(self.contract['screens'].get(key)==value,'source screen mismatch: '+key)
        require(self.contract.get('candidate_step_counts')==grant['historical_step_counts'],'source temporal ladder mismatch')
        require(self.contract.get('qualification_sector')=='full' and self.contract.get('runtime_phase_budget') is None
                and self.contract.get('operator_interpolation_used') is False,'source provider policy mismatch')
        for key in ('analytic_source_sha256','analytic_library_sha256'):
            require(physics.get(key)==grant[key],'source engine identity mismatch: '+key)
        brec=self.json('BASIS.json')
        require(sha(self.files['BASIS.npz'])==brec['matrix_sha256'],'basis payload mismatch')
        require(digest({k:v for k,v in brec.items() if k!='identity'})==brec['identity'],'basis record mismatch')
        require(physics['basis_identity']==brec['identity'],'basis context mismatch')
        self.snapshots={};self.receipts={};raw_count=0;maxdiff=0.;hist={}
        qnames=sorted(k for k in self.files if k.startswith('runtime_queries/') and k.endswith('.json'))
        require(len(qnames)==grant['query_count'],'runtime query count mismatch')
        for name in qnames:
            rec=self.json(name);qid=PurePosixPath(name).stem;hx=rec['time_hex'];t=float.fromhex(hx)
            require(np.isfinite(t) and t.hex()==hx,'noncanonical query time')
            require(qid==rec.get('query_id') and rec.get('context_id')==self.context_id and
                qid==digest({'schema':'BASS_TP2D_RUNTIME_QUERY_V1','context_id':self.context_id,'time_hex':hx}),
                'runtime query identity mismatch')
            require(hx not in self.snapshots,'duplicate exact query time')
            require(rec.get('schema')=='BASS_TP2D_QUALIFIED_RUNTIME_QUERY_V1','query schema mismatch')
            require(rec.get('capture_execution_allowed') is False and rec.get('continuous_global_supremum_bound') is False,
                    'query claim ceiling mismatch')
            npzname=name[:-5]+'.npz'
            require(npzname in self.files and sha(self.files[npzname])==rec['payload_sha256'],'query payload hash mismatch')
            arrays=self.arrays(npzname)
            q=rec['qualification'];attempts=rec['attempts'];ladder=grant['runtime_reference_resolutions']
            require(q.get('status')=='RUNTIME_QUERY_QUALIFIED' and
                    q.get('evidence_relation')=='INDEPENDENT_NUMERICAL_RESOLUTION_COMPARISON','query not qualified independently')
            require(2<=len(attempts)<=len(ladder) and [a['resolution'] for a in attempts]==ladder[:len(attempts)],
                    'attempted ladder prefix mismatch')
            require(q['lower_resolution']==attempts[-2]['resolution'] and q['selected_resolution']==attempts[-1]['resolution']
                    and q['lower_resolution']!=q['selected_resolution'],'selected pair not adjacent independent resolutions')
            expected={'selected__'+k for k in ('S','H','D')}
            n=grant['channel_count'];m=n//2
            require(n%2==0,'symmetric-center dimension required')
            for attempt in attempts:
                prefix=tag(attempt['resolution'])+'__'
                expected|={prefix+k for k in CROSS_KEYS}
                for k in CROSS_KEYS:
                    a=arrays[prefix+k]
                    require(a.shape==(m,m) and a.dtype.kind=='c' and a.dtype.itemsize==16
                            and np.isfinite(a).all(),'attempt cross shape/dtype/finiteness')
            require(set(arrays)==expected,'query NPZ member set mismatch')
            for attempt in attempts[-2:]:
                d=attempt['diagnostics']
                require(d.get('hermiticity_pass') is True and d.get('metric_pass') is True and
                        d['hermiticity_relative_max']<=grant['screens']['operator_hermiticity_relative_max'] and
                        d['metric_ratio']>=grant['screens']['metric_min_ratio'],'archived pair diagnostics failed')
            lo,hi=tag(q['lower_resolution']),tag(q['selected_resolution'])
            details={k:relative(arrays[lo+'__'+k],arrays[hi+'__'+k]) for k in CROSS_KEYS}
            dmax=max(details.values())
            require(np.isfinite(dmax) and dmax<=grant['screens']['raw_cross_relative_max'],'replayed cross convergence failed')
            require(np.isclose(dmax,q['max_raw_cross_relative_difference'],rtol=1e-8,atol=1e-15),'stored/replayed cross difference mismatch')
            selected={k:arrays['selected__'+k] for k in ('S','H','D')}
            diag=full_screen(selected,grant['screens'],n)
            for k in ('S','H','D'):
                require(np.array_equal(selected[k][:m,m:],arrays[hi+'__'+k+'_tp']) and
                        np.array_equal(selected[k][m:,:m],arrays[hi+'__'+k+'_pt']),
                        'selected full/cross block identity mismatch')
                selected[k].setflags(write=False)
            self.snapshots[hx]=SimpleNamespace(t=t,**selected,diagnostics=diag,qualification=q,identity=qid)
            self.receipts[hx]=rec;raw_count+=len(attempts);maxdiff=max(maxdiff,dmax);hist[hi]=hist.get(hi,0)+1
        require(raw_count==grant['raw_evaluation_count'],'raw evaluation ledger mismatch')
        last=self.json(f"CANDIDATE_N{grant['historical_step_counts'][-1]}.json")
        require(last['unique_runtime_queries_after']==len(self.snapshots) and last['raw_operator_evaluations_after']==raw_count,
                'candidate/provider ledger mismatch')
        self.audit={'original_status':self.report['status'],'archive_sha256':grant['archive_sha256'],
            'report_sha256':grant['report_sha256'],'manifest_entries_verified':len(manifest),
            'selected_operator_payloads_revalidated':len(self.snapshots),'raw_cross_attempts_revalidated':raw_count,
            'all_saved_selected_queries_revalidated':True,'resolution_histogram':hist,
            'max_selected_cross_difference_recomputed':maxdiff,'new_operator_evaluations':0,
            'lower_full_diagnostics':'ARCHIVE_MANIFEST_BOUND_NOT_FRESH_FULL_MATRIX_RECOMPUTATION',
            'continuous_global_supremum_bound':False,
            'selected_matrix_bytes':sum(a.nbytes for s in self.snapshots.values() for a in (s.S,s.H,s.D))}
        self.lookup_count=0

    def json(self,name):
        require(name in self.files,'archive member missing: '+name)
        return decode_json(self.files[name])

    def arrays(self,name):
        require(name in self.files,'archive member missing: '+name)
        with np.load(io.BytesIO(self.files[name]),allow_pickle=False) as f:
            require(len(f.files)==len(set(f.files)),'duplicate NPZ members')
            return {k:np.array(f[k]) for k in f.files}

    def at(self,t):
        t=float(t);require(np.isfinite(t),'finite query time required')
        hx=t.hex()
        require(hx in self.snapshots,'CACHE_MISS_EXACT_TIME '+hx)
        self.lookup_count+=1
        return self.snapshots[hx]

    def reference(self):
        receipt=self.json('REFERENCE_RECEIPT.json');a=self.arrays('REFERENCE_STATES.npz')
        for key,gkey in (('method','reference_method'),('rtol','reference_rtol'),('atol','reference_atol'),('nfev','reference_nfev')):
            require(receipt.get(key)==self.grant[gkey],'reference '+key+' mismatch')
        require(receipt['max_norm_drift']<=self.grant['screens']['reference_norm_drift_max'],'archived reference norm gate')
        t=a['times'];states=a['states'];n=self.grant['channel_count']
        require(t.ndim==1 and len(t)>=2 and np.isfinite(t).all() and np.all(np.diff(t)>0),'reference time array invalid')
        require(states.shape==(len(t),n) and np.isfinite(states).all(),'reference states invalid')
        require(a['initial_state'].shape==(n,) and a['final_state'].shape==(n,),'reference endpoints invalid')
        require(np.array_equal(states[0],a['initial_state']) and np.array_equal(states[-1],a['final_state']),
                'reference endpoint array identity mismatch')
        norms=[]
        for time,c in zip(t,states):
            value=np.vdot(c,self.at(time).S@c)
            require(np.isfinite(value) and value.real>0 and abs(value.imag)<1e-11,'reference metric norm invalid')
            norms.append(value.real)
        drift=float(np.max(np.abs(np.array(norms)-norms[0])))
        require(drift<=self.grant['screens']['reference_norm_drift_max'],'replayed reference norm gate')
        return {'receipt':receipt,'arrays':a,'metric_norm_drift_recomputed':drift,
                'evidence_relation':'REUSED_PINNED_DOP853_RUN_NOT_NEW_REFERENCE_SOLVE'}
