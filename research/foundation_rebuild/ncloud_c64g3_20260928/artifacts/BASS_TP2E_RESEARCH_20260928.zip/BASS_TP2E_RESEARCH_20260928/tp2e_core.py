"""Fourth-order time-discretization experiments. No operator interpolation.

M4-QMQ integrates y'=G(t)y using *actual* quarter, midpoint and three-quarter
samples. Its fourth-order claim assumes sufficient time smoothness. It does
not turn per-query quadrature convergence into a continuous error bound.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.linalg import expm, solve_triangular


def _inputs(matrices, h):
    h=float(h)
    if not np.isfinite(h) or h==0:
        raise ValueError('finite nonzero signed time step required')
    arrays=tuple(np.asarray(m,dtype=np.complex128) for m in matrices)
    shape=arrays[0].shape
    if len(shape)!=2 or shape[0]!=shape[1] or shape[0]<1:
        raise ValueError('nonempty square matrices required')
    if any(m.shape!=shape or not np.isfinite(m).all() for m in arrays):
        raise ValueError('matrix shape/finiteness mismatch')
    return arrays,h


def m4_qmq_omega(g1, gm, g3, h):
    """Open three-point quadrature plus the leading Magnus commutator.

    Omega = h(2 G_1 - G_m + 2 G_3)/3 - h^2 [G_1,G_3]/6.
    Chronological convention: a later step multiplies the state on the left.
    Raw matrices are never projected onto the skew-Hermitian subspace.
    """
    (g1,gm,g3),h=_inputs((g1,gm,g3),h)
    return h*((2*g1-gm+2*g3)/3)-(h*h/6)*(g1@g3-g3@g1)


def cf4_step(g1, g2, h, y):
    """Standard CF4 at the two Gauss nodes, earlier node first.

    U = exp[h(a G1+b G2)] exp[h(b G1+a G2)],
    a=(3-2 sqrt(3))/12, b=(3+2 sqrt(3))/12.
    The rightmost exponential acts first.
    """
    (g1,g2),h=_inputs((g1,g2),h)
    y=np.asarray(y,dtype=np.complex128)
    if y.shape!=(len(g1),) or not np.isfinite(y).all():
        raise ValueError('finite state vector matching generator required')
    a=(3-2*np.sqrt(3))/12;b=(3+2*np.sqrt(3))/12
    return expm(h*(a*g1+b*g2))@(expm(h*(b*g1+a*g2))@y)


def midpoint_times(t0, tf, n):
    """Reproduce TP1 run_candidate/candidate_step arithmetic, bit for bit.

    Do not replace by linspace or t0+(j+1/2)*dt: those expressions can have
    different binary64 time identities and would miss the historical cache.
    """
    t0=float(t0);tf=float(tf)
    if type(n) is not int or n<1 or not np.isfinite([t0,tf]).all() or tf<=t0:
        raise ValueError('finite increasing interval and positive integer n required')
    dt=(tf-t0)/n
    result=[]
    for j in range(n):
        ta=t0+j*dt;tb=ta+dt
        result.append(.5*(ta+tb))
    return np.array(result,dtype=np.float64)


@dataclass(frozen=True)
class M4Result:
    nstep: int
    dt: float
    initial_state: np.ndarray
    final_state: np.ndarray
    norm_history: np.ndarray
    max_norm_drift: float
    max_generator_defect: float
    max_omega_defect: float
    node_count: int


def run_cached_m4(provider,c0,t0,tf,n,frame_fn,*,skew_limit=1e-11):
    """Compute a new M4 endpoint with N and 2N legacy midpoint samples.

    provider.at must be an exact-time, read-only lookup for the offline route.
    This function has no assembler, tolerance tuning or cache-miss fallback.
    """
    mids=midpoint_times(t0,tf,n);quarters=midpoint_times(t0,tf,2*n)
    dt=(float(tf)-float(t0))/n
    s0=provider.at(float(t0));sf=provider.at(float(tf))
    c0=np.array(c0,dtype=np.complex128,copy=True)
    norm0=np.vdot(c0,s0.S@c0)
    if not np.isfinite(norm0) or norm0.real<=0 or abs(norm0.imag)>1e-12*max(1.,abs(norm0.real)):
        raise ValueError('initial metric norm invalid')
    c0/=np.sqrt(norm0.real)
    y=frame_fn(s0).R@c0
    norms=[float(np.vdot(y,y).real)];max_g=0.;max_o=0.
    for j in range(n):
        gs=[]
        for t in (quarters[2*j],mids[j],quarters[2*j+1]):
            frame=frame_fn(provider.at(float(t)))
            max_g=max(max_g,float(frame.antihermitian_defect));gs.append(frame.G)
        ta=float(t0)+j*dt;tb=ta+dt
        omega=m4_qmq_omega(*gs,tb-ta)
        defect=float(np.linalg.norm(omega+omega.conj().T)/max(np.linalg.norm(omega),1e-300))
        max_o=max(max_o,defect)
        if max_g>skew_limit or max_o>skew_limit:
            raise ArithmeticError('raw generator/omega skewness gate failed')
        y=expm(omega)@y
        if not np.isfinite(y).all():raise ArithmeticError('nonfinite M4 state')
        norms.append(float(np.vdot(y,y).real))
    cf=solve_triangular(frame_fn(sf).R,y,lower=False,check_finite=True)
    norms=np.array(norms)
    final_metric=float(np.vdot(cf,sf.S@cf).real)
    drift=max(float(np.max(np.abs(norms-norms[0]))),abs(final_metric-norms[0]))
    return M4Result(n,dt,c0,cf,norms,drift,max_g,max_o,3*n)
